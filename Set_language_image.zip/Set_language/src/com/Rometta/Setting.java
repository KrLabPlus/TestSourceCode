package com.Rometta;

import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;

public class Setting extends Activity {
	
	ImageView image;
			
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting);
		
		image = (ImageView)findViewById(R.id.image);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		int menu_key = i.getIntExtra("key", 0);//0縺ｯ蜿励￠蜿悶ｋ蛟､縺後↑縺�蝣ｴ蜷医↓貂｡縺吝�､
		//蜑阪�ｮ逕ｻ髱｢縺ｧ縺ｮ險�隱槭�ｮ蛟､繧貞女縺大叙繧翫�∵擅莉ｶ蛻�蟯舌〒陦ｨ遉ｺ縺吶ｋ繝｡繝九Η繝ｼ繧貞愛譁ｭ縺吶ｋ
		//0=譌･譛ｬ隱�, 1=闍ｱ隱�, 2=蝨滉ｽ仙ｼ�
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
			image.setImageResource(R.drawable.howto_howto_desuca_en);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//繝｡繝九Η繝ｼ縺ｮ鬆�逶ｮ縺碁∈謚槭＆繧後◆縺ｨ縺阪↓菴ｿ逕ｨ縺吶ｋ繝｡繧ｽ繝�繝�
	//key縺ｮ謨ｰ蟄励�ｯ荳翫�ｮ繝｡繧ｽ繝�繝峨�ｮ謨ｰ蟄励↓蟇ｾ蠢懊＠縺ｦ縺�繧�
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("it");
			  reload(key);
			  break;
		}
		return super.onOptionsItemSelected(item);
	}

	//蜿ら�ｧ縺吶ｋ繝輔ぃ繧､繝ｫ繧貞､画峩縺吶ｋ繝｡繧ｽ繝�繝�
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//逕ｻ髱｢繧貞�崎ｪｭ縺ｿ霎ｼ縺ｿ縺吶ｋ繝｡繧ｽ繝�繝�
	//逕ｻ髱｢驕ｷ遘ｻ縺吶ｋ髫帙↓縲｝utExtra縺ｧ驕ｸ謚槭＆繧後◆險�隱樊ュ蝣ｱ繧呈ｸ｡縺励※縺�繧�
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("key", key);
		startActivity(reload);
		
	}
}
