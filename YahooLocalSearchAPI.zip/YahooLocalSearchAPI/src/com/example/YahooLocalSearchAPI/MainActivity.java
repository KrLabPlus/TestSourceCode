package com.example.YahooLocalSearchAPI;

import com.example.YahooLocalSearchAPI.R;

import android.app.Activity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener{
	SpannableStringBuilder sb1;
	SpannableStringBuilder sb2;
	String izakaya;
	String cafe;
	String restaurant;
	String dist;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.activity_main);

		EditText edit1 = (EditText) findViewById(R.id.editText1);
		EditText edit2 = (EditText) findViewById(R.id.editText2);
		
		//EditText???????????????????????????????????????
		sb1 = (SpannableStringBuilder)edit1.getText();
		sb2 = (SpannableStringBuilder)edit2.getText();
	
        
        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.RadioGroup);
        radioGroup.check(R.id.radioButton300);
        dist = "0.3";
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {  
        	public void onCheckedChanged(RadioGroup group, int checkedId) {   
                  
           if (checkedId == R.id.radioButton300) {
                	dist = "0.3";  
                } else if (checkedId == R.id.radioButton500) {
                	dist = "0.5";
                } else {
                	dist = "1";
                }
              }  
           });
		
		findViewById(R.id.button1).setOnClickListener(this);
		
	}
	
	public void onClick(View v) {
		TextView textView1 = (TextView) findViewById(R.id.textView1);
		textView1.setText("");
		
		String lat = sb1.toString();
		String lon = sb2.toString();
		
		YahooLocalSearchAPI task = new YahooLocalSearchAPI(this);
		task.execute(lat, lon, dist);
	}
}