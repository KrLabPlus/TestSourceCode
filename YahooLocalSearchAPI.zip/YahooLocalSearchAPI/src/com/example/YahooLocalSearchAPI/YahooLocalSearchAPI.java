package com.example.YahooLocalSearchAPI;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.TreeMap;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.xmlpull.v1.XmlPullParser;

import com.example.YahooLocalSearchAPI.R;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;
import android.widget.TextView;

public class YahooLocalSearchAPI extends AsyncTask<String, Void, TreeMap<Integer, String>>{
	static final String TAG = "YahooLocalSearchTest";
	static final int MIN_TIME = 0;
	static final int MIN_METER = 0;
	private static final String api_uri = "http://search.olp.yahooapis.jp/OpenLocalPlatform/V1/localSearch?";
	private static final String keyid = "dj0zaiZpPU9wYWVraUQyMlZHUyZzPWNvbnN1bWVyc2VjcmV0Jng9NWU-";
	private static final String device = "mobile";
	private static final String sort = "dist";
	private static final int results = 10;
	private static final String gc = "0205001";
	static final double ERROR_DOUBLE = 10000.0;
	static final String ERROR_STRING = "NULL";
	private Activity main_activity;

	
	public YahooLocalSearchAPI(Activity activity) {
		this.main_activity = activity;
	}
	
	protected TreeMap<Integer, String> doInBackground(String... string) {
		float lat = Float.parseFloat(string[0]);
		float lon = Float.parseFloat(string[1]);
		String dist = string[2];
		
		//APIから受け取ったスポットデータを格納するTreeMap
		TreeMap<Integer, String> Convini = new TreeMap<Integer, String>();
		
		//HTTPクライアントの生成
		HttpClient http_client = new DefaultHttpClient();
		
		//APIからXMLを生成
    	Log.i(TAG, "createXML/lat:" + lat + ", lon:" + lon);
		String uri = api_uri + "appid=" + keyid + "&device=" + device + "&sort=" + sort + "&results=" + results
				+ "&lat=" + lat + "&lon=" + lon + "&dist=" + dist + "&gc=" + gc;
		Log.i(TAG, uri);
    	HttpGet request = new HttpGet(uri);
    	HttpResponse response = null;
    	
    	try { 
    		response = http_client.execute(request);
    	} catch (ClientProtocolException e) {
    		e.printStackTrace();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	
    	int status = response.getStatusLine().getStatusCode();
    	if (status == HttpStatus.SC_OK) {
    		try {
    			ByteArrayOutputStream ostream = new ByteArrayOutputStream();
    			response.getEntity().writeTo(ostream);
    			
    			//XML??????????????????
    			XmlPullParser xml_pullparser = Xml.newPullParser();
    			xml_pullparser.setInput(new StringReader(ostream.toString()));
    			
    			int eventType = 0;
				String name_latlon = new String();
				String[] spot_data = new String[10];
				int spot_count = 0;
				boolean name_get_is = false;
				boolean coordinates_get_is = false;
				
				//XML????????????
    			while (((eventType = xml_pullparser.next()) != XmlPullParser.END_DOCUMENT) && (spot_count != 10)) {
    				if (eventType == XmlPullParser.START_TAG && "Name".equals(xml_pullparser.getName()) && name_get_is != true) {
    					name_latlon += xml_pullparser.nextText() + ",";
    					name_get_is = true;
    				} else if (eventType == XmlPullParser.START_TAG && "Coordinates".equals(xml_pullparser.getName()) && coordinates_get_is != true) {
    					name_latlon += xml_pullparser.nextText();
    					coordinates_get_is = true;
    				} else if (eventType == XmlPullParser.END_TAG && "Feature".equals(xml_pullparser.getName())) {
    					spot_count++;
    					spot_data[spot_count - 1] = name_latlon;
    					Convini.put(spot_count, spot_data[spot_count - 1]);
    					name_latlon = "";
    					name_get_is = false;
    					coordinates_get_is = false;
    				}
    			}
    		} catch (Exception e) {
    	    	Log.d("XmlPullParser", "Error");
    	    }
    	}
    	
		return Convini;
    	
	}
	
	
	String[] spotDataAnalyze (String spotData) {
		String[] analyzedSpotData = spotData.split(",");
		return analyzedSpotData;
	}
	
	@Override
	protected void onPostExecute(TreeMap<Integer, String> Convini) {
		TextView text_view1 = (TextView) main_activity.findViewById(R.id.textView1);
	    
	    for (int spot_count : Convini.keySet()) {
		    text_view1.append("\n" + spot_count + ": ");
		    String[] analyzedSpotData = spotDataAnalyze(Convini.get(spot_count));
		    text_view1.append("店名：" + analyzedSpotData[0] + "\n");
		    text_view1.append("緯度：" + analyzedSpotData[1] + "\n");
		    text_view1.append("経度：" + analyzedSpotData[2] + "\n");
	    }

	}
}
