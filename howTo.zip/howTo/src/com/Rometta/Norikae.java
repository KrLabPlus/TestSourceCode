package com.Rometta;

import android.app.Activity;
import android.os.Bundle;

public class Norikae extends Activity {
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.norikae);
	}

}
