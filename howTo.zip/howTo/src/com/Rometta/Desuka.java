package com.Rometta;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ScrollView;

public class Desuka extends Activity implements OnClickListener {
	
	private Button desuka_menu1, desuka_menu2, desuka_menu3, top1;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.desuka);
		
		desuka_menu1 = (Button)findViewById(R.id.desuka_menu1);
		desuka_menu2 = (Button)findViewById(R.id.desuka_menu2);
		desuka_menu3 = (Button)findViewById(R.id.desuka_menu3);
		top1 = (Button)findViewById(R.id.back1);

		
		desuka_menu1.setOnClickListener(this);
		desuka_menu2.setOnClickListener(this);
		desuka_menu3.setOnClickListener(this);
		top1.setOnClickListener(this);

	}
	
	public void onClick(View view) {
		if(view == desuka_menu1) {
			ImageView desukaImage1  = (ImageView)findViewById(R.id.desuka_image);
			ImageView norioriImage1 = (ImageView)findViewById(R.id.desuka_touch);
			ImageView norioriImage2 = (ImageView)findViewById(R.id.desuka_touch2);
			desukaImage1.setImageResource(R.drawable.howto_desuca_use);
			norioriImage1.setImageResource(R.drawable.desuka_touch);
			norioriImage2.setImageResource(R.drawable.desuka_touch2);
			TextView desukaCheck1 = (TextView)findViewById(R.id.text1);
			TextView desukaCheck2 = (TextView)findViewById(R.id.text2);
			desukaCheck1.setText(getResources().getString(R.string.desuka_noriori1));
			desukaCheck2.setText(getResources().getString(R.string.desuka_noriori2));
		}
		
		if(view == desuka_menu2) {
			ImageView desukaImage2  = (ImageView)findViewById(R.id.desuka_image);
			ImageView checkImage1   = (ImageView)findViewById(R.id.desuka_touch);
			ImageView checkImage2   = (ImageView)findViewById(R.id.desuka_touch2);
			desukaImage2.setImageResource(R.drawable.howto_zandaka);
			checkImage1.setImageResource(R.drawable.zandaka_check1);
			checkImage2.setImageResource(R.drawable.zandaka_check2);
			TextView desukaCheck1 = (TextView)findViewById(R.id.text1);
			TextView desukaCheck2 = (TextView)findViewById(R.id.text2);
			desukaCheck1.setText(getResources().getString(R.string.desuka_check1));
			desukaCheck2.setText(getResources().getString(R.string.desuka_check2));
		}
		
		if(view == desuka_menu3) {
			ImageView desukaImage3 = (ImageView)findViewById(R.id.desuka_image);
			ImageView chargeImage1 = (ImageView)findViewById(R.id.desuka_touch);
			ImageView chargeImage2 = (ImageView)findViewById(R.id.desuka_touch2);
			desukaImage3.setImageResource(R.drawable.howto_charge);
			chargeImage1.setImageResource(R.drawable.desuka_charge);
			chargeImage2.setImageResource(R.drawable.desuka_charge2);
			
			TextView desukaCharge1 = (TextView)findViewById(R.id.text1);
			TextView desukaCharge2 = (TextView)findViewById(R.id.text2);
			desukaCharge1.setText(getResources().getString(R.string.desuka_charge1));
			desukaCharge2.setText(getResources().getString(R.string.desuka_charge2));

		}
		
		if(view == top1) {
		final ScrollView back1 = (ScrollView)findViewById(R.id.desuka_scroll);
		back1.post(new Runnable() {
			public void run() {
				back1.scrollTo(0, back1.getTop());
			}
		});
		}

	}

	
}
