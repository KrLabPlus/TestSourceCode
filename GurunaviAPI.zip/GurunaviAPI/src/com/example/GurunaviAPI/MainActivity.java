package com.example.GurunaviAPI;

import android.app.Activity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener{
	SpannableStringBuilder sb1;
	SpannableStringBuilder sb2;
	String izakaya;
	String cafe;
	String restaurant;
	String range;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.activity_main);

		EditText edit1 = (EditText) findViewById(R.id.editText1);
		EditText edit2 = (EditText) findViewById(R.id.editText2);
		
		//EditTextに入力された緯度経度を保存
		sb1 = (SpannableStringBuilder)edit1.getText();
		sb2 = (SpannableStringBuilder)edit2.getText();
		
		//検索条件設定
		CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox1);
		CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
		CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
        
        checkBox1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox checkBox = (CheckBox) v;
                // チェックボックスのチェック状態を取得します
                if (checkBox.isChecked() == true) {
                	izakaya = "居酒屋";
                } else {
                	izakaya = "";
                }
            }
        });
        
        checkBox2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox checkBox = (CheckBox) v;
                // チェックボックスのチェック状態を取得します
                if (checkBox.isChecked() == true) {
                	cafe = "カフェ";
                } else {
                	cafe = "";
                }
            }
        });
        
        checkBox3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox checkBox = (CheckBox) v;
                // チェックボックスのチェック状態を取得します
                if (checkBox.isChecked() == true) {
                	restaurant = "レストラン";
                } else {
                	restaurant = "";
                }
            }
        });
        
        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.RadioGroup);
        radioGroup.check(R.id.radioButton300);
        range = "1";
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {  
            public void onCheckedChanged(RadioGroup group, int checkedId) {   
                
                // 選択されたRadioButtonによって範囲を変更  
                if (checkedId == R.id.radioButton300) {
                	range = "1";  
                } else if (checkedId == R.id.radioButton500) {
                	range = "2";
                } else {
                	range = "3";
                }
              }  
            });
		
		findViewById(R.id.button1).setOnClickListener(this);
		
	}
	
	//ボタンが押されたら実行
	public void onClick(View v) {
		TextView textView1 = (TextView) findViewById(R.id.textView1);
		//ボタンが押されるたびにTextViewと検索条件を初期化する
		textView1.setText("");
		String freeword = "";
		
		//EditTextに入力された緯度経度をStringとして格納
		String lat = sb1.toString();
		String lng = sb2.toString();
		
		//検索条件を格納
		if (izakaya == "居酒屋" && cafe == "" && restaurant == "") {
			freeword = izakaya;
		} else if (izakaya == "" && cafe == "カフェ" && restaurant == "") {
			freeword = cafe; 
		} else if (izakaya == "" && cafe == "" && restaurant == "レストラン") {
			freeword = restaurant; 
		} else if (izakaya == "居酒屋" && cafe == "カフェ" && restaurant == "") {
			freeword = izakaya + "," + cafe;
		} else if (izakaya == "" && cafe == "カフェ" && restaurant == "レストラン") {
			freeword = cafe + "," + restaurant;
		} else if (izakaya == "居酒屋" && cafe == "" && restaurant == "レストラン") {
			freeword = izakaya + "," + restaurant;
		} else if (izakaya == "居酒屋" && cafe == "カフェ" && restaurant == "レストラン") {
			freeword = izakaya + "," + cafe + "," + restaurant;
		} else {
			freeword = null;
		}
		
		//AsyncHttpRequestに緯度経度を投げる
		GurunaviAPI task = new GurunaviAPI(this);
		task.execute(lat, lng, freeword, range);
	}
}