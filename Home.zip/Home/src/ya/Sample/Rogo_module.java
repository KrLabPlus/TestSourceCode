package ya.Sample;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;

public class Rogo_module extends Activity{
	Button bt1;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rogo_module);

		new Handler().postDelayed(new Runnable() {
            public void run() {
            	Intent it = new Intent(getApplicationContext(), Home_module.class);
                startActivity(it);

                // �A�N�e�B�r�e�B���I�������邱�ƂŁA�X�v���b�V����ʂɖ߂邱�Ƃ�h���B
                Rogo_module.this.finish();
            }
        }, 1800);
    }
}