package ya.Sample;

import android.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import android.view.View.*;
import android.widget.*;

public class Home_module extends Activity {
	ImageButton bt1,bt2,bt3,bt4,bt5,bt6;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home_module);

		bt1 = (ImageButton)findViewById(R.id.imageButton1);
		bt2 = (ImageButton)findViewById(R.id.imageButton2);
		bt3 = (ImageButton)findViewById(R.id.imageButton3);
		bt4 = (ImageButton)findViewById(R.id.imageButton4);
		bt5 = (ImageButton)findViewById(R.id.imageButton5);
		bt6 = (ImageButton)findViewById(R.id.imageButton6);

		bt1.setOnClickListener(new HomeClickListener());
		bt2.setOnClickListener(new HomeClickListener());
		bt3.setOnClickListener(new HomeClickListener());
		bt4.setOnClickListener(new HomeClickListener());
		bt5.setOnClickListener(new HomeClickListener());
		bt6.setOnClickListener(new HomeClickListener());
	}
	class HomeClickListener implements OnClickListener{
		public void onClick(View v){
			Intent it;
			if(v == bt1){
				it = new Intent(getApplicationContext(), Norikae_module.class);
			} else if(v == bt2){
				it = new Intent(getApplicationContext(), SpotSearch_module.class);
			} else if(v == bt3){
				it = new Intent(getApplicationContext(), TimeSchedule_module.class);
			} else if(v == bt4){
				it = new Intent(getApplicationContext(), DESUKA_module.class);
			} else if(v == bt5){
				it = new Intent(getApplicationContext(), HowTo_module.class);
			} else {
				it = new Intent(getApplicationContext(), Service_module.class);
			}
			startActivity(it);
		}
	}
}
