package ya.Sample;

import android.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import android.view.View.*;
import android.widget.*;

public class Home_module extends Activity {
	Button bt1,bt2,bt3,bt4,bt5,bt6;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home_module);

		bt1 = (Button)findViewById(R.id.button1);
		bt2 = (Button)findViewById(R.id.button2);
		bt3 = (Button)findViewById(R.id.button3);
		bt4 = (Button)findViewById(R.id.button4);
		bt5 = (Button)findViewById(R.id.button5);
		bt6 = (Button)findViewById(R.id.button6);

		bt1.setOnClickListener(new SampleClickListener1());
		bt2.setOnClickListener(new SampleClickListener2());
		bt3.setOnClickListener(new SampleClickListener3());
		bt4.setOnClickListener(new SampleClickListener4());
		bt5.setOnClickListener(new SampleClickListener5());
		bt6.setOnClickListener(new SampleClickListener6());
	}

	class SampleClickListener1 implements OnClickListener{
		public void onClick(View v){
			Intent it = new Intent(getApplicationContext(), Norikae_module.class);
			startActivity(it);
		}
	}
	class SampleClickListener2 implements OnClickListener{
		public void onClick(View v){
			Intent it = new Intent(getApplicationContext(), SpotSearch_module.class);
			startActivity(it);
		}
	}
	class SampleClickListener3 implements OnClickListener{
		public void onClick(View v){
			Intent it = new Intent(getApplicationContext(), TimeSchedule_module.class);
			startActivity(it);
		}
	}
	class SampleClickListener4 implements OnClickListener{
		public void onClick(View v){
			Intent it = new Intent(getApplicationContext(), DESUKA_module.class);
			startActivity(it);
		}
	}
	class SampleClickListener5 implements OnClickListener{
		public void onClick(View v){
			Intent it = new Intent(getApplicationContext(), HowTo_module.class);
			startActivity(it);
		}
	}
	class SampleClickListener6 implements OnClickListener{
		public void onClick(View v){
			Intent it = new Intent(getApplicationContext(), Service_module.class);
			startActivity(it);
		}
	}
}
