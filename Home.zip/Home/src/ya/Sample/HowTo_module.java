package ya.Sample;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class HowTo_module extends Activity{
	Button bt1;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_howto_module);

		bt1 = (Button)findViewById(R.id.button1);

		bt1.setOnClickListener(new SampleClickListener());
	}
	class SampleClickListener implements OnClickListener{
		public void onClick(View v){
			finish();
		}
	}
}