package com.Rometta;

import java.util.Locale;

import android.app.Activity;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class Setting extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting);
	}

    // オプションメニューが最初に呼び出される時に1度だけ呼び出されます
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		getMenuInflater().inflate(R.menu.setting, menu);
		return true;
	}

    // オプションメニューアイテムが選択された時に呼び出されます
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		int id = item.getItemId();
		if (id == R.id.language1) {
			initialize();
			return true;
		} else if (id == R.id.language2) {
			initialize();
			return true;
		} else if (id == R.id.credit){
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
    // オプションメニューが表示される度に呼び出されます
	public boolean onPrepareOptionsmenu(Menu menu) {
		menu.findItem(R.id.language1).setEnabled(true);
		menu.findItem(R.id.language2).setEnabled(true);
		menu.findItem(R.id.credit).setEnabled(true);
		return super.onPrepareOptionsMenu(menu);
	}
	
	private void initialize() {
        setContentView(R.layout.setting);
 
        Locale locale = Locale.getDefault();            // アプリで使用されているロケール情報を取得
        if (locale.equals(Locale.JAPAN)) {
        		locale = Locale.ENGLISH;
            } else {
            	locale = Locale.JAPAN;
            } 
        Locale.setDefault(locale);                      // 新しいロケールを設定
        Configuration config = new Configuration();
        config.locale = locale;                         // Resourcesに対するロケールを設定
        Resources resources = getBaseContext().getResources();
        resources.updateConfiguration(config, null);    // Resourcesに対する新しいロケールを反映
        setContentView(R.layout.setting);
	}
}
