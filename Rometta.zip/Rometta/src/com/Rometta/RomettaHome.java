package com.Rometta;

import java.util.Locale;

import com.Rometta.HowTo.*;
import com.Rometta.Desuka.*;
import com.Rometta.Norikae.*;
import com.Rometta.Service.*;
import com.Rometta.Spot.*;
import com.Rometta.TimeSchedule.*;

import android.app.*;
import android.os.*;
import android.text.Html;
import android.view.*;
import android.content.*;
import android.content.res.Configuration;
import android.view.View.*;
import android.widget.*;

public class RomettaHome extends Activity {
	int menu_key;
	ImageButton bt1,bt2,bt3,bt4,bt5,bt6;
    private static final int MENU_A = 0; // 右上メニューに対しての値
    private static final int MENU_B = 1;

	public void onCreate(Bundle savedInstanceState) {
		setTheme(R.style.my_theme);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_home);
		
		menu_key = getIntent().getIntExtra("menu_key",0);

		bt1 = (ImageButton)findViewById(R.id.imageButton1);
		bt2 = (ImageButton)findViewById(R.id.imageButton2);
		bt3 = (ImageButton)findViewById(R.id.imageButton3);
		bt4 = (ImageButton)findViewById(R.id.imageButton4);
		bt5 = (ImageButton)findViewById(R.id.imageButton5);
		bt6 = (ImageButton)findViewById(R.id.imageButton6);

		bt1.setOnClickListener(new HomeClickListener());
		bt2.setOnClickListener(new HomeClickListener());
		bt3.setOnClickListener(new HomeClickListener());
		bt4.setOnClickListener(new HomeClickListener());
		bt5.setOnClickListener(new HomeClickListener());
		bt6.setOnClickListener(new HomeClickListener());
	}
	
	class HomeClickListener implements OnClickListener{
		public void onClick(View v){
			Intent it;
			if(v == bt1){
				it = new Intent(getApplicationContext(), RomettaNorikae.class);
				it.putExtra("menu_key", menu_key);
			} else if(v == bt2){
				it = new Intent(getApplicationContext(), RomettaSpot.class);
				it.putExtra("menu_key", menu_key);
			} else if(v == bt3){
				it = new Intent(getApplicationContext(), RomettaTimeSchedule.class);
				it.putExtra("menu_key", menu_key);
			} else if(v == bt4){
				it = new Intent(getApplicationContext(), RomettaDesuka.class);
				it.putExtra("menu_key", menu_key);
			} else if(v == bt5){
				it = new Intent(getApplicationContext(), RomettaHowTo.class);
				it.putExtra("menu_key", menu_key);
			} else {
				it = new Intent(getApplicationContext(), RomettaService.class);
				it.putExtra("menu_key", menu_key);
			}
			startActivity(it);
		}
	}
	
    
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		menu_key = i.getIntExtra("menu_key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
			bt1.setImageResource(R.drawable.home_norikae_en);
			bt2.setImageResource(R.drawable.home_spot_en);
			bt3.setImageResource(R.drawable.home_time_en);
			bt4.setImageResource(R.drawable.home_desuca_en);
			bt5.setImageResource(R.drawable.home_howto_en);
			bt6.setImageResource(R.drawable.home_service_en);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("");
			  reload(key);
			  break;
		  case R.id.credit:
			  String html = "<big>Rometta! ver 1.0.1</big>";
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage(Html.fromHtml(html) + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n" 
			    		+ "Rometta!は、とさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。\n"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}
}
