package com.Rometta.Desuka;

public class RomettaDesuka_Zandaka {
      public int remain;

      public RomettaDesuka_Zandaka(){
      }

      public static RomettaDesuka_Zandaka parse(byte[] res, int off) {
          RomettaDesuka_Zandaka self = new RomettaDesuka_Zandaka();
          self.init(res, off);
          return self;
      }

	  private void init(byte[] res, int off) {
	      this.remain  = toInt(res, off, 15,16);
	  }

	  private int toInt(byte[] res, int off, int... idx) {
	      int num = 0;

	      for (int i=0; i<idx.length; i++) {
	          num = num << 8;
	          num += ((int)res[off+i+2]) & 0x0ff;
	      }
	      return num;
	  }

	  public String toString() {
	      String str = Integer.toString(remain);
	      return str;
	  }
}

