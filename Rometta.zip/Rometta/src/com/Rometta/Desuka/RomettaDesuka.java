package com.Rometta.Desuka;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import com.Rometta.R;

import android.app.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.NfcF;
import android.os.*;
import android.content.Intent;
import android.text.Html;
import android.util.Log;
import android.widget.*;

public class RomettaDesuka extends Activity {
	  private PendingIntent mPendingIntent;
	  private NfcAdapter nfcAdapter;
	  private IntentFilter[] mFilters;
	  private String[][] mTechLists;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_desuka);
		setTitle("ですか残高確認");

		this.nfcAdapter = NfcAdapter.getDefaultAdapter(this);
		
        if (this.nfcAdapter == null){
        	new AlertDialog.Builder(RomettaDesuka.this)
			.setTitle("エラー")
		
			.setMessage("お使いの端末にはNFC機能が搭載されていません。")
			.setPositiveButton(
					"OK",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							finish();
						}
					})
			.show();
            return;
        }
        if (!this.nfcAdapter.isEnabled()){
        	new AlertDialog.Builder(RomettaDesuka.this)
			.setTitle("エラー")
			.setMessage("NFC機能が有効になっていません。")
			.setPositiveButton(
					"OK",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							finish();
						}
					})
			.show();
            return;
        }

        mPendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter tech = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
        mFilters = new IntentFilter[] { tech, };
        mTechLists = new String[][] { new String[] { NfcF.class.getName() } };
	}


	public void onNewIntent(Intent paramIntent){
		Tag localTag = null;
		byte[] felicaIDm = new byte[]{0};
		if ((this.nfcAdapter != null) && (this.nfcAdapter.isEnabled()) && (paramIntent.getAction().equals("android.nfc.action.TECH_DISCOVERED"))) {
			localTag = (Tag)paramIntent.getParcelableExtra("android.nfc.extra.TAG");
			if (localTag != null) {
				felicaIDm = localTag.getId();
			}
		}
		felica_analyze(felicaIDm, localTag);
	}

	@Override
    public void onPause() {
            super.onPause();
            if (nfcAdapter != null) {
                    // onPause() で disableForegroundDispatch() をコールすること。
                    nfcAdapter.disableForegroundDispatch(this);
            }
    }

	public void onResume(){
		super.onResume();
	    if ((this.nfcAdapter != null) && (this.nfcAdapter.isEnabled())) {
	      this.nfcAdapter.enableForegroundDispatch(this, mPendingIntent, mFilters, mTechLists);
	    }
	  }

	private void felica_analyze(byte[] IDm, Tag tag_f){
		NfcF nfc = NfcF.get(tag_f);
		try {
			nfc.connect();
			byte[] req = readWithoutEncryption(IDm, 10);

			// カードにリクエスト送信
			byte[] res = nfc.transceive(req);
			nfc.close();
			
			String zandaka = "<font color=#eb6101><big><big>" + parse(res) + "円</big></big></font>";
			
			// 結果を文字列に変換して表示
			new AlertDialog.Builder(RomettaDesuka.this)
			.setTitle("ですか残高")
			.setMessage("ですかカードの残高は\n　　" + Html.fromHtml(zandaka) + " です。")
			.setPositiveButton(
					"OK",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
						}
					})
			.show();
		} catch (Exception e) {
			new AlertDialog.Builder(RomettaDesuka.this)
			.setTitle("エラー")
			.setMessage("ですかカードが読み取れなかったか、ですかカードではありません。")
			.setPositiveButton(
					"OK",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
						}
					})
			.show();
		}
	}

	private byte[] readWithoutEncryption(byte[] idm, int size) throws IOException {
		ByteArrayOutputStream bout = new ByteArrayOutputStream(100);

		bout.write(0);           // データ長バイトのダミー
		bout.write(0x06);        // Felicaコマンド「Read Without Encryption」
		bout.write(idm);         // カードID 8byte
		bout.write(1);           // サービスコードリストの長さ(以下２バイトがこの数分繰り返す)
		bout.write(0x0b);        // 履歴のサービスコード下位バイト
		bout.write(0x00);        // 履歴のサービスコード上位バイト
		bout.write(1);        // ブロック数
		bout.write(0x80);    // ブロックエレメント上位バイト 「Felicaユーザマニュアル抜粋」の4.3項参照
		bout.write(2);       // ブロック番号

		byte[] msg = bout.toByteArray();
		msg[0] = (byte) msg.length; // 先頭１バイトはデータ長
		return msg;
	}
	private String parse(byte[] res) throws Exception {
		// res[0] = データ長
		// res[1] = 0x07
		// res[2〜9] = カードID
		// res[10,11] = エラーコード。0=正常。
		if (res[10] != 0x00) throw new RuntimeException("Felica error.");

		// res[12] = 応答ブロック数
		// res[13+n*16] = 履歴データ。16byte/ブロックの繰り返し。
		int size = res[12];
		String str = "";

    // 個々の履歴の解析。
		RomettaDesuka_Zandaka rireki = RomettaDesuka_Zandaka.parse(res, 13);
		str += rireki.toString();

		return str;
	}
	private String toHex(byte[] id) {
		StringBuilder sbuf = new StringBuilder();
		for (int i = 0; i < id.length; i++) {
			String hex = "0" + Integer.toString((int) id[i] & 0x0ff, 16);
			if (hex.length() > 2)
				hex = hex.substring(1, 3);
			sbuf.append(" " + i + ":" + hex);
		}
		return sbuf.toString();
	}
}
