package com.Rometta.Spot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import com.Rometta.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

public class RomettaSpot_Result extends Activity {
	int count, menu_key;
	String[][] spot_data;
	String user_lat, user_lng, api;
	RomettaSpot_CustomData[] datas;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_spot_result);
		setTitle("検索結果");
		menu_key = (Integer) getIntent().getExtras().get("menu_key");

		//スポットデータ・ユーザの位置を取得
        @SuppressWarnings("unchecked")
		TreeMap <Integer, String> Spot =  new  TreeMap <Integer, String>((Map<Integer, String>)getIntent().getExtras().get("SpotData"));
        user_lat = new String((String)getIntent().getExtras().get("UserLat"));
	    user_lng = new String((String)getIntent().getExtras().get("UserLng"));
	    String user_station = new String((String)getIntent().getExtras().get("UserStation"));
	    api = new String((String)getIntent().getExtras().get("API"));
	    Log.i("api", api);

	    TextView tv_moyori = (TextView)findViewById(R.id.text_start_name);
	    tv_moyori.setText(user_station);

	    //スポットデータを表形式で格納する2次元配列spot_data
	    spot_data = new String[10][10];	//ちょっと余分に確保してます
	    for (int spot_count : Spot.keySet()) {
		    String[] analyzedSpotData = spotDataAnalyze(Spot.get(spot_count));
		    count++;
		    for (int i = 0; i < analyzedSpotData.length; i++) {
		    	spot_data[spot_count - 1][i] = analyzedSpotData[i];
		    }
	    }

        // リソースに準備した画像ファイルからBitmapを作成しておく
	    Bitmap[] images = new Bitmap[10];
        Bitmap image1 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_one);
        Bitmap image2 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_two);
        Bitmap image3 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_three);
        Bitmap image4 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_four);
        Bitmap image5 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_five);
        Bitmap image6 = BitmapFactory.decodeResource(getResources(), R.drawable.spot_six);
        Bitmap image7 = BitmapFactory.decodeResource(getResources(), R.drawable.spot_seven);
        Bitmap image8 = BitmapFactory.decodeResource(getResources(), R.drawable.spot_eight);
        Bitmap image9 = BitmapFactory.decodeResource(getResources(), R.drawable.spot_nine);
        Bitmap image10 = BitmapFactory.decodeResource(getResources(), R.drawable.spot_ten);


        images[0] = image1;
        images[1] = image2;
        images[2] = image3;
        images[3] = image4;
        images[4] = image5;
        images[5] = image6;
        images[6] = image7;
        images[7] = image8;
        images[8] = image9;
        images[9] = image10;


     // リストの作成
        List<RomettaSpot_CustomData> objects = new ArrayList<RomettaSpot_CustomData>();
        datas = new RomettaSpot_CustomData[count];
        for (int i = 0; i < count; i++) {
        	datas[i] = new RomettaSpot_CustomData();
        	datas[i].setImageData(images[i]);
        	datas[i].setTextData(spot_data[i][0]);
        	datas[i].setTextData2(spot_data[i][3]);
        	objects.add(datas[i]);
        }

        if (count == 0) {
        	TextView tv_result_top = (TextView)findViewById(R.id.tv_result_top);
        	tv_result_top.setText("スポットが見つかりませんでした");
        }

        RomettaSpot_CustomAdapter customAdapter = new RomettaSpot_CustomAdapter(this, 0, objects);

        // リストビューにデータを設定
        ListView listView1 = (ListView)findViewById(R.id.result_list);
        listView1.setAdapter(customAdapter);

        //リストビューのitemをクリックした時の画面遷移処理
        listView1.setOnItemClickListener (new AdapterView.OnItemClickListener() {
        	double goal_lat, goal_lng;
        	String name, category, address, tel, opentime, holiday, url;
        	@Override
        	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        		ListView listView = (ListView)parent;
        		String store_name = datas[position].getTextData();
        		Log.i("SelectedItem", store_name);
        		Log.i("Position", Integer.toString(position));

        		//APIの種類によって情報を格納
        		if (api.equals("g")) {
        			goal_lat = Double.parseDouble(spot_data[position][1]);
        			goal_lng = Double.parseDouble(spot_data[position][2]);
        			name = spot_data[position][0];
        			category = spot_data[position][3];
        			url = spot_data[position][4];
        			address = spot_data[position][5];
        			tel = spot_data[position][6];
        			opentime = spot_data[position][7];
        			holiday = spot_data[position][8];

        		} else if (api.equals("y")) {
        			goal_lat = Double.parseDouble(spot_data[position][2]);
        			goal_lng = Double.parseDouble(spot_data[position][1]);
        			name = spot_data[position][0];
        			category = spot_data[position][5];
        			address = spot_data[position][3];
        			tel = spot_data[position][4];
        			url = spot_data[position][6];
        		}

        		if (opentime == null || opentime.length() == 0) {
        			opentime = "No data";
        		}
        		if (holiday == null || holiday.length() == 0) {
        			holiday = "No data";
        		}
        		if (url == null || url.length() == 0) {
        			url = "No data";
        		}

        		Log.i("goal_lat", Double.toString(goal_lat));
        		Log.i("goal_lng", Double.toString(goal_lng));

        		goal_lat = exchangeLat(goal_lat, goal_lng);
        		goal_lng = exchangeLng(goal_lat, goal_lng);

        		Intent it = new Intent(RomettaSpot_Result.this, RomettaSpot_ResultDetail.class);

        		//選択したスポットデータ・ポジション・ユーザの緯度経度・目的地の緯度経度・APIの種類を遷移先に渡す
        		it.putExtra("Name", name);
        		it.putExtra("Category", category);
        		it.putExtra("Address", address);
        		it.putExtra("Tel", tel);
        		it.putExtra("Opentime", opentime);
        		it.putExtra("Holiday", holiday);
        		it.putExtra("Url", url);
        		it.putExtra("Start_lat", Double.parseDouble(user_lat));
        		it.putExtra("Start_lng", Double.parseDouble(user_lng));
        		it.putExtra("Goal_lat", goal_lat);
        		it.putExtra("Goal_lng", goal_lng);
        		it.putExtra("API", api);
        		it.putExtra("menu_key", menu_key);

        		startActivity(it);
        	}
        });
	}

	//緯度経度を世界測地系に変換する
	double exchangeLat(double lat_t, double lng_t) {
		double lat_w = lat_t - lat_t * 0.00010695 + lng_t * 0.000017464 + 0.0046017;
		return lat_w;
	}
	double exchangeLng(double lat_t, double lng_t) {
		double lng_w = lng_t - lat_t * 0.000046038 - lng_t * 0.000083043 + 0.010040;
		return lng_w;
	}

	//スポットデータ配列1行分を「,」で分解する
	String[] spotDataAnalyze (String spotData) {
		String[] analyzedSpotData = spotData.split(",");
		return analyzedSpotData;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		int menu_key = i.getIntExtra("menu_key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("");
			  reload(key);
			  break;
		  case R.id.credit:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage("Rometta! ver 1.0.1" + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n"
			    		+ "Rometta!はとさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}
}
