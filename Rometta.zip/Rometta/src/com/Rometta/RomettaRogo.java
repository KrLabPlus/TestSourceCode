package com.Rometta;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;

/*
 * ロゴ画面のでの様々な機能を設定している
 */
public class RomettaRogo extends Activity{
	Button bt1;

	public void onCreate(Bundle savedInstanceState) {
		setTheme(R.style.my_theme);
		getActionBar().hide();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_rogo);

		// 一定時間(ここでは2秒)後に遷移する処理
		new Handler().postDelayed(new Runnable() {
            public void run() {
            	Intent it = new Intent(getApplicationContext(), RomettaHome.class);
                startActivity(it);

                // アクティビティを終了させることで、スプラッシュ画面に戻ることを防ぐ。
                RomettaRogo.this.finish();
            }
        }, 1800);
    }
}