package com.Rometta.Service;

import java.util.Locale;

import com.Rometta.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class RomettaService_Teiki  extends Activity implements OnClickListener{
	int menu_key;
	private ImageButton btn1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_service_teiki);
		setTitle("路面電車定期券");
		menu_key = (Integer) getIntent().getExtras().get("menu_key");
	    btn1 = (ImageButton)findViewById(R.id.more_teiki);
	    btn1.setOnClickListener(this);

	}


	@Override
    public void onClick(View v) {
		if(v == btn1){
			Intent link_teiki = new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.tosaden.co.jp/train/ic.php"));
			startActivity(link_teiki);
		}
    }
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		int menu_key = i.getIntExtra("menu_key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("it");
			  reload(key);
			  break;
		  case R.id.credit:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage("Rometta! ver 1.0.1" + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n" 
			    		+ "Rometta!はとさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}
}