package com.Rometta.HowTo;

import java.util.Locale;

import com.Rometta.R;

import android.app.*;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class RomettaHowTo_Desuka extends Activity implements OnClickListener {
	int menu_key;
	private Button desuka_menu1, desuka_menu2, desuka_menu3, top1;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_howto_desuka);
		setTitle(R.string.title_howto_desuka);
		menu_key = (Integer) getIntent().getExtras().get("menu_key");

		desuka_menu1 = (Button)findViewById(R.id.desuka_menu1);
		desuka_menu2 = (Button)findViewById(R.id.desuka_menu2);
		desuka_menu3 = (Button)findViewById(R.id.desuka_menu3);
		top1 = (Button)findViewById(R.id.back1);


		desuka_menu1.setOnClickListener(this);
		desuka_menu2.setOnClickListener(this);
		desuka_menu3.setOnClickListener(this);
		top1.setOnClickListener(this);

	}

	public void onClick(View view) {
		if(view == desuka_menu1) {
			ImageView desukaImage1  = (ImageView)findViewById(R.id.desuka_image);
			ImageView norioriImage1 = (ImageView)findViewById(R.id.desuka_touch);
			ImageView norioriImage2 = (ImageView)findViewById(R.id.desuka_touch2);
			desukaImage1.setImageResource(R.drawable.howto_desuka_use);
			norioriImage1.setImageResource(R.drawable.howto_desuka_touch);
			norioriImage2.setImageResource(R.drawable.howto_desuka_touch2);
			TextView desukaCheck1 = (TextView)findViewById(R.id.text1);
			TextView desukaCheck2 = (TextView)findViewById(R.id.text2);
			desukaCheck1.setText(getResources().getString(R.string.desuka_noriori1));
			desukaCheck2.setText(getResources().getString(R.string.desuka_noriori2));
		}

		if(view == desuka_menu2) {
			ImageView desukaImage2  = (ImageView)findViewById(R.id.desuka_image);
			ImageView checkImage1   = (ImageView)findViewById(R.id.desuka_touch);
			ImageView checkImage2   = (ImageView)findViewById(R.id.desuka_touch2);
			desukaImage2.setImageResource(R.drawable.howto_zandaka);
			checkImage1.setImageResource(R.drawable.howto_zandaka_check1);
			checkImage2.setImageResource(R.drawable.howto_zandaka_check2);
			TextView desukaCheck1 = (TextView)findViewById(R.id.text1);
			TextView desukaCheck2 = (TextView)findViewById(R.id.text2);
			desukaCheck1.setText(getResources().getString(R.string.desuka_check1));
			desukaCheck2.setText(getResources().getString(R.string.desuka_check2));
		}

		if(view == desuka_menu3) {
			ImageView desukaImage3 = (ImageView)findViewById(R.id.desuka_image);
			ImageView chargeImage1 = (ImageView)findViewById(R.id.desuka_touch);
			ImageView chargeImage2 = (ImageView)findViewById(R.id.desuka_touch2);
			desukaImage3.setImageResource(R.drawable.howto_charge);
			chargeImage1.setImageResource(R.drawable.howto_desuka_charge);
			chargeImage2.setImageResource(R.drawable.howto_desuka_charge2);

			TextView desukaCharge1 = (TextView)findViewById(R.id.text1);
			TextView desukaCharge2 = (TextView)findViewById(R.id.text2);
			desukaCharge1.setText(getResources().getString(R.string.desuka_charge1));
			desukaCharge2.setText(getResources().getString(R.string.desuka_charge2));

		}

		if(view == top1) {
		final ScrollView back1 = (ScrollView)findViewById(R.id.desuka_scroll);
		back1.post(new Runnable() {
			public void run() {
				back1.scrollTo(0, back1.getTop());
			}
		});
		}

	}

	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		int menu_key = i.getIntExtra("menu_key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("");
			  reload(key);
			  break;
		  case R.id.credit:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage("Rometta! ver 1.0.1" + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n"
			    		+ "Rometta!はとさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}


}
