package com.Rometta.Norikae;

import java.io.*;
import java.net.*;
import java.util.*;

import com.Rometta.R;
import com.Rometta.HowTo.RomettaHowTo_Desuka;
import com.Rometta.HowTo.RomettaHowTo_Norikae;

import org.json.JSONObject;

import android.app.*;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.*;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.*;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

import com.google.android.gms.maps.*;
import com.google.android.gms.maps.GoogleMap.*;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.*;

public class RomettaNorikae_ResultRoute extends Activity{
	int menu_key;
	GoogleMap gMap;
    Intent it;
    LatLng point;
    int cost, norikae;
    String from_time, from_station, to_time, to_station;
    TextView tv, tv2, tv3, tv4, tv5, tv6, tv7, tv8, tv9, tv10;


    // 経由地点用のパラメータをここで設定しておく(if文で繰り返し使用)
    private static final String HARIMAYA_LATLNG = "33.559536,133.542854";
    private static final double HORIDUME_LNG = 133.539313;      // 堀詰の経度(少し東寄り)
    private static final double UMENOTUJI_LAT = 33.554587;      // 梅の辻の緯度(少し北寄り)
    private static final double DENTETSU_LNG = 133.543926;      // デンテツの経度(少し西寄り)

    public static String posinfo = "";
    public static String info_A = "";
    public static String info_B = "";
    ArrayList<LatLng> markerPoints;

    public static MarkerOptions options1;
    public static MarkerOptions options2;

    public ProgressDialog progressDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rometta_norikae_result_route);
        setTitle("ルート詳細");

        tv = (TextView)findViewById(R.id.from_station);
        tv2 = (TextView)findViewById(R.id.from_time);
        tv3 = (TextView)findViewById(R.id.noriba);
        tv4 = (TextView)findViewById(R.id.cost);
        tv5 = (TextView)findViewById(R.id.seiriken);
        tv6 = (TextView)findViewById(R.id.to_station);
        tv7 = (TextView)findViewById(R.id.to_time);
        tv8 = (TextView)findViewById(R.id.oriba);
        tv9 = (TextView)findViewById(R.id.HowToIntent);


        //プログレス(読み込み中にクルクルまわるやつ)
        progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage("ルート検索中...");
        progressDialog.hide();

        //初期化
        markerPoints = new ArrayList<LatLng>();

        MapFragment mapfragment = (MapFragment)getFragmentManager().findFragmentById(R.id.map);
        gMap = mapfragment.getMap();
        if (gMap != null) {
        	gMap.getUiSettings().setZoomControlsEnabled(true);
        }

        it = getIntent();
        //menu_keyを受け取る
      	menu_key = (Integer) getIntent().getExtras().get("menu_key");

        from_time = it.getStringExtra("FROM_TIME");
        to_time = it.getStringExtra("TO_TIME");
        from_station = it.getStringExtra("FROM_STATION");
        to_station = it.getStringExtra("TO_STATION");

        cost = it.getIntExtra("COST", 0);
        norikae = it.getIntExtra("NORIKAE", 0);

        tv.setText(from_station);
        tv2.setText(from_time);
        tv4.setText("(大人)"+ cost + "円");
        tv6.setText(to_station);
        tv7.setText(to_time);

        // データテーブルに「高知駅前」、「桟橋通五丁目」、「鏡川橋」しかないから間に合わせの条件分岐
        if(from_station.equals("高知駅前")){
        	tv3.setText("１番のりば");
        } else if(from_station.equals("鏡川橋")){
        	tv3.setText("北側のりば");
        } else {
        	tv3.setText("西側のりば");
        }

        if(to_station.equals("高知駅前")){
        	tv8.setText("１番のりば");
        } else if(to_station.equals("鏡川橋")){
        	tv8.setText("南側のりば");
        } else {
        	tv8.setText("東側のりば");
        }


        if(norikae == 1){
        	tv9.setClickable(true);
        	tv9.setOnClickListener(new OnClickListener() {
        		public void onClick(View v) {
        			Intent it_how = new Intent(getApplicationContext(), RomettaHowTo_Norikae.class);
        			it_how.putExtra("menu_key", menu_key);
        			startActivity(it_how);
        		}
        	});
        } else {
        	tv9.setText("");
        }


        // 出発地のマーカー設置
        point = new LatLng(it.getDoubleExtra("FROM_LAT", 0), it.getDoubleExtra("FROM_LNG", 0));
        markerPoints.add(point);

        options1 = new MarkerOptions();
        options1.position(point);
        options1.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        options1.title("出発地");

        // 到着地のマーカー設置
        point = new LatLng(it.getDoubleExtra("TO_LAT", 0), it.getDoubleExtra("TO_LNG", 0));
        markerPoints.add(point);

        options2 = new MarkerOptions();
        options2.position(point);
        options2.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        options2.title("到着地");

        gMap.addMarker(options1);
        gMap.addMarker(options2);

        LatLng location = new LatLng(it.getDoubleExtra("FROM_LAT", 0), it.getDoubleExtra("FROM_LNG", 0));
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 14));

        // ルート検索
        routeSearch();

        gMap.setOnMarkerClickListener(new OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
            	String title = marker.getTitle();
            	if (title.equals("出発地")){
            		marker.setSnippet(info_A);
            	}else if (title.equals("到着地")){
            		marker.setSnippet(info_B);
            	}
            	return false;
            }
        });
    }

    // ルート検索メソッド
    private void routeSearch(){
        progressDialog.show();

        LatLng origin = markerPoints.get(0);
        LatLng dest = markerPoints.get(1);

        // GoogleDirectionsAPI からURL取得
        String url = getDirectionsUrl(origin, dest);

        downloadTask downloadTask = new downloadTask();

        downloadTask.execute(url);
    }

    private String getDirectionsUrl(LatLng origin,LatLng dest){

    	double ori_lat = origin.latitude;
    	double ori_lng = origin.longitude;

    	double des_lat = dest.latitude;
    	double des_lng = dest.longitude;

    	// スタート地点の緯度・経度を指定
        String str_origin = "origin="+origin.latitude+","+origin.longitude;

        // ゴール地点の緯度・経度を指定
        String str_dest = "destination="+dest.latitude+","+dest.longitude;

        // GPSを使うか否か
        String sensor = "sensor=false";

        //JSON指定(帰ってくるデータの形式の指定)
        String output = "json";

        // parametersの宣言(これで条件を指定)
        String parameters = null;

        if(ori_lng < HORIDUME_LNG && des_lng < HORIDUME_LNG){                    // 出発と到着が西側で完結
        	//ここに西側部分のみの処理
        	if(ori_lng < 133.498342 && des_lng < 133.498342){                    // 出発と到着が鏡川橋(33.555623,133.498342)より西
        		if(ori_lng < 133.496635 && des_lng < 133.496635){                // 出発と到着が鴨部(33.552162,133.496794)より西
            		if(ori_lng < 133.4297618 && des_lng < 133.4297618){          // 出発と到着が鳴谷より西
            			parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
            		} else if(ori_lng < 133.4297618 || des_lng < 133.4297618){
            			// 伊野駅前(33.548486,133.430408)を経由地
            			parameters = str_origin+"&"+str_dest+"&waypoints=33.548486,133.430408&"+sensor+"&language=ja"+"&mode=driving";
            		} else {
            			parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
            		}
        		} else {
        			parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
        		}
        	} else if(ori_lng < 133.498342 || des_lng < 133.498342){                 // 出発か到着のどちらかが鏡川橋より西
        		if(ori_lng < 133.496635 || des_lng < 133.496635){                    // 出発か到着のどちらかが鴨部より西
            		if(ori_lng < 133.4297618 || des_lng < 133.4297618){              // 出発か到着のどちらかが鳴谷より西
            			parameters = str_origin+"&"+str_dest+"&waypoints=optimize:true|33.552162,133.496794|33.548486,133.430408|33.555372,133.502993" +"&"+sensor+"&language=ja"+"&mode=driving";
            			//伊野駅前、鴨部、蛍橋を経由地に追加した処理
            		} else {
            			parameters = str_origin+"&"+str_dest+"&waypoints=optimize:true|33.552162,133.496794|33.552503,133.498277&"+sensor+"&language=ja"+"&mode=driving";
            			//鴨部を経由地に追加した処理
            		}
        		} else {
        			if(ori_lng < 133.498277 || des_lng < 133.498277){
        				parameters = str_origin+"&"+str_dest+"&waypoints=33.552503,133.498277&"+sensor+"&language=ja"+"&mode=driving";
        			} else {
        				parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
        			}
        		}
        	} else {
        		parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
        	}
        } else if(ori_lng > HORIDUME_LNG && des_lng > HORIDUME_LNG && ori_lat <= UMENOTUJI_LAT && des_lat <= UMENOTUJI_LAT){     // 出発と到着が南側で完結

        	parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";

        } else if(ori_lng > HORIDUME_LNG && des_lng > HORIDUME_LNG && ori_lat > UMENOTUJI_LAT && des_lat > UMENOTUJI_LAT){
        	if(ori_lng > DENTETSU_LNG && des_lng > DENTETSU_LNG){                                                                // 出発と到着が東側で完結

        		if(ori_lng > 133.614197 && des_lng > 133.614197){                  // 出発と到着が一条橋(33.574841,133.614096)より東
        			parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
        		} else if(ori_lng > 133.614197 || des_lng > 133.614197){           // 出発か到着のどちらかが一条橋(33.574841,133.614096)より東
               		//一条橋(33.574841,133.614096)を経由地に追加した処理
        			parameters = str_origin+"&"+str_dest+"&waypoints=33.574841,133.614096&"+sensor+"&language=ja"+"&mode=driving";
               	} else {
               		parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
               	}
        	} else if(ori_lng <= DENTETSU_LNG && des_lng <= DENTETSU_LNG){                                                       // 出発と到着が北側で完結

        		//高知駅前の開始地点を少し南にずらさなければ綺麗に表示できない(DB登録時におまかせ)
        		parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
        	} else{
        		parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=driving";
        	}
        } else { // 出発か到着がはりまや橋より東側にある場合
        	if(ori_lng < 133.498342 || des_lng < 133.498342){                        // 出発か到着のどちらかが鏡川橋(33.555623,133.498342)より西
        		if(ori_lng < 133.496635 || des_lng < 133.496635){                    // 出発か到着のどちらかが鴨部(33.552162,133.496794)より西
            		if(ori_lng < 133.4297618 || des_lng < 133.4297618){              // 出発か到着のどちらかが鳴谷より西
            			if(ori_lng > 133.614197 || des_lng > 133.614197){            // 出発か到着のどちらかが一条橋(33.574841,133.614096)より東
            				//伊野駅前、鴨部、蛍橋、はりまや橋、一条橋を経由地に追加した処理
            				parameters = str_origin+"&"+str_dest+"&waypoints=optimize:true|33.552162,133.496794|33.552503,133.498277|33.574841,133.614096|33.548486,133.430408|"+HARIMAYA_LATLNG +"&"+sensor+"&language=ja"+"&mode=driving";
            			} else {
            				//伊野駅前(33.548486,133.430408)、鴨部、蛍橋はりまや橋を経由地に追加した処理
            				parameters = str_origin+"&"+str_dest+"&waypoints=optimize:true|33.552162,133.496794|33.548486,133.430408|33.552503,133.498277|"+HARIMAYA_LATLNG +"&"+sensor+"&language=ja"+"&mode=driving";
            			}
            		} else {
            			//鴨部、蛍橋、はりまや橋を経由地に追加した処理
            			parameters = str_origin+"&"+str_dest+"&waypoints=optimize:true|33.552503,133.498277|33.552162,133.496794|"+HARIMAYA_LATLNG +"&"+sensor+"&language=ja"+"&mode=driving";
            		}
        		} else {
        			//蛍橋、はりまや橋を経由地に追加した処理
        			parameters = str_origin+"&"+str_dest+"&waypoints=optimize:true|33.552503,133.498277|"+HARIMAYA_LATLNG +"&"+sensor+"&language=ja"+"&mode=driving";
        		}
        	} else if(ori_lng > 133.614197 || des_lng > 133.614197){
        		parameters = str_origin+"&"+str_dest+"&waypoints=optimize:true|"+HARIMAYA_LATLNG +"|33.574841,133.614096"+"&"+sensor+"&language=ja"+"&mode=driving";
        	} else {
        		parameters = str_origin+"&"+str_dest+"&waypoints="+HARIMAYA_LATLNG+"&"+sensor+"&language=ja"+"&mode=driving";
        	}
        }
        String url = "https://maps.googleapis.com/maps/api/directions/"+output+"?"+parameters;
        return url;
    }

    private String downloadUrl(String strUrl) throws IOException{
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try{
            URL url = new URL(strUrl);

            urlConnection = (HttpURLConnection) url.openConnection();

            urlConnection.connect();

            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();

            String line = "";
            while( ( line = br.readLine()) != null){
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        }catch(Exception e){
            Log.d("Exception while downloading url", e.toString());
        }finally{
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    private class downloadTask extends AsyncTask<String, Void, String>{
    //非同期で取得
        @Override
        protected String doInBackground(String... url) {

            String data = "";
            try{
                // Fetching the data from web service
                data = downloadUrl(url[0]);
            }catch(Exception e){
                Log.d("Background Task",e.toString());
            }
            return data;
        }

        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            parserTask parserTask = new parserTask();

            parserTask.execute(result);
        }
    }

    // JSON形式で帰ってきたデータを解析
    private class parserTask extends AsyncTask<String, Integer, List<List<HashMap<String,String>>> >{

        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {
            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try{
                jObject = new JSONObject(jsonData[0]);
                RomettaNorikae_ParseJsonpOfDirectionAPI parser = new RomettaNorikae_ParseJsonpOfDirectionAPI();

                routes = parser.parse(jObject);
            }catch(Exception e){
                e.printStackTrace();
            }
            return routes;
        }

        //ルート検索で得た座標を使って経路表示
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {

            ArrayList<LatLng> points = null;
            PolylineOptions lineOptions = null;

            if(result.size() != 0){
                for(int i=0;i<result.size();i++){
                    points = new ArrayList<LatLng>();
                    lineOptions = new PolylineOptions();

                    List<HashMap<String, String>> path = result.get(i);

                    for(int j=0;j<path.size();j++){
                        HashMap<String,String> point = path.get(j);

                        double lat = Double.parseDouble(point.get("lat"));
                        double lng = Double.parseDouble(point.get("lng"));
                        LatLng position = new LatLng(lat, lng);

                        points.add(position);
                    }
                    //ポリライン
                    lineOptions.addAll(points);
                    lineOptions.width(15);
                    lineOptions.color(0x550000ff);
                }
                //描画
                gMap.addPolyline(lineOptions);
            }else{
                gMap.clear();
                Toast.makeText(RomettaNorikae_ResultRoute.this, "ルート情報を取得できませんでした", Toast.LENGTH_LONG).show();
            }
            progressDialog.hide();
        }
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		int menu_key = i.getIntExtra("menu_key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("");
			  reload(key);
			  break;
		  case R.id.credit:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage("Rometta! ver 1.0.1" + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n"
			    		+ "Rometta!はとさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}
}
