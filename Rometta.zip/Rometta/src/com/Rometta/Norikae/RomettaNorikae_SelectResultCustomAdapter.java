package com.Rometta.Norikae;

import java.util.List;

import com.Rometta.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class RomettaNorikae_SelectResultCustomAdapter extends ArrayAdapter<RomettaNorikae_SelectResultCustomData> {
	 private LayoutInflater layoutInflater_;

	 public RomettaNorikae_SelectResultCustomAdapter(Context context, int textViewResourceId, List<RomettaNorikae_SelectResultCustomData> objects) {
		 super(context, textViewResourceId, objects);
		 layoutInflater_ = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	 }

	 @Override
	 public View getView(int position, View convertView, ViewGroup parent) {
	 // 特定の行(position)のデータを得る
		 RomettaNorikae_SelectResultCustomData item = (RomettaNorikae_SelectResultCustomData)getItem(position);

	 // convertViewは使い回しされている可能性があるのでnullの時だけ新しく作る
		 if (null == convertView) {
			 convertView = layoutInflater_.inflate(R.layout.activity_rometta_norikae_custom_layout, null);
		 }

	 // CustomDataのデータをViewの各Widgetにセットする
		 ImageView imageView;
		 imageView = (ImageView)convertView.findViewById(R.id.image_number);
		 imageView.setImageBitmap(item.getImageData());

		 TextView textView;
		 textView = (TextView)convertView.findViewById(R.id.from_to_time);
		 textView.setText(item.getTextData());

		 TextView textView2;
		 textView2 = (TextView)convertView.findViewById(R.id.all_time);
		 textView2.setText(item.getTextData2());

		 TextView textView3;
		 textView3 = (TextView)convertView.findViewById(R.id.cost_view);
		 textView3.setText(item.getTextData3());

		 TextView textView4;
		 textView4 = (TextView)convertView.findViewById(R.id.norikae_umu);
		 textView4.setText(item.getTextData4());

		 TextView textView5;
		 textView5 = (TextView)convertView.findViewById(R.id.seiriken_umu);
		 textView5.setText(item.getTextData5());

		 return convertView;
	 }
}