package com.Rometta.Spot;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.Rometta.R;
import com.Rometta.Spot.CustomAdapter;
import com.Rometta.Spot.CustomData;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

public class RomettaSpotResult extends Activity {
	int count;
	String[][] spot_data;
	String user_lat, user_lng, api;
	CustomData[] datas;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_spot_search_result_page);
		
		//スポットデータ・ユーザの位置を取得
        @SuppressWarnings("unchecked")
		TreeMap <Integer, String> Spot =  new  TreeMap <Integer, String>((Map<Integer, String>)getIntent().getExtras().get("SpotData"));
        user_lat = new String((String)getIntent().getExtras().get("UserLat"));
	    user_lng = new String((String)getIntent().getExtras().get("UserLng"));
	    String user_station = new String((String)getIntent().getExtras().get("UserStation"));
	    api = new String((String)getIntent().getExtras().get("API"));
	    Log.i("api", api);
	    
	    TextView tv_moyori = (TextView)findViewById(R.id.text_start_name);
	    tv_moyori.setText(user_station);
	    
	    //スポットデータを表形式で格納する2次元配列spot_data
	    spot_data = new String[10][10];	//ちょっと余分に確保してます
	    for (int spot_count : Spot.keySet()) {
		    String[] analyzedSpotData = spotDataAnalyze(Spot.get(spot_count));
		    count++;
		    for (int i = 0; i < analyzedSpotData.length; i++) {
		    	spot_data[spot_count - 1][i] = analyzedSpotData[i];
		    }
	    }

        // リソースに準備した画像ファイルからBitmapを作成しておく
	    Bitmap[] images = new Bitmap[10];
        Bitmap image1 = BitmapFactory.decodeResource(getResources(), R.drawable.one);
        Bitmap image2 = BitmapFactory.decodeResource(getResources(), R.drawable.two);
        Bitmap image3 = BitmapFactory.decodeResource(getResources(), R.drawable.three);
        Bitmap image4 = BitmapFactory.decodeResource(getResources(), R.drawable.four);
        Bitmap image5 = BitmapFactory.decodeResource(getResources(), R.drawable.five);
        Bitmap image6 = BitmapFactory.decodeResource(getResources(), R.drawable.six);
        Bitmap image7 = BitmapFactory.decodeResource(getResources(), R.drawable.seven);
        Bitmap image8 = BitmapFactory.decodeResource(getResources(), R.drawable.eight);
        Bitmap image9 = BitmapFactory.decodeResource(getResources(), R.drawable.nine);
        Bitmap image10 = BitmapFactory.decodeResource(getResources(), R.drawable.ten);

        
        images[0] = image1;
        images[1] = image2;
        images[2] = image3;
        images[3] = image4;
        images[4] = image5;
        images[5] = image6;
        images[6] = image7;
        images[7] = image8;
        images[8] = image9;
        images[9] = image10;
		
        
     // リストの作成
        List<CustomData> objects = new ArrayList<CustomData>();
        datas = new CustomData[count];
        for (int i = 0; i < count; i++) {
        	datas[i] = new CustomData();
        	datas[i].setImageData(images[i]);
        	datas[i].setTextData(spot_data[i][0]);
        	datas[i].setTextData2(spot_data[i][3]);
        	objects.add(datas[i]);
        }
        
        if (count == 0) {
        	TextView tv_result_top = (TextView)findViewById(R.id.tv_result_top);
        	tv_result_top.setText("スポットが見つかりませんでした");
        }
        
        CustomAdapter customAdapter = new CustomAdapter(this, 0, objects);
        
        // リストビューにデータを設定
        ListView listView1 = (ListView)findViewById(R.id.result_list);
        listView1.setAdapter(customAdapter);
        
        //リストビューのitemをクリックした時の画面遷移処理
        listView1.setOnItemClickListener (new AdapterView.OnItemClickListener() {
        	double goal_lat, goal_lng;
        	String name, category, address, tel, opentime, holiday, url;
        	@Override
        	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        		ListView listView = (ListView)parent;
        		String store_name = datas[position].getTextData();
        		Log.i("SelectedItem", store_name);
        		Log.i("Position", Integer.toString(position));
        		
        		//APIの種類によって情報を格納
        		if (api.equals("g")) {
        			goal_lat = Double.parseDouble(spot_data[position][1]);
        			goal_lng = Double.parseDouble(spot_data[position][2]);
        			name = spot_data[position][0];
        			category = spot_data[position][3];
        			url = spot_data[position][4];
        			address = spot_data[position][5];
        			tel = spot_data[position][6];
        			opentime = spot_data[position][7];
        			holiday = spot_data[position][8];
        			
        		} else if (api.equals("y")) {
        			goal_lat = Double.parseDouble(spot_data[position][2]);
        			goal_lng = Double.parseDouble(spot_data[position][1]);
        			name = spot_data[position][0];
        			category = spot_data[position][5];
        			address = spot_data[position][3];
        			tel = spot_data[position][4];
        			url = spot_data[position][6];
        		}
        		
        		if (opentime == null || opentime.length() == 0) {
        			opentime = "No data";
        		}
        		if (holiday == null || holiday.length() == 0) {
        			holiday = "No data";
        		}
        		if (url == null || url.length() == 0) {
        			url = "No data";
        		}
        		
        		Log.i("goal_lat", Double.toString(goal_lat));
        		Log.i("goal_lng", Double.toString(goal_lng));
        		
        		Intent it = new Intent(RomettaSpotResult.this, RomettaSpotResultDetail.class);
        
        		//選択したスポットデータ・ポジション・ユーザの緯度経度・目的地の緯度経度・APIの種類を遷移先に渡す
        		it.putExtra("Name", name);
        		it.putExtra("Category", category);
        		it.putExtra("Address", address);
        		it.putExtra("Tel", tel);
        		it.putExtra("Opentime", opentime);
        		it.putExtra("Holiday", holiday);
        		it.putExtra("Url", url);
        		it.putExtra("Start_lat", Double.parseDouble(user_lat));
        		it.putExtra("Start_lng", Double.parseDouble(user_lng));
        		it.putExtra("Goal_lat", goal_lat);
        		it.putExtra("Goal_lng", goal_lng);
        		it.putExtra("API", api);
        	 
        		startActivity(it);
        	}
        });
	}

	//スポットデータ配列1行分を「,」で分解する
	String[] spotDataAnalyze (String spotData) {
		String[] analyzedSpotData = spotData.split(",");
		return analyzedSpotData;
	}
	

}