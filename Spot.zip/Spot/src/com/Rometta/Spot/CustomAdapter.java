package com.Rometta.Spot;

import java.util.List;

import com.Rometta.R;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends ArrayAdapter<CustomData> {
	protected static int MAX_FONT_SIZE = 20;
	protected static int MIN_FONT_SIZE = 5;
	private LayoutInflater layoutInflater_;
	 
	 public CustomAdapter(Context context, int textViewResourceId, List<CustomData> objects) {
		 super(context, textViewResourceId, objects);
		 layoutInflater_ = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	 }
	 
	 @Override
	 public View getView(int position, View convertView, ViewGroup parent) {
		 // 特定の行(position)のデータを得る
		 CustomData item = (CustomData)getItem(position);
	 
		 // convertViewは使い回しされている可能性があるのでnullの時だけ新しく作る
		 if (null == convertView) {
			 convertView = layoutInflater_.inflate(R.layout.custom_layout, null);
		 }
	 
		 // CustomDataのデータをViewの各Widgetにセットする
		 ImageView imageView;
		 imageView = (ImageView)convertView.findViewById(R.id.image_number);
		 imageView.setImageBitmap(item.getImageData());
	 
		 TextView textView;
		 textView = (TextView)convertView.findViewById(R.id.store_name);
		 //setMaxTextSize(item.getTextData(), textView);
		 textView.setText(item.getTextData());
	 
		 TextView textView2;
		 textView2 = (TextView)convertView.findViewById(R.id.store_detail);
		 //setMaxTextSize(item.getTextData2(), textView2);
		 textView2.setText(item.getTextData2());
	 
		 return convertView;
	 }
	 
/*		//TextViewに収まるように、フォントサイズを変更する
		private void setMaxTextSize(String str, TextView tv) {
			WindowManager wm = (WindowManager)this.getContext().getSystemService(Context.WINDOW_SERVICE);
	        DisplayMetrics metrics = new DisplayMetrics(); 
	        Display display = wm.getDefaultDisplay();
	        display.getMetrics(metrics);
	        final float density = metrics.scaledDensity;
	        
	        Paint p = new Paint();
	        
	        MAX_FONT_SIZE = (int) (tv.getWidth() / density);
			MIN_FONT_SIZE = (int) (tv.getWidth() / density);

	        for (int i = MAX_FONT_SIZE; i > MIN_FONT_SIZE; i = i - 2) {
	            p.setTextSize(i); //ここでPaintにテキストサイズを指定する
	            float width = tv.getWidth() / density; //Dip単位に変換します
	 
	            if ((width >= p.measureText(str))) {
	                tv.setText(str);
	                int size = (int) (i - (3 * density));
	                tv.setTextSize(size);
	                break;
	            }
	        }
	    }
	    */
}

