package ya.Sample;

import android.app.*;
import android.content.Intent;
import android.os.*;
import android.view.*;
import android.view.View.OnClickListener;
import android.widget.*;

public class testDirections extends Activity{
	Button bt;

	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout ll = new LinearLayout(this);
		ll.setOrientation(LinearLayout.VERTICAL);
		setContentView(ll);

        bt = new Button(this);
        bt.setText("����");
        ll.addView(bt);

        bt.setOnClickListener(new searchClickListener());
	}

	class searchClickListener implements OnClickListener{
		public void onClick(View v){
			Intent it = new Intent(getApplicationContext(), transitRouteSearch.class);
			double start_lat = 33.552162;
			double start_lng = 133.496794;
			double goal_lat = 33.574841;
			double goal_lng = 133.614096;
			it.putExtra("Start_lat", start_lat);
			it.putExtra("Start_lng", start_lng);
			it.putExtra("Goal_lat", goal_lat);
			it.putExtra("Goal_lng", goal_lng);
			startActivity(it);
		}
	}
}