/** Automatically generated file. DO NOT MODIFY */
package ya.Sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}