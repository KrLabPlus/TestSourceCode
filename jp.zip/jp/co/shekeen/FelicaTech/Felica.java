// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;

import android.content.Intent;
import android.nfc.Tag;
import android.nfc.tech.NfcF;
import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import jp.co.shekeen.BalanceReaderFree.DebugHelper;

public class Felica
{

    private Felica(NfcF nfcf)
    {
        mTimeoutEnabled = false;
        mNfcf = nfcf;
        mIdm = nfcf.getTag().getId();
        mSystemCode = nfcf.getSystemCode();
        mManufacture = nfcf.getManufacturer();
        DebugHelper.print(mIdm);
    }

    private byte[] getFindServiceCodeCommand(int i)
    {
        byte abyte0[] = new byte[2];
        abyte0[0] = (byte)(i & 0xff);
        abyte0[1] = (byte)(i >> 8);
        byte byte0 = (byte)(2 + (mIdm.length + abyte0.length));
        ByteBuffer bytebuffer = ByteBuffer.allocate(byte0);
        bytebuffer.put(byte0).put((byte)10).put(mIdm).put(abyte0);
        return bytebuffer.array();
    }

    private byte[] getGetSystemCodeListCommand()
    {
        byte byte0 = (byte)(2 + mIdm.length);
        ByteBuffer bytebuffer = ByteBuffer.allocate(byte0);
        bytebuffer.put(byte0).put((byte)12).put(mIdm);
        return bytebuffer.array();
    }

    public static Felica getInstance(Intent intent)
    {
        android.os.Parcelable parcelable = intent.getParcelableExtra("android.nfc.extra.TAG");
        NfcF nfcf;
        if(parcelable != null && (parcelable instanceof Tag))
            if((nfcf = NfcF.get((Tag)parcelable)) != null)
                return new Felica(nfcf);
        return null;
    }

    private byte[] getPollSystemCommand(byte byte0, byte byte1)
    {
        byte abyte0[] = new byte[4];
        abyte0[0] = byte0;
        abyte0[1] = byte1;
        abyte0[2] = 1;
        byte byte2 = (byte)(2 + abyte0.length);
        ByteBuffer bytebuffer = ByteBuffer.allocate(byte2);
        bytebuffer.put(byte2).put((byte)0).put(abyte0);
        return bytebuffer.array();
    }

    private int getPollingTimeOut(int i)
    {
        return (int)Math.ceil(10D * (2.4169999999999998D + 1.208D * (double)i));
    }

    private byte[] getReadCommand(byte byte0, byte byte1, byte byte2)
    {
        byte abyte0[] = {
            1, byte0, byte1, 1, -128, byte2
        };
        byte byte3 = (byte)(2 + (mIdm.length + abyte0.length));
        ByteBuffer bytebuffer = ByteBuffer.allocate(byte3);
        bytebuffer.put(byte3).put((byte)6).put(mIdm).put(abyte0);
        return bytebuffer.array();
    }

    private byte[] getRequestResponseCommand()
    {
        byte byte0 = (byte)(2 + mIdm.length);
        ByteBuffer bytebuffer = ByteBuffer.allocate(byte0);
        bytebuffer.put(byte0).put((byte)4).put(mIdm);
        return bytebuffer.array();
    }

    private int getTimeOut(int i, int j)
    {
        while(mManufacture == null || mManufacture.length < 8 || mManufacture[i] == 0) 
            return 255;
        int k = 7 & mManufacture[i];
        int l = (0x38 & mManufacture[i]) >> 3;
        int i1 = (0xc0 & mManufacture[i]) >> 6;
        return (int)Math.ceil(10D * (0.30199999999999999D * (double)(j * (l + 1) + (k + 1)) * Math.pow(4D, i1)));
    }

    public static boolean isFelica(Tag tag)
    {
        String s = android/nfc/tech/NfcF.getCanonicalName();
        String as[] = tag.getTechList();
        int i = as.length;
        int j = 0;
        do
        {
            if(j >= i)
                return false;
            if(as[j].equals(s))
                return true;
            j++;
        } while(true);
    }

    public void close()
    {
        try
        {
            mNfcf.close();
        }
        catch(Exception exception)
        {
            DebugHelper.print(new Object[] {
                "Exception at close"
            });
        }
        mNfcf = null;
    }

    public void enableTimeout(boolean flag)
    {
        mTimeoutEnabled = flag;
    }

    public byte[] findServiceCode(int i)
    {
        byte abyte0[] = getFindServiceCodeCommand(i);
        byte abyte1[];
        byte abyte2[];
        try
        {
            if(!mNfcf.isConnected())
                mNfcf.connect();
            abyte1 = mNfcf.transceive(abyte0);
        }
        catch(Exception exception)
        {
            DebugHelper.print(new Object[] {
                "Exception at read"
            });
            return null;
        }
        if(abyte1 == null)
            break MISSING_BLOCK_LABEL_46;
        if(abyte1.length >= 12)
            break MISSING_BLOCK_LABEL_60;
        DebugHelper.print(new Object[] {
            "read failed"
        });
        return null;
        abyte2 = Arrays.copyOfRange(abyte1, 10, abyte1.length);
        return abyte2;
    }

    public byte[][] getServiceCodeList()
    {
        int i = 1;
        ArrayList arraylist = new ArrayList();
        do
        {
            byte abyte0[];
            for(abyte0 = findServiceCode(i); abyte0 == null || abyte0[0] == -1 && abyte0[1] == -1;)
            {
                int ai[] = {
                    0, 0
                };
                return (byte[][])arraylist.toArray((byte[][])Array.newInstance(Byte.TYPE, ai));
            }

            Object aobj[] = new Object[1];
            aobj[0] = (new StringBuilder("service code faound ")).append(Integer.toHexString(0xff & abyte0[0])).append(Integer.toHexString(0xff & abyte0[1])).toString();
            DebugHelper.print(aobj);
            arraylist.add(abyte0);
            i++;
        } while(true);
    }

    public byte[] getSystemCode()
    {
        if(mSystemCode.length != 2)
        {
            return null;
        } else
        {
            byte abyte0[] = new byte[2];
            abyte0[0] = mSystemCode[0];
            abyte0[1] = mSystemCode[1];
            return abyte0;
        }
    }

    public byte[][] getSystemCodeList()
        throws Exception
    {
        byte abyte0[] = getGetSystemCodeListCommand();
        if(!mNfcf.isConnected())
            mNfcf.connect();
        byte abyte1[] = mNfcf.transceive(abyte0);
        byte abyte2[][];
        if(abyte1 == null || abyte1.length < 10)
        {
            DebugHelper.print(new Object[] {
                "read failed"
            });
            abyte2 = null;
        } else
        {
            byte byte0 = abyte1[10];
            abyte2 = new byte[byte0][];
            int i = 0;
            while(i < byte0) 
            {
                abyte2[i] = Arrays.copyOfRange(abyte1, 11 + i * 2, 13 + i * 2);
                Object aobj[] = new Object[1];
                aobj[0] = (new StringBuilder("found ")).append(Integer.toHexString(0xff & abyte2[i][0])).append(" ").append(Integer.toHexString(0xff & abyte2[i][1])).toString();
                DebugHelper.print(aobj);
                i++;
            }
        }
        return abyte2;
    }

    public boolean isIDmValid()
    {
        if(mIdm != null && mIdm.length == 8)
        {
            byte abyte0[] = mIdm;
            int i = abyte0.length;
            int j = 0;
            while(j < i) 
            {
                if(abyte0[j] != 0)
                    return true;
                j++;
            }
        }
        return false;
    }

    public boolean isTimeoutEnabled()
    {
        return mTimeoutEnabled;
    }

    public boolean pollSystem(byte byte0, byte byte1)
        throws Exception
    {
        byte abyte0[] = getPollSystemCommand(byte0, byte1);
        if(!mNfcf.isConnected())
            mNfcf.connect();
        if(mTimeoutEnabled && android.os.Build.VERSION.SDK_INT >= 14)
        {
            int i = getPollingTimeOut(1);
            Object aobj[] = new Object[2];
            aobj[0] = "POLL TIMEOUT:";
            aobj[1] = Integer.valueOf(i);
            DebugHelper.print(aobj);
            mNfcf.setTimeout(i);
        }
        byte abyte1[] = mNfcf.transceive(abyte0);
        DebugHelper.print(new Object[] {
            "POLL END"
        });
        if(abyte1 == null || abyte1.length < 20)
            return false;
        mSystemCode = Arrays.copyOfRange(abyte1, 18, 20);
        mIdm = Arrays.copyOfRange(abyte1, 2, 10);
        if(mSystemCode[0] != byte0 || mSystemCode[1] != byte1)
        {
            DebugHelper.print(new Object[] {
                "POLL NG"
            });
            return false;
        } else
        {
            DebugHelper.print(new Object[] {
                "POLL OK"
            });
            return true;
        }
    }

    public boolean pollSystem(byte abyte0[])
        throws Exception
    {
        return pollSystem(abyte0[0], abyte0[1]);
    }

    public byte[] read(byte byte0, byte byte1, byte byte2)
        throws Exception
    {
        byte abyte0[] = getReadCommand(byte0, byte1, byte2);
        if(!mNfcf.isConnected())
            mNfcf.connect();
        if(mTimeoutEnabled && android.os.Build.VERSION.SDK_INT >= 14)
        {
            int i = getTimeOut(5, 1);
            Object aobj[] = new Object[2];
            aobj[0] = "READ TIMEOUT:";
            aobj[1] = Integer.valueOf(i);
            DebugHelper.print(aobj);
            mNfcf.setTimeout(i);
        }
        DebugHelper.print(new Object[] {
            "READ START"
        });
        byte abyte1[] = mNfcf.transceive(abyte0);
        if(abyte1 == null || abyte1.length < 13)
        {
            DebugHelper.print(new Object[] {
                "read failed"
            });
            return null;
        } else
        {
            DebugHelper.print(new Object[] {
                "READ END"
            });
            return Arrays.copyOfRange(abyte1, 13, abyte1.length);
        }
    }

    public byte[] read(byte abyte0[], byte byte0)
        throws Exception
    {
        return read(abyte0[0], abyte0[1], byte0);
    }

    public boolean requsetResponse()
    {
        boolean flag;
        flag = true;
        byte abyte0[] = getRequestResponseCommand();
        byte abyte1[];
        Object aobj1[];
        try
        {
            if(!mNfcf.isConnected())
                mNfcf.connect();
            abyte1 = mNfcf.transceive(abyte0);
        }
        catch(Exception exception)
        {
            Object aobj[] = new Object[flag];
            aobj[0] = "Exception";
            DebugHelper.print(aobj);
            return false;
        }
        if(abyte1 == null)
            break MISSING_BLOCK_LABEL_64;
        if(abyte1.length >= 11 && abyte1[0] == 11 && abyte1[1] == 5)
            break MISSING_BLOCK_LABEL_140;
        if(abyte1 == null)
            break MISSING_BLOCK_LABEL_101;
        aobj1 = new Object[2];
        aobj1[0] = "result ";
        aobj1[1] = Byte.valueOf(abyte1[1]);
        DebugHelper.print(aobj1);
        break MISSING_BLOCK_LABEL_138;
        DebugHelper.print(new Object[] {
            "result null"
        });
        flag = false;
        return flag;
    }

    private static final byte COMMAND_POLLING = 0;
    private static final byte COMMAND_READ_WO_ENCRYPTION = 6;
    private static final byte COMMAND_REQUEST_RESPONSE = 4;
    private static final byte COMMAND_REQUEST_SYSTEMCODE = 12;
    private static final byte COMMAND_SEARCH_SERVICECODE = 10;
    private static final int DEFAULT_TIMEOUT = 255;
    private static final int MANUFACTURE_INDEX_READ = 5;
    private byte mIdm[];
    private byte mManufacture[];
    private NfcF mNfcf;
    private byte mSystemCode[];
    private boolean mTimeoutEnabled;
}
