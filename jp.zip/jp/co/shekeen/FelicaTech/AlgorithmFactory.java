// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;


// Referenced classes of package jp.co.shekeen.FelicaTech:
//            IAlgorithm, BigEndian, LittleEndian, Ascii

public class AlgorithmFactory
{

    public AlgorithmFactory()
    {
    }

    public static IAlgorithm getInstance(String s)
    {
        int i;
        IAlgorithm aialgorithm[];
        int j;
        i = 0;
        aialgorithm = new IAlgorithm[3];
        aialgorithm[0] = new BigEndian();
        aialgorithm[1] = new LittleEndian();
        aialgorithm[2] = new Ascii();
        j = aialgorithm.length;
_L6:
        if(i < j) goto _L2; else goto _L1
_L1:
        IAlgorithm ialgorithm = null;
_L4:
        return ialgorithm;
_L2:
        ialgorithm = aialgorithm[i];
        if(ialgorithm.getName().equals(s)) goto _L4; else goto _L3
_L3:
        i++;
        if(true) goto _L6; else goto _L5
_L5:
    }

    public static String getLongName(String s)
    {
        int i;
        IAlgorithm aialgorithm[];
        int j;
        i = 0;
        aialgorithm = new IAlgorithm[3];
        aialgorithm[0] = new BigEndian();
        aialgorithm[1] = new LittleEndian();
        aialgorithm[2] = new Ascii();
        j = aialgorithm.length;
_L6:
        if(i < j) goto _L2; else goto _L1
_L1:
        String s1 = null;
_L4:
        return s1;
_L2:
        s1 = aialgorithm[i].getName();
        if(s1.indexOf(s) == 0) goto _L4; else goto _L3
_L3:
        i++;
        if(true) goto _L6; else goto _L5
_L5:
    }
}
