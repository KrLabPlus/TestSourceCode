// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;

import jp.co.shekeen.BalanceReaderFree.DebugHelper;

// Referenced classes of package jp.co.shekeen.FelicaTech:
//            Felica, IAlgorithm

public abstract class FelicaUser
{

    protected FelicaUser(byte byte0, byte byte1, byte byte2, byte byte3, byte byte4, byte byte5, IAlgorithm ialgorithm, 
            String s)
    {
        mSystemCodeLow = byte0;
        mSystemCodeHigh = byte1;
        mServiceCodeLow = byte2;
        mServiceCodeHigh = byte3;
        mBlockPosition = byte4;
        mStartAddress = byte5;
        mAlgorithm = ialgorithm;
        mCardName = s;
    }

    public boolean fakePoll()
    {
        byte abyte0[];
        if(mFelica != null)
            if((abyte0 = mFelica.getSystemCode()) != null)
                if(abyte0[0] == mSystemCodeLow && abyte0[1] == mSystemCodeHigh && mFelica.isIDmValid())
                {
                    DebugHelper.print(new Object[] {
                        "FAKE POLL OK"
                    });
                    return true;
                } else
                {
                    Object aobj[] = new Object[3];
                    aobj[0] = "FAKE POLL NG";
                    aobj[1] = mCardName;
                    Object aobj1[] = new Object[4];
                    aobj1[0] = Integer.valueOf(0xff & abyte0[0]);
                    aobj1[1] = Integer.valueOf(0xff & abyte0[1]);
                    aobj1[2] = Integer.valueOf(0xff & mSystemCodeLow);
                    aobj1[3] = Integer.valueOf(0xff & mSystemCodeHigh);
                    aobj[2] = String.format("TOP:%02X%02X TARGET:%02X%02X", aobj1);
                    DebugHelper.print(aobj);
                    return false;
                }
        return false;
    }

    public String getAlgorithm()
    {
        return mAlgorithm.getName();
    }

    public String getBalance()
    {
        byte abyte0[] = readBlock();
        if(abyte0 == null)
        {
            DebugHelper.print(new Object[] {
                "blockdata is null"
            });
            return null;
        } else
        {
            return mAlgorithm.convertToBalance(abyte0, mStartAddress);
        }
    }

    public byte getBlockPosition()
    {
        return mBlockPosition;
    }

    public String getCardName()
    {
        return new String(mCardName);
    }

    public byte[] getServiceCode()
    {
        byte abyte0[] = new byte[2];
        abyte0[0] = mServiceCodeLow;
        abyte0[1] = mServiceCodeHigh;
        return abyte0;
    }

    public byte getStartAddress()
    {
        return mStartAddress;
    }

    public byte[] getSystemCode()
    {
        byte abyte0[] = new byte[2];
        abyte0[0] = mSystemCodeLow;
        abyte0[1] = mSystemCodeHigh;
        return abyte0;
    }

    public boolean poll()
    {
        if(mFelica != null) goto _L2; else goto _L1
_L1:
        boolean flag = false;
_L4:
        return flag;
_L2:
        boolean flag1 = mFelica.pollSystem(mSystemCodeLow, mSystemCodeHigh);
        flag = flag1;
_L5:
        if(!flag)
        {
            DebugHelper.print(new Object[] {
                "pollSystem failed"
            });
            return flag;
        }
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        flag = false;
          goto _L5
    }

    protected byte[] readBlock()
    {
        if(mReadResult == null) goto _L2; else goto _L1
_L1:
        byte abyte0[] = mReadResult;
_L4:
        return abyte0;
_L2:
        if(mFelica == null)
            return null;
        Object aobj[] = new Object[1];
        StringBuilder stringbuilder = (new StringBuilder("Reading ")).append(mCardName);
        Object aobj1[] = new Object[5];
        aobj1[0] = Integer.valueOf(0xff & mSystemCodeHigh);
        aobj1[1] = Integer.valueOf(0xff & mSystemCodeLow);
        aobj1[2] = Integer.valueOf(0xff & mServiceCodeHigh);
        aobj1[3] = Integer.valueOf(0xff & mServiceCodeLow);
        aobj1[4] = Integer.valueOf(0xff & mBlockPosition);
        aobj[0] = stringbuilder.append(String.format(" %02X%02X %02X%02X %d", aobj1)).toString();
        DebugHelper.print(aobj);
        byte abyte1[] = mFelica.read(mServiceCodeLow, mServiceCodeHigh, mBlockPosition);
        abyte0 = abyte1;
_L5:
        if(abyte0 == null || abyte0.length != 16)
            return null;
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        abyte0 = null;
          goto _L5
    }

    protected void setFelica(Felica felica)
    {
        mFelica = felica;
    }

    private final IAlgorithm mAlgorithm;
    private final byte mBlockPosition;
    private final String mCardName;
    private Felica mFelica;
    private byte mReadResult[];
    private final byte mServiceCodeHigh;
    private final byte mServiceCodeLow;
    private final byte mStartAddress;
    private final byte mSystemCodeHigh;
    private final byte mSystemCodeLow;
}
