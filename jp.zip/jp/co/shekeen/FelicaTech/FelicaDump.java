// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;

import java.util.ArrayList;
import jp.co.shekeen.BalanceReaderFree.DebugHelper;

// Referenced classes of package jp.co.shekeen.FelicaTech:
//            Felica, DumpBlock

public class FelicaDump
{

    public FelicaDump(Felica felica)
    {
        mFelica = felica;
    }

    private void dumpServiceCode(Felica felica, byte byte0, byte byte1)
        throws Exception
    {
        byte abyte0[] = felica.getSystemCode();
        byte byte2 = 0;
        if(abyte0 == null)
        {
            DebugHelper.print(new Object[] {
                "Invalid felica state!!"
            });
            return;
        }
        do
        {
            abyte1 = felica.read(byte0, byte1, byte2);
            if(abyte1 != null && byte2 != 127)
            {
                mDumpArray.add(new DumpBlock(abyte0[0], abyte0[1], byte0, byte1, byte2, abyte1));
                byte2++;
            } else
            {
                return;
            }
        } while(true);
    }

    private void dumpSystemCode(Felica felica, byte byte0, byte byte1)
        throws Exception
    {
        felica.pollSystem(byte0, byte1);
        byte abyte0[][] = felica.getServiceCodeList();
        int i = abyte0.length;
        int j = 0;
        do
        {
            if(j >= i)
                return;
            byte abyte1[] = abyte0[j];
            dumpServiceCode(felica, abyte1[0], abyte1[1]);
            j++;
        } while(true);
    }

    public DumpBlock[] dumpAll()
        throws Exception
    {
        byte abyte0[][];
        if(mFelica == null)
            return null;
        mDumpArray = new ArrayList();
        abyte0 = mFelica.getSystemCodeList();
        if(abyte0 == null) goto _L2; else goto _L1
_L1:
        int i;
        int j;
        i = abyte0.length;
        j = 0;
_L5:
        if(j < i) goto _L3; else goto _L2
_L2:
        return (DumpBlock[])mDumpArray.toArray(new DumpBlock[0]);
_L3:
        byte abyte1[] = abyte0[j];
        dumpSystemCode(mFelica, abyte1[0], abyte1[1]);
        j++;
        if(true) goto _L5; else goto _L4
_L4:
    }

    private ArrayList mDumpArray;
    Felica mFelica;
}
