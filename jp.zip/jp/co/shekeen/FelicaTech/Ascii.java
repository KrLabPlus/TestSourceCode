// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;


// Referenced classes of package jp.co.shekeen.FelicaTech:
//            IAlgorithm

public class Ascii
    implements IAlgorithm
{

    public Ascii()
    {
    }

    public String convertToBalance(byte abyte0[], int i)
    {
        if(abyte0 == null || abyte0.length - i < 5)
            return null;
        char ac[] = new char[5];
        int j = 0;
        int k = 0;
        do
        {
            if(k >= 5)
                return String.valueOf(ac, 0, j);
            if(j > 0 || abyte0[i + k] != 48)
            {
                ac[j] = (char)abyte0[i + k];
                j++;
            }
            k++;
        } while(true);
    }

    public byte[] convertToByte(int i)
    {
        char ac[] = String.valueOf(i).toCharArray();
        byte abyte0[] = new byte[5];
        int j = 1;
        do
        {
            if(j > abyte0.length)
                return abyte0;
            if(ac.length - j >= 0)
                abyte0[abyte0.length - j] = (byte)ac[ac.length - j];
            else
                abyte0[abyte0.length - j] = 48;
            j++;
        } while(true);
    }

    public String getName()
    {
        return "ASCII";
    }

    private static final int BLOCK_SIZE = 5;
    private static final String NAME = "ASCII";
}
