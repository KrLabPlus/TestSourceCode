// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;

import java.io.Serializable;
import java.util.Arrays;

public class DumpBlock
    implements Serializable
{

    public DumpBlock(byte byte0, byte byte1, byte byte2, byte byte3, byte byte4, byte abyte0[])
    {
        mSystemCodeLow = byte0;
        mSystemCodeHigh = byte1;
        mServiceCodeLow = byte2;
        mServiceCodeHigh = byte3;
        mBlockPosition = byte4;
        mBlockData = abyte0;
    }

    public DumpBlock(byte abyte0[], byte abyte1[], byte byte0, byte abyte2[])
    {
        mSystemCodeLow = abyte0[0];
        mSystemCodeHigh = abyte0[1];
        mServiceCodeLow = abyte1[0];
        mServiceCodeHigh = abyte1[1];
        mBlockPosition = byte0;
        mBlockData = abyte2;
    }

    public byte[] getBlockData()
    {
        return Arrays.copyOf(mBlockData, mBlockData.length);
    }

    public byte getBlockPosition()
    {
        return mBlockPosition;
    }

    public byte[] getServiceCode()
    {
        byte abyte0[] = new byte[2];
        abyte0[0] = mServiceCodeLow;
        abyte0[1] = mServiceCodeHigh;
        return abyte0;
    }

    public byte[] getSystemCode()
    {
        byte abyte0[] = new byte[2];
        abyte0[0] = mSystemCodeLow;
        abyte0[1] = mSystemCodeHigh;
        return abyte0;
    }

    private static final long serialVersionUID = 0xaed1a0e4360f0574L;
    private final byte mBlockData[];
    private final byte mBlockPosition;
    private final byte mServiceCodeHigh;
    private final byte mServiceCodeLow;
    private final byte mSystemCodeHigh;
    private final byte mSystemCodeLow;
}
