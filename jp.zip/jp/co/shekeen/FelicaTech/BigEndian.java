// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;


// Referenced classes of package jp.co.shekeen.FelicaTech:
//            IAlgorithm

public class BigEndian
    implements IAlgorithm
{

    public BigEndian()
    {
    }

    public String convertToBalance(byte abyte0[], int i)
    {
        if(abyte0 == null || abyte0.length - i < 2)
            return null;
        else
            return String.valueOf(256 * (0xff & abyte0[i]) + (0xff & abyte0[i + 1]));
    }

    public byte[] convertToByte(int i)
    {
        byte abyte0[] = new byte[2];
        abyte0[0] = (byte)((0xff00 & i) / 256);
        abyte0[1] = (byte)(i & 0xff);
        return abyte0;
    }

    public String getName()
    {
        return "BE";
    }

    private static final int BLOCK_SIZE = 2;
    private static final String NAME = "BE";
}
