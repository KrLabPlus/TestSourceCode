// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;


// Referenced classes of package jp.co.shekeen.FelicaTech:
//            FelicaUser, LittleEndian, IAlgorithm, Felica

public class Waon extends FelicaUser
{

    public Waon(Felica felica)
    {
        super((byte)-2, (byte)0, (byte)23, (byte)104, (byte)0, (byte)0, ALGORITHM, "WAON");
        setFelica(felica);
    }

    private static final IAlgorithm ALGORITHM = new LittleEndian();
    private static final byte BLOCK_POSITION = 0;
    private static final String CARD_NAME = "WAON";
    private static final byte SERVICE_CODE_HIGH = 104;
    private static final byte SERVICE_CODE_LOW = 23;
    private static final byte START_ADDRESS = 0;
    private static final byte SYSTEM_CODE_HIGH = 0;
    private static final byte SYSTEM_CODE_LOW = -2;

}
