// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;

import java.util.ArrayList;
import jp.co.shekeen.BalanceReaderFree.DebugHelper;

// Referenced classes of package jp.co.shekeen.FelicaTech:
//            FelicaUserPlugin, Felica, FelicaUser, Suica, 
//            Waon, Nanaco, Edy

public class FelicaUserFactory
{
    public static class BalanceResult
    {

        public String balance;
        public int index;

        public BalanceResult()
        {
        }
    }


    public FelicaUserFactory(Felica felica)
    {
        mFelica = felica;
        mFelicaUserList = new ArrayList();
    }

    public void addPlugin(FelicaUserPlugin felicauserplugin)
    {
        if(felicauserplugin == null)
        {
            return;
        } else
        {
            felicauserplugin.setFelica(mFelica);
            mFelicaUserList.add(felicauserplugin);
            return;
        }
    }

    public void close()
    {
        if(mFelica == null)
        {
            return;
        } else
        {
            mFelica.close();
            return;
        }
    }

    public BalanceResult getBalance(boolean flag)
    {
        if(mFelica == null)
            return null;
        int i = 0;
        do
        {
            if(i >= mFelicaUserList.size())
            {
                DebugHelper.print(new Object[] {
                    "Unknown felica"
                });
                return null;
            }
            FelicaUser felicauser = (FelicaUser)mFelicaUserList.get(i);
            Object aobj[] = new Object[2];
            aobj[0] = "POLL";
            aobj[1] = felicauser.getCardName();
            DebugHelper.print(aobj);
            boolean flag1;
            if(flag)
                flag1 = felicauser.poll();
            else
                flag1 = felicauser.fakePoll();
            String s;
            if(flag1)
                if((s = felicauser.getBalance()) != null)
                {
                    Object aobj1[] = new Object[2];
                    aobj1[0] = (new StringBuilder(String.valueOf(felicauser.getCardName()))).append(" selected at").toString();
                    aobj1[1] = Integer.valueOf(i);
                    DebugHelper.print(aobj1);
                    BalanceResult balanceresult = new BalanceResult();
                    balanceresult.index = i;
                    balanceresult.balance = s;
                    return balanceresult;
                }
            i++;
        } while(true);
    }

    public FelicaUser[] getDefaultUserList()
    {
        FelicaUser afelicauser[] = new FelicaUser[4];
        afelicauser[0] = new Suica(mFelica);
        afelicauser[1] = new Waon(mFelica);
        afelicauser[2] = new Nanaco(mFelica);
        afelicauser[3] = new Edy(mFelica);
        return afelicauser;
    }

    public boolean getTimeoutEnabled()
    {
        if(mFelica == null)
            return false;
        else
            return mFelica.isTimeoutEnabled();
    }

    private Felica mFelica;
    private ArrayList mFelicaUserList;
}
