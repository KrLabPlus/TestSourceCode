// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.FelicaTech;


// Referenced classes of package jp.co.shekeen.FelicaTech:
//            FelicaUser, AlgorithmFactory, IAlgorithm

public class FelicaUserPlugin extends FelicaUser
{

    public FelicaUserPlugin(byte byte0, byte byte1, byte byte2, byte byte3, byte byte4, byte byte5, String s, 
            String s1)
    {
        super(byte0, byte1, byte2, byte3, byte4, byte5, AlgorithmFactory.getInstance(s), s1);
    }

    public FelicaUserPlugin(byte byte0, byte byte1, byte byte2, byte byte3, byte byte4, byte byte5, IAlgorithm ialgorithm, 
            String s)
    {
        super(byte0, byte1, byte2, byte3, byte4, byte5, ialgorithm, s);
    }
}
