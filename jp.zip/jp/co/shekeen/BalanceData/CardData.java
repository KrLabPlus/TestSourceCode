// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceData;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import jp.co.shekeen.BalanceReaderFree.DebugHelper;
import jp.co.shekeen.FelicaTech.*;

// Referenced classes of package jp.co.shekeen.BalanceData:
//            CandidateInfo

public class CardData
    implements Serializable
{

    public CardData(Context context, String s)
    {
        mName = new String(s);
        loadContent(context.getSharedPreferences(mName, 0));
    }

    public CardData(String s, CandidateInfo acandidateinfo[], int i)
    {
        mName = new String(s);
        mCandidateList = acandidateinfo;
        mSelection = i;
        mPreset = false;
    }

    public CardData(FelicaUser felicauser)
    {
        mName = felicauser.getCardName();
        byte abyte0[] = felicauser.getSystemCode();
        byte abyte1[] = felicauser.getServiceCode();
        byte byte0 = felicauser.getBlockPosition();
        byte byte1 = felicauser.getStartAddress();
        String s = felicauser.getAlgorithm();
        mCandidateList = (new CandidateInfo[] {
            new CandidateInfo(abyte0[0], abyte0[1], abyte1[0], abyte1[1], byte0, byte1, s)
        });
        mSelection = 0;
        mPreset = true;
    }

    public static void checkPresetVersion(Context context)
    {
        SharedPreferences sharedpreferences = context.getSharedPreferences("version\b", 0);
        if(sharedpreferences.getInt("preset version", 0) < 2)
        {
            DebugHelper.print(new Object[] {
                "UPDATE PRESET"
            });
            installPreset(context, sharedpreferences);
        }
    }

    public static CardData convert(String s, String s1)
        throws NumberFormatException
    {
        if(s1.length() != 13)
            throw new NumberFormatException();
        byte byte0 = (byte)(0xff & Integer.valueOf(s1.substring(0, 2), 16).intValue());
        byte byte1 = (byte)(0xff & Integer.valueOf(s1.substring(2, 4), 16).intValue());
        byte byte2 = (byte)(0xff & Integer.valueOf(s1.substring(4, 6), 16).intValue());
        byte byte3 = (byte)(0xff & Integer.valueOf(s1.substring(6, 8), 16).intValue());
        byte byte4 = (byte)(0xff & Integer.valueOf(s1.substring(8, 10), 16).intValue());
        byte byte5 = (byte)(0xff & Integer.valueOf(s1.substring(10, 12), 16).intValue());
        String s2 = AlgorithmFactory.getLongName(s1.substring(12));
        if(s2 == null)
            throw new NumberFormatException();
        else
            return new CardData(s, new CandidateInfo[] {
                new CandidateInfo(byte1, byte0, byte3, byte2, byte4, byte5, s2)
            }, 0);
    }

    private static void installPreset(Context context, SharedPreferences sharedpreferences)
    {
        ArrayList arraylist;
        FelicaUser afelicauser[];
        int i;
        arraylist = new ArrayList();
        afelicauser = (new FelicaUserFactory(null)).getDefaultUserList();
        if(afelicauser.length < 1)
            return;
        i = 0;
_L5:
        if(i < afelicauser.length) goto _L2; else goto _L1
_L1:
        String as[];
        int j;
        as = loadCardIndex(context);
        j = 0;
_L6:
        if(j < as.length) goto _L4; else goto _L3
_L3:
        int k = 0;
_L7:
        if(k >= arraylist.size())
        {
            android.content.SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putInt("preset version", 2);
            editor.commit();
            return;
        }
        break MISSING_BLOCK_LABEL_158;
_L2:
        arraylist.add(new CardData(afelicauser[i]));
        i++;
          goto _L5
_L4:
        CardData carddata = new CardData(context, as[j]);
        if(!carddata.isPreset())
            arraylist.add(carddata);
        carddata.delete(context);
        j++;
          goto _L6
        ((CardData)arraylist.get(k)).save(context);
        k++;
          goto _L7
    }

    public static String[] loadCardIndex(Context context)
    {
        return (String[])loadIndex(context.getSharedPreferences("index\b", 0)).toArray(new String[0]);
    }

    private void loadContent(SharedPreferences sharedpreferences)
    {
        mSelection = sharedpreferences.getInt("selection", 0);
        mPreset = sharedpreferences.getBoolean("preset", false);
        int i = sharedpreferences.getInt("candidate num", 0);
        mCandidateList = new CandidateInfo[i];
        int j = 0;
        do
        {
            if(j >= i)
                return;
            String s = String.valueOf(j);
            byte byte0 = (byte)(0xff & sharedpreferences.getInt((new StringBuilder("system code low")).append(s).toString(), 0));
            byte byte1 = (byte)(0xff & sharedpreferences.getInt((new StringBuilder("system code high")).append(s).toString(), 0));
            byte byte2 = (byte)(0xff & sharedpreferences.getInt((new StringBuilder("service code low")).append(s).toString(), 0));
            byte byte3 = (byte)(0xff & sharedpreferences.getInt((new StringBuilder("service code high")).append(s).toString(), 0));
            byte byte4 = (byte)(0xff & sharedpreferences.getInt((new StringBuilder("block position")).append(s).toString(), 0));
            byte byte5 = (byte)(0xff & sharedpreferences.getInt((new StringBuilder("data address")).append(s).toString(), 0));
            String s1 = sharedpreferences.getString((new StringBuilder("algorithm")).append(s).toString(), "");
            mCandidateList[j] = new CandidateInfo(byte0, byte1, byte2, byte3, byte4, byte5, s1);
            j++;
        } while(true);
    }

    private static ArrayList loadIndex(SharedPreferences sharedpreferences)
    {
        int i = sharedpreferences.getInt("index count", 0);
        ArrayList arraylist = new ArrayList();
        int j = 0;
        do
        {
            if(j >= i)
                return arraylist;
            arraylist.add(sharedpreferences.getString(String.valueOf(j), ""));
            j++;
        } while(true);
    }

    public static void moveCardToTop(Context context, int i)
    {
        SharedPreferences sharedpreferences = context.getSharedPreferences("index\b", 0);
        ArrayList arraylist = loadIndex(sharedpreferences);
        if(i <= 0 || i >= arraylist.size())
        {
            return;
        } else
        {
            arraylist.add(0, (String)arraylist.remove(i));
            saveIndex(sharedpreferences, arraylist);
            return;
        }
    }

    public static void reinstallPreset(Context context)
    {
        installPreset(context, context.getSharedPreferences("index\b", 0));
    }

    private void saveContent(SharedPreferences sharedpreferences)
    {
        android.content.SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.clear();
        editor.putInt("selection", mSelection);
        editor.putInt("candidate num", mCandidateList.length);
        editor.putBoolean("preset", mPreset);
        int i = 0;
        do
        {
            if(i >= mCandidateList.length)
            {
                editor.commit();
                return;
            }
            byte abyte0[] = mCandidateList[i].getSystemCode();
            byte abyte1[] = mCandidateList[i].getServiceCode();
            byte byte0 = mCandidateList[i].getBlockPosition();
            byte byte1 = mCandidateList[i].getDataAddress();
            String s = mCandidateList[i].getAlgorithmName();
            String s1 = String.valueOf(i);
            editor.putInt((new StringBuilder("system code low")).append(s1).toString(), 0xff & abyte0[0]);
            editor.putInt((new StringBuilder("system code high")).append(s1).toString(), 0xff & abyte0[1]);
            editor.putInt((new StringBuilder("service code low")).append(s1).toString(), 0xff & abyte1[0]);
            editor.putInt((new StringBuilder("service code high")).append(s1).toString(), 0xff & abyte1[1]);
            editor.putInt((new StringBuilder("block position")).append(s1).toString(), byte0 & 0xff);
            editor.putInt((new StringBuilder("data address")).append(s1).toString(), byte1 & 0xff);
            editor.putString((new StringBuilder("algorithm")).append(s1).toString(), s);
            i++;
        } while(true);
    }

    private static void saveIndex(SharedPreferences sharedpreferences, ArrayList arraylist)
    {
        android.content.SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.clear();
        editor.putInt("index count", arraylist.size());
        int i = 0;
        do
        {
            if(i >= arraylist.size())
            {
                editor.commit();
                return;
            }
            editor.putString(String.valueOf(i), (String)arraylist.get(i));
            i++;
        } while(true);
    }

    public void delete(Context context)
    {
        SharedPreferences sharedpreferences;
        ArrayList arraylist;
        int i;
        int j;
        sharedpreferences = context.getSharedPreferences("index\b", 0);
        arraylist = loadIndex(sharedpreferences);
        i = -1;
        j = 0;
_L2:
        if(j < arraylist.size())
        {
label0:
            {
                if(!((String)arraylist.get(j)).equals(mName))
                    break label0;
                i = j;
            }
        }
        if(i < 0)
        {
            return;
        } else
        {
            context.getSharedPreferences(mName, 0).edit().clear().commit();
            arraylist.remove(i);
            saveIndex(sharedpreferences, arraylist);
            return;
        }
        j++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public CandidateInfo[] getCandidateList()
    {
        if(mCandidateList == null)
            return null;
        else
            return (CandidateInfo[])Arrays.copyOf(mCandidateList, mCandidateList.length);
    }

    public String getName()
    {
        return new String(mName);
    }

    public int getSelectedIndex()
    {
        return mSelection;
    }

    public CandidateInfo getSelection()
    {
        if(mCandidateList == null || mSelection >= mCandidateList.length)
            return null;
        else
            return mCandidateList[mSelection];
    }

    public boolean isPreset()
    {
        return mPreset;
    }

    public void save(Context context)
    {
        SharedPreferences sharedpreferences;
        SharedPreferences sharedpreferences1;
        ArrayList arraylist;
        int i;
        sharedpreferences = context.getSharedPreferences("index\b", 0);
        sharedpreferences1 = context.getSharedPreferences(mName, 0);
        arraylist = loadIndex(sharedpreferences);
        i = 0;
_L5:
        int j;
        boolean flag;
        j = arraylist.size();
        flag = false;
        if(i < j) goto _L2; else goto _L1
_L1:
        if(!flag)
            arraylist.add(0, mName);
        saveIndex(sharedpreferences, arraylist);
        saveContent(sharedpreferences1);
        return;
_L2:
        if(!mName.equals(arraylist.get(i)))
            break; /* Loop/switch isn't completed */
        flag = true;
        if(true) goto _L1; else goto _L3
_L3:
        i++;
        if(true) goto _L5; else goto _L4
_L4:
    }

    public void setSelectedIndex(int i)
    {
        if(i < 0 || i >= mCandidateList.length)
        {
            return;
        } else
        {
            mSelection = i;
            return;
        }
    }

    public FelicaUserPlugin toPlugin()
    {
        CandidateInfo candidateinfo = getSelection();
        if(candidateinfo == null)
        {
            return null;
        } else
        {
            byte abyte0[] = candidateinfo.getSystemCode();
            byte abyte1[] = candidateinfo.getServiceCode();
            byte byte0 = candidateinfo.getBlockPosition();
            byte byte1 = candidateinfo.getDataAddress();
            String s = candidateinfo.getAlgorithmName();
            return new FelicaUserPlugin(abyte0[0], abyte0[1], abyte1[0], abyte1[1], byte0, byte1, s, mName);
        }
    }

    private static final String KEY_ALGORITHM = "algorithm";
    private static final String KEY_BLOCK_POSITION = "block position";
    private static final String KEY_CANDIDATE_COUNT = "candidate num";
    private static final String KEY_DATA_ADDRESS = "data address";
    private static final String KEY_INDEX_COUNT = "index count";
    private static final String KEY_PRESET = "preset";
    private static final String KEY_PRESET_VERSION = "preset version";
    private static final String KEY_SELECTION = "selection";
    private static final String KEY_SERVICE_CODE_HIGH = "service code high";
    private static final String KEY_SERVICE_CODE_LOW = "service code low";
    private static final String KEY_SYSTEM_CODE_HIGH = "system code high";
    private static final String KEY_SYSTEM_CODE_LOW = "system code low";
    private static final int PRESET_VERSION = 2;
    private static final String REFERENCES_INDEX = "index\b";
    private static final String REFERENCES_VERSION = "version\b";
    private static final long serialVersionUID = 0x1b53ba8250f4ba91L;
    private CandidateInfo mCandidateList[];
    private String mName;
    private boolean mPreset;
    private int mSelection;
}
