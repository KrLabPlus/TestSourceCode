// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceData;

import java.io.Serializable;
import jp.co.shekeen.FelicaTech.DumpBlock;

public class CandidateInfo extends DumpBlock
    implements Serializable
{

    public CandidateInfo(byte byte0, byte byte1, byte byte2, byte byte3, byte byte4, byte byte5, String s)
    {
        super(byte0, byte1, byte2, byte3, byte4, null);
        mDataAddress = byte5;
        mAlgorithmName = new String(s);
    }

    public CandidateInfo(DumpBlock dumpblock, byte byte0, String s)
    {
        super(dumpblock.getSystemCode(), dumpblock.getServiceCode(), dumpblock.getBlockPosition(), null);
        mDataAddress = byte0;
        mAlgorithmName = new String(s);
    }

    public String getAlgorithmName()
    {
        return new String(mAlgorithmName);
    }

    public byte getDataAddress()
    {
        return mDataAddress;
    }

    public String toString()
    {
        byte abyte0[] = getSystemCode();
        byte abyte1[] = getServiceCode();
        byte byte0 = getBlockPosition();
        String s = String.valueOf(mAlgorithmName.charAt(0));
        Object aobj[] = new Object[7];
        aobj[0] = Integer.valueOf(0xff & abyte0[1]);
        aobj[1] = Integer.valueOf(0xff & abyte0[0]);
        aobj[2] = Integer.valueOf(0xff & abyte1[1]);
        aobj[3] = Integer.valueOf(0xff & abyte1[0]);
        aobj[4] = Integer.valueOf(byte0 & 0xff);
        aobj[5] = Integer.valueOf(0xff & mDataAddress);
        aobj[6] = s;
        return String.format("%02X%02X %02X%02X %02X%02X %s", aobj);
    }

    private static final long serialVersionUID = 0x3b72e3f8f5cce7dcL;
    private final String mAlgorithmName;
    private final byte mDataAddress;
}
