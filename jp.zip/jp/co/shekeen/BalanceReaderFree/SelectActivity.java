// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceScreen;
import android.widget.LinearLayout;
import android.widget.TextView;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            RegisterActivity, ManualActivity, GuiUtility

public class SelectActivity extends PreferenceActivity
{

    public SelectActivity()
    {
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        addPreferencesFromResource(0x7f040001);
        ((PreferenceScreen)findPreference("key_pref_auto")).setIntent(new Intent(this, jp/co/shekeen/BalanceReaderFree/RegisterActivity));
        ((PreferenceScreen)findPreference("key_pref_manual")).setIntent(new Intent(this, jp/co/shekeen/BalanceReaderFree/ManualActivity));
        TextView textview = new TextView(this);
        textview.setText(getString(0x7f07004c));
        textview.setTextAppearance(this, 0x1030044);
        int i = (new GuiUtility(this)).dipToPx(10);
        android.widget.LinearLayout.LayoutParams layoutparams = new android.widget.LinearLayout.LayoutParams(-1, -2);
        LinearLayout linearlayout = new LinearLayout(this);
        linearlayout.setLayoutParams(layoutparams);
        linearlayout.setPadding(i, i, i, i);
        linearlayout.addView(textview);
        linearlayout.setGravity(80);
        addContentView(linearlayout, new android.widget.LinearLayout.LayoutParams(-1, -1));
    }

    private static final String KEY_AUTO = "key_pref_auto";
    private static final String KEY_MANUAL = "key_pref_manual";
    private static final int PADDING = 10;
}
