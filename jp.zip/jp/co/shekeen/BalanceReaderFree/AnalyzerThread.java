// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.os.Handler;
import android.os.Message;
import java.util.ArrayList;
import jp.co.shekeen.BalanceData.CandidateInfo;
import jp.co.shekeen.FelicaTech.*;

public class AnalyzerThread extends Thread
{
    public static class AnalyzerHandler extends Handler
    {

        public void handleMessage(Message message)
        {
            switch(message.what)
            {
            default:
                return;

            case 1: // '\001'
                mListener.onAnalyzeSucceeded((ArrayList)message.obj);
                return;

            case 2: // '\002'
                mListener.onAnalyzeFailed();
                return;

            case 3: // '\003'
                mListener.onAnalyzeRetry();
                break;
            }
        }

        private IAnalyzerListener mListener;

        public AnalyzerHandler(IAnalyzerListener ianalyzerlistener)
        {
            mListener = ianalyzerlistener;
        }
    }

    public static interface IAnalyzerListener
    {

        public abstract void onAnalyzeFailed();

        public abstract void onAnalyzeRetry();

        public abstract void onAnalyzeSucceeded(ArrayList arraylist);
    }


    public AnalyzerThread(IAnalyzerListener ianalyzerlistener, Felica felica, int i)
    {
        mHandler = new AnalyzerHandler(ianalyzerlistener);
        mFelicaDump = new FelicaDump(felica);
        mBalance = i;
        IAlgorithm aialgorithm[] = new IAlgorithm[3];
        aialgorithm[0] = new LittleEndian();
        aialgorithm[1] = new BigEndian();
        aialgorithm[2] = new Ascii();
        mAlgoList = aialgorithm;
    }

    private void analyzeData(DumpBlock adumpblock[], IAlgorithm ialgorithm)
    {
        byte abyte0[];
        String s;
        int i;
        int j;
        abyte0 = ialgorithm.convertToByte(mBalance);
        s = ialgorithm.getName();
        i = adumpblock.length;
        j = 0;
_L2:
        DumpBlock dumpblock;
        byte abyte1[];
        int k;
        if(j >= i)
            return;
        dumpblock = adumpblock[j];
        abyte1 = dumpblock.getBlockData();
        k = 0;
_L3:
label0:
        {
            if(k <= abyte1.length - abyte0.length)
                break label0;
            j++;
        }
        if(true) goto _L2; else goto _L1
_L1:
        boolean flag;
        int l;
        flag = true;
        l = 0;
_L4:
        if(l < abyte0.length)
        {
label1:
            {
                if(abyte1[k + l] == abyte0[l])
                    break label1;
                flag = false;
            }
        }
        if(flag)
            mCandidateList.add(new CandidateInfo(dumpblock, (byte)(k & 0xff), s));
        k++;
          goto _L3
        l++;
          goto _L4
    }

    public void run()
    {
        Message message = new Message();
        DumpBlock adumpblock[];
        IAlgorithm aialgorithm[];
        int i;
        mCandidateList = new ArrayList();
        adumpblock = mFelicaDump.dumpAll();
        aialgorithm = mAlgoList;
        i = aialgorithm.length;
        int j = 0;
_L3:
        if(j < i) goto _L2; else goto _L1
_L1:
        if(mCandidateList.size() != 0)
            break MISSING_BLOCK_LABEL_91;
        message.what = 2;
_L4:
        mHandler.sendMessage(message);
        return;
_L2:
        analyzeData(adumpblock, aialgorithm[j]);
        j++;
          goto _L3
        try
        {
            message.what = 1;
            message.obj = mCandidateList;
        }
        catch(Exception exception)
        {
            message.what = 3;
        }
          goto _L4
    }

    public static final int RESULT_FAILED = 2;
    public static final int RESULT_RETRY = 3;
    public static final int RESULT_SUCCEEDED = 1;
    private IAlgorithm mAlgoList[];
    private int mBalance;
    private ArrayList mCandidateList;
    private FelicaDump mFelicaDump;
    private Handler mHandler;
}
