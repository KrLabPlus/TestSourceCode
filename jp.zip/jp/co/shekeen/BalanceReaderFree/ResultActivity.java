// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import jp.co.shekeen.BalanceData.CandidateInfo;
import jp.co.shekeen.BalanceData.CardData;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            SettingActivity

public class ResultActivity extends Activity
    implements TextWatcher, android.view.View.OnClickListener, android.content.DialogInterface.OnClickListener
{

    public ResultActivity()
    {
    }

    private void onClickComplete()
    {
        String as[];
        int i;
        mSelected = mGroupResult.getCheckedRadioButtonId();
        mSelected = -5 + mSelected;
        mCardName = mEditName.getText().toString();
        if(mSelected < 0 || mCardName.length() < 1)
            return;
        as = CardData.loadCardIndex(this);
        i = 0;
_L2:
        int j = as.length;
        boolean flag = false;
        if(i < j)
        {
label0:
            {
                if(!mCardName.equals(as[i]))
                    break label0;
                flag = true;
            }
        }
        if(flag)
        {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle(0x7f070045);
            builder.setMessage((new StringBuilder("\"")).append(mCardName).append("\"").append(getString(0x7f070044)).toString());
            builder.setIcon(0x1080027);
            builder.setCancelable(false);
            builder.setPositiveButton(0x7f070046, this);
            builder.setNegativeButton(0x7f070047, this);
            builder.show();
            return;
        } else
        {
            saveCardData();
            return;
        }
        i++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private void saveCardData()
    {
        CandidateInfo acandidateinfo[] = (CandidateInfo[])mCandidateList.toArray(new CandidateInfo[0]);
        (new CardData(mCardName, acandidateinfo, mSelected)).save(this);
        Intent intent = new Intent(this, jp/co/shekeen/BalanceReaderFree/SettingActivity);
        intent.addFlags(0x4000000);
        startActivity(intent);
    }

    public void afterTextChanged(Editable editable)
    {
    }

    public void beforeTextChanged(CharSequence charsequence, int i, int j, int k)
    {
    }

    public void onClick(DialogInterface dialoginterface, int i)
    {
        if(i == -1)
            saveCardData();
    }

    public void onClick(View view)
    {
        if(view == mButtonComplete)
            onClickComplete();
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030005);
        mTextStatus = (TextView)findViewById(0x7f0c0017);
        mGroupResult = (RadioGroup)findViewById(0x7f0c003d);
        mEditName = (EditText)findViewById(0x7f0c002d);
        mButtonComplete = (Button)findViewById(0x7f0c0020);
        Bundle bundle1 = getIntent().getExtras();
        if(bundle1 != null)
        {
            mButtonComplete.setEnabled(false);
            mButtonComplete.setOnClickListener(this);
            mEditName.addTextChangedListener(this);
            mCandidateList = (ArrayList)bundle1.getSerializable("candidate");
            if(mCandidateList != null && mCandidateList.size() != 0)
            {
                int i = 0;
                do
                {
                    if(i >= mCandidateList.size())
                    {
                        mTextStatus.setText((new StringBuilder()).append(Integer.valueOf(mCandidateList.size())).append("�̌�₪������܂���").toString());
                        return;
                    }
                    RadioButton radiobutton = new RadioButton(this);
                    radiobutton.setText(((CandidateInfo)mCandidateList.get(i)).toString());
                    radiobutton.setTextAppearance(this, 0x1030042);
                    mGroupResult.addView(radiobutton);
                    radiobutton.setId(i + 5);
                    if(i == 0)
                        radiobutton.setChecked(true);
                    i++;
                } while(true);
            }
        }
    }

    public void onTextChanged(CharSequence charsequence, int i, int j, int k)
    {
        Button button = mButtonComplete;
        boolean flag;
        if(charsequence.toString().length() > 0)
            flag = true;
        else
            flag = false;
        button.setEnabled(flag);
    }

    public static final String EXTRA_CANDIDATE = "candidate";
    private static final int RADIO_ID_OFFSET = 5;
    private Button mButtonComplete;
    private ArrayList mCandidateList;
    private String mCardName;
    private EditText mEditName;
    private RadioGroup mGroupResult;
    private int mSelected;
    private TextView mTextStatus;
}
