// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.content.Context;

public class Config
{

    public Config()
    {
    }

    public static void initialize(Context context)
    {
        FREE = context.getPackageName().contains("Free");
    }

    public static final boolean DEBUG = false;
    public static boolean FREE = false;
    public static final String TAG = "shekeen";

    static 
    {
        FREE = true;
    }
}
