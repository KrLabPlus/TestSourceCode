// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            MainActivity, AnalyzeActivity, DebugHelper

public class RegisterActivity extends Activity
    implements TextWatcher, android.view.View.OnClickListener
{

    public RegisterActivity()
    {
        mLimit = false;
    }

    public void afterTextChanged(Editable editable)
    {
    }

    public void beforeTextChanged(CharSequence charsequence, int i, int j, int k)
    {
    }

    public void onClick(View view)
    {
label0:
        {
            if(view == mButtonAnalyze)
            {
                if(!mLimit)
                    break label0;
                Intent intent = new Intent(this, jp/co/shekeen/BalanceReaderFree/MainActivity);
                intent.addFlags(0x4000000);
                startActivity(intent);
            }
            return;
        }
        try
        {
            int i = Integer.valueOf(mEditBalance.getText().toString()).intValue();
            Intent intent1 = new Intent(this, jp/co/shekeen/BalanceReaderFree/AnalyzeActivity);
            intent1.putExtra("balance", i);
            intent1.addFlags(0x40000000);
            startActivity(intent1);
            return;
        }
        catch(NumberFormatException numberformatexception)
        {
            DebugHelper.print(new Object[] {
                "invalid number"
            });
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030004);
        mButtonAnalyze = (Button)findViewById(0x7f0c003c);
        mEditBalance = (EditText)findViewById(0x7f0c0039);
        mButtonAnalyze.setEnabled(false);
        mButtonAnalyze.setOnClickListener(this);
        mEditBalance.addTextChangedListener(this);
    }

    public void onTextChanged(CharSequence charsequence, int i, int j, int k)
    {
        int i1 = Integer.valueOf(charsequence.toString()).intValue();
        int l = i1;
_L2:
        Button button = mButtonAnalyze;
        boolean flag;
        if(l > 255)
            flag = true;
        else
            flag = false;
        button.setEnabled(flag);
        return;
        NumberFormatException numberformatexception;
        numberformatexception;
        l = 0;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static final int ANALYZE_UBOUND = 255;
    private Button mButtonAnalyze;
    private EditText mEditBalance;
    private boolean mLimit;
}
