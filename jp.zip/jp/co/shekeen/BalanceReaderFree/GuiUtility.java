// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

public class GuiUtility
{

    public GuiUtility(Context context)
    {
        mScale = context.getResources().getDisplayMetrics().density;
    }

    public int dipToPx(int i)
    {
        return (int)(0.5F + (float)i * mScale);
    }

    private float mScale;
}
