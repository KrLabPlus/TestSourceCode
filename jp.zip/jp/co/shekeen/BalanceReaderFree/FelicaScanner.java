// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.os.Handler;
import android.os.Message;
import jp.co.shekeen.FelicaTech.FelicaUserFactory;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            DebugHelper

public class FelicaScanner extends Thread
{
    public static interface FelicaScannerCallback
    {

        public abstract void onScanFinished(jp.co.shekeen.FelicaTech.FelicaUserFactory.BalanceResult balanceresult);
    }

    private static class ScanHandler extends Handler
    {

        public void handleMessage(Message message)
        {
            mCallback.onScanFinished((jp.co.shekeen.FelicaTech.FelicaUserFactory.BalanceResult)message.obj);
        }

        public void sendScanResult(jp.co.shekeen.FelicaTech.FelicaUserFactory.BalanceResult balanceresult)
        {
            Message message = new Message();
            message.obj = balanceresult;
            sendMessage(message);
        }

        private FelicaScannerCallback mCallback;

        private ScanHandler(FelicaScannerCallback felicascannercallback)
        {
            mCallback = felicascannercallback;
        }

        ScanHandler(FelicaScannerCallback felicascannercallback, ScanHandler scanhandler)
        {
            this(felicascannercallback);
        }
    }


    public FelicaScanner(FelicaUserFactory felicauserfactory, FelicaScannerCallback felicascannercallback)
    {
        mFactory = felicauserfactory;
        mHandler = new ScanHandler(felicascannercallback, null);
    }

    public void cancel()
    {
        mCancelled = true;
    }

    public void run()
    {
        jp.co.shekeen.FelicaTech.FelicaUserFactory.BalanceResult balanceresult;
        int i;
        int j;
        balanceresult = null;
        i = 7;
        if(mFactory.getTimeoutEnabled())
            i *= 2;
        j = 0;
_L5:
        if(j < i) goto _L2; else goto _L1
_L1:
        mFactory.close();
        mHandler.sendScanResult(balanceresult);
        return;
_L2:
        Object aobj[] = new Object[2];
        aobj[0] = "TRY";
        aobj[1] = Integer.valueOf(j);
        DebugHelper.print(aobj);
        FelicaUserFactory felicauserfactory = mFactory;
        boolean flag;
        if(j > 0)
            flag = true;
        else
            flag = false;
        balanceresult = felicauserfactory.getBalance(flag);
        if(balanceresult != null || mCancelled) goto _L1; else goto _L3
_L3:
        j++;
        if(true) goto _L5; else goto _L4
_L4:
    }

    private boolean mCancelled;
    private FelicaUserFactory mFactory;
    private ScanHandler mHandler;
}
