// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.app.*;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.*;
import android.view.MenuItem;
import java.util.ArrayList;
import jp.co.shekeen.BalanceData.CardData;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            Config, RegisterActivity, EditActivity

public class SettingActivity extends PreferenceActivity
    implements android.preference.Preference.OnPreferenceClickListener
{
    public static class SettingFragment extends PreferenceFragment
    {

        public void onCreate(Bundle bundle)
        {
            super.onCreate(bundle);
            ((SettingActivity)getActivity()).initPreference(this);
        }

        public SettingFragment()
        {
        }
    }


    public SettingActivity()
    {
    }

    private void initPreference(SettingFragment settingfragment)
    {
        mFragment = settingfragment;
        PackageManager packagemanager = getPackageManager();
        if(Config.FREE)
            try
            {
                packagemanager.getPackageInfo("jp.co.shekeen.BalanceReader", 128);
                addPreferencesFromResource(0x7f040003);
            }
            catch(android.content.pm.PackageManager.NameNotFoundException namenotfoundexception1)
            {
                addPreferencesFromResource(0x7f040004);
            }
        else
            addPreferencesFromResource(0x7f040002);
        KEY_REGISTER = getString(0x7f070069);
        KEY_EDIT = getString(0x7f07006a);
        KEY_EXPORT = getString(0x7f07006b);
        KEY_VERSION = getString(0x7f07006d);
        KEY_UPGRADE = getString(0x7f07006c);
        mButtonRegister = findPreference(KEY_REGISTER);
        mButtonEdit = findPreference(KEY_EDIT);
        mButtonExport = findPreference(KEY_EXPORT);
        mButtonVersion = findPreference(KEY_VERSION);
        mButtonUpgrade = findPreference(KEY_UPGRADE);
        mButtonRegister.setOnPreferenceClickListener(this);
        mButtonEdit.setOnPreferenceClickListener(this);
        mButtonVersion.setOnPreferenceClickListener(this);
        if(mButtonExport != null)
            mButtonExport.setOnPreferenceClickListener(this);
        if(mButtonUpgrade != null)
            mButtonUpgrade.setOnPreferenceClickListener(this);
        try
        {
            PackageInfo packageinfo = getPackageManager().getPackageInfo(getPackageName(), 128);
            String s = (new StringBuilder("Version ")).append(packageinfo.versionName).append("   (c) shekeen lab.").toString();
            mButtonVersion.setSummary(s);
        }
        catch(android.content.pm.PackageManager.NameNotFoundException namenotfoundexception)
        {
            namenotfoundexception.printStackTrace();
        }
        if(android.os.Build.VERSION.SDK_INT >= 14)
        {
            ActionBar actionbar = getActionBar();
            actionbar.setDisplayOptions(4, 4);
            actionbar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void onMenuExport()
    {
        String as[] = CardData.loadCardIndex(this);
        if(as == null || as.length == 0)
        {
            showNoCardError();
            return;
        }
        ArrayList arraylist = new ArrayList();
        int i = 0;
        do
        {
            if(i >= as.length)
            {
                if(arraylist.size() == 0)
                {
                    showNoCardError();
                    return;
                }
                break;
            }
            CardData carddata = new CardData(this, as[i]);
            if(!carddata.isPreset())
                arraylist.add(carddata);
            i++;
        } while(true);
        Intent intent = getPackageManager().getLaunchIntentForPackage("jp.co.shekeen.BalanceReader");
        if(intent == null)
        {
            showNoPaidPackage();
            return;
        } else
        {
            intent.setAction("jp.co.shekeen.BalanceReader.ACTION_EXPORT_CARDS");
            intent.putExtra("card list", arraylist);
            startActivity(intent);
            return;
        }
    }

    private void showNoCardError()
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle(0x7f070035);
        builder.setCancelable(false);
        builder.setPositiveButton(0x7f07003a, null);
        builder.setMessage(0x7f070059);
        builder.setIcon(0x1080027);
        builder.show();
    }

    private void showNoPaidPackage()
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle(0x7f070035);
        builder.setCancelable(false);
        builder.setPositiveButton(0x7f07003a, null);
        builder.setMessage(0x7f07005a);
        builder.setIcon(0x1080027);
        builder.show();
    }

    public void addPreferencesFromResource(int i)
    {
        if(mFragment != null)
        {
            mFragment.addPreferencesFromResource(i);
            return;
        } else
        {
            super.addPreferencesFromResource(i);
            return;
        }
    }

    public Preference findPreference(CharSequence charsequence)
    {
        if(mFragment != null)
            return mFragment.findPreference(charsequence);
        else
            return super.findPreference(charsequence);
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        if(android.os.Build.VERSION.SDK_INT >= 11)
        {
            mFragment = new SettingFragment();
            getFragmentManager().beginTransaction().replace(0x1020002, mFragment).commit();
            return;
        } else
        {
            initPreference(null);
            return;
        }
    }

    public boolean onMenuItemSelected(int i, MenuItem menuitem)
    {
        if(menuitem.getItemId() == 0x102002c)
        {
            finish();
            return true;
        } else
        {
            return super.onMenuItemSelected(i, menuitem);
        }
    }

    public boolean onPreferenceClick(Preference preference)
    {
        if(preference != mButtonRegister) goto _L2; else goto _L1
_L1:
        startActivity(new Intent(this, jp/co/shekeen/BalanceReaderFree/RegisterActivity));
_L4:
        return false;
_L2:
        if(preference == mButtonEdit)
            startActivity(new Intent(this, jp/co/shekeen/BalanceReaderFree/EditActivity));
        else
        if(preference == mButtonExport)
            onMenuExport();
        else
        if(preference == mButtonUpgrade)
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=jp.co.shekeen.BalanceReaderFree")));
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static final String PAID_PACKAGE = "jp.co.shekeen.BalanceReader";
    private String KEY_EDIT;
    private String KEY_EXPORT;
    private String KEY_REGISTER;
    private String KEY_UPGRADE;
    private String KEY_VERSION;
    Preference mButtonEdit;
    Preference mButtonExport;
    Preference mButtonRegister;
    Preference mButtonUpgrade;
    Preference mButtonVersion;
    SettingFragment mFragment;

}
