// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;


public class DebugHelper
{

    public DebugHelper()
    {
    }

    public static void print(byte abyte0[])
    {
    }

    public static transient void print(Object aobj[])
    {
    }

    public static void printStackTrace(Exception exception)
    {
    }
}
