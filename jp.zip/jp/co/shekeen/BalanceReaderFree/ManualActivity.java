// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import jp.co.shekeen.BalanceData.CardData;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            MainActivity

public class ManualActivity extends Activity
    implements TextWatcher, android.view.View.OnClickListener
{

    public ManualActivity()
    {
    }

    private CardData getCardData()
    {
        String s = mEditName.getText().toString();
        String s1 = mEditFormat.getText().toString().toUpperCase();
        if(s.length() == 0 || s1.length() != 13)
            return null;
        CardData carddata;
        try
        {
            carddata = CardData.convert(s, s1);
        }
        catch(NumberFormatException numberformatexception)
        {
            return null;
        }
        return carddata;
    }

    public void afterTextChanged(Editable editable)
    {
        String s = mEditName.getText().toString();
        String s1 = mEditFormat.getText().toString();
        if(s.length() > 0 && s1.length() == 13)
        {
            mButtonComplete.setEnabled(true);
            return;
        } else
        {
            mButtonComplete.setEnabled(false);
            return;
        }
    }

    public void beforeTextChanged(CharSequence charsequence, int i, int j, int k)
    {
    }

    public void onClick(View view)
    {
        CardData carddata;
label0:
        {
            if(view == mButtonComplete)
            {
                carddata = getCardData();
                if(carddata != null)
                    break label0;
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
                builder.setTitle(0x7f070045);
                builder.setMessage(0x7f070056);
                builder.setIcon(0x1080027);
                builder.setCancelable(false);
                builder.setPositiveButton(0x7f07003a, null);
                builder.show();
            }
            return;
        }
        carddata.save(this);
        Intent intent = new Intent(this, jp/co/shekeen/BalanceReaderFree/MainActivity);
        intent.addFlags(0x4000000);
        startActivity(intent);
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030003);
        mEditName = (EditText)findViewById(0x7f0c002d);
        mEditFormat = (EditText)findViewById(0x7f0c0030);
        mButtonComplete = (Button)findViewById(0x7f0c0020);
        mEditName.addTextChangedListener(this);
        mEditFormat.addTextChangedListener(this);
        mButtonComplete.setOnClickListener(this);
        mButtonComplete.setEnabled(false);
    }

    public void onTextChanged(CharSequence charsequence, int i, int j, int k)
    {
    }

    private Button mButtonComplete;
    private EditText mEditFormat;
    private EditText mEditName;
}
