// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;


public final class R
{
    public static final class attr
    {

        public static final int adSize = 0x7f010000;
        public static final int adSizes = 0x7f010001;
        public static final int adUnitId = 0x7f010002;
        public static final int appTheme = 0x7f010016;
        public static final int buyButtonAppearance = 0x7f01001d;
        public static final int buyButtonHeight = 0x7f01001a;
        public static final int buyButtonText = 0x7f01001c;
        public static final int buyButtonWidth = 0x7f01001b;
        public static final int cameraBearing = 0x7f010007;
        public static final int cameraTargetLat = 0x7f010008;
        public static final int cameraTargetLng = 0x7f010009;
        public static final int cameraTilt = 0x7f01000a;
        public static final int cameraZoom = 0x7f01000b;
        public static final int circleCrop = 0x7f010005;
        public static final int environment = 0x7f010017;
        public static final int fragmentMode = 0x7f010019;
        public static final int fragmentStyle = 0x7f010018;
        public static final int imageAspectRatio = 0x7f010004;
        public static final int imageAspectRatioAdjust = 0x7f010003;
        public static final int liteMode = 0x7f01000c;
        public static final int mapType = 0x7f010006;
        public static final int maskedWalletDetailsBackground = 0x7f010020;
        public static final int maskedWalletDetailsButtonBackground = 0x7f010022;
        public static final int maskedWalletDetailsButtonTextAppearance = 0x7f010021;
        public static final int maskedWalletDetailsHeaderTextAppearance = 0x7f01001f;
        public static final int maskedWalletDetailsLogoImageType = 0x7f010024;
        public static final int maskedWalletDetailsLogoTextColor = 0x7f010023;
        public static final int maskedWalletDetailsTextAppearance = 0x7f01001e;
        public static final int uiCompass = 0x7f01000d;
        public static final int uiMapToolbar = 0x7f010015;
        public static final int uiRotateGestures = 0x7f01000e;
        public static final int uiScrollGestures = 0x7f01000f;
        public static final int uiTiltGestures = 0x7f010010;
        public static final int uiZoomControls = 0x7f010011;
        public static final int uiZoomGestures = 0x7f010012;
        public static final int useViewLifecycle = 0x7f010013;
        public static final int zOrderOnTop = 0x7f010014;

        public attr()
        {
        }
    }

    public static final class color
    {

        public static final int common_action_bar_splitter = 0x7f080009;
        public static final int common_signin_btn_dark_text_default = 0x7f080000;
        public static final int common_signin_btn_dark_text_disabled = 0x7f080002;
        public static final int common_signin_btn_dark_text_focused = 0x7f080003;
        public static final int common_signin_btn_dark_text_pressed = 0x7f080001;
        public static final int common_signin_btn_default_background = 0x7f080008;
        public static final int common_signin_btn_light_text_default = 0x7f080004;
        public static final int common_signin_btn_light_text_disabled = 0x7f080006;
        public static final int common_signin_btn_light_text_focused = 0x7f080007;
        public static final int common_signin_btn_light_text_pressed = 0x7f080005;
        public static final int common_signin_btn_text_dark = 0x7f080017;
        public static final int common_signin_btn_text_light = 0x7f080018;
        public static final int wallet_bright_foreground_disabled_holo_light = 0x7f08000f;
        public static final int wallet_bright_foreground_holo_dark = 0x7f08000a;
        public static final int wallet_bright_foreground_holo_light = 0x7f080010;
        public static final int wallet_dim_foreground_disabled_holo_dark = 0x7f08000c;
        public static final int wallet_dim_foreground_holo_dark = 0x7f08000b;
        public static final int wallet_dim_foreground_inverse_disabled_holo_dark = 0x7f08000e;
        public static final int wallet_dim_foreground_inverse_holo_dark = 0x7f08000d;
        public static final int wallet_highlighted_text_holo_dark = 0x7f080014;
        public static final int wallet_highlighted_text_holo_light = 0x7f080013;
        public static final int wallet_hint_foreground_holo_dark = 0x7f080012;
        public static final int wallet_hint_foreground_holo_light = 0x7f080011;
        public static final int wallet_holo_blue_light = 0x7f080015;
        public static final int wallet_link_text_light = 0x7f080016;
        public static final int wallet_primary_text_holo_light = 0x7f080019;
        public static final int wallet_secondary_text_holo_dark = 0x7f08001a;

        public color()
        {
        }
    }

    public static final class dimen
    {

        public static final int padding_large = 0x7f0a0002;
        public static final int padding_medium = 0x7f0a0001;
        public static final int padding_small = 0x7f0a0000;

        public dimen()
        {
        }
    }

    public static final class drawable
    {

        public static final int blank = 0x7f020000;
        public static final int common_full_open_on_phone = 0x7f020001;
        public static final int common_ic_googleplayservices = 0x7f020002;
        public static final int common_signin_btn_icon_dark = 0x7f020003;
        public static final int common_signin_btn_icon_disabled_dark = 0x7f020004;
        public static final int common_signin_btn_icon_disabled_focus_dark = 0x7f020005;
        public static final int common_signin_btn_icon_disabled_focus_light = 0x7f020006;
        public static final int common_signin_btn_icon_disabled_light = 0x7f020007;
        public static final int common_signin_btn_icon_focus_dark = 0x7f020008;
        public static final int common_signin_btn_icon_focus_light = 0x7f020009;
        public static final int common_signin_btn_icon_light = 0x7f02000a;
        public static final int common_signin_btn_icon_normal_dark = 0x7f02000b;
        public static final int common_signin_btn_icon_normal_light = 0x7f02000c;
        public static final int common_signin_btn_icon_pressed_dark = 0x7f02000d;
        public static final int common_signin_btn_icon_pressed_light = 0x7f02000e;
        public static final int common_signin_btn_text_dark = 0x7f02000f;
        public static final int common_signin_btn_text_disabled_dark = 0x7f020010;
        public static final int common_signin_btn_text_disabled_focus_dark = 0x7f020011;
        public static final int common_signin_btn_text_disabled_focus_light = 0x7f020012;
        public static final int common_signin_btn_text_disabled_light = 0x7f020013;
        public static final int common_signin_btn_text_focus_dark = 0x7f020014;
        public static final int common_signin_btn_text_focus_light = 0x7f020015;
        public static final int common_signin_btn_text_light = 0x7f020016;
        public static final int common_signin_btn_text_normal_dark = 0x7f020017;
        public static final int common_signin_btn_text_normal_light = 0x7f020018;
        public static final int common_signin_btn_text_pressed_dark = 0x7f020019;
        public static final int common_signin_btn_text_pressed_light = 0x7f02001a;
        public static final int droid = 0x7f02001b;
        public static final int e = 0x7f02001c;
        public static final int eight = 0x7f02001d;
        public static final int five = 0x7f02001e;
        public static final int four = 0x7f02001f;
        public static final int google_play = 0x7f020020;
        public static final int highlight = 0x7f020021;
        public static final int ic_launcher = 0x7f020022;
        public static final int ic_plusone_medium_off_client = 0x7f020023;
        public static final int ic_plusone_small_off_client = 0x7f020024;
        public static final int ic_plusone_standard_off_client = 0x7f020025;
        public static final int ic_plusone_tall_off_client = 0x7f020026;
        public static final int ic_sysbar_menu = 0x7f020027;
        public static final int nine = 0x7f020028;
        public static final int o = 0x7f020029;
        public static final int one = 0x7f02002a;
        public static final int powered_by_google_dark = 0x7f02002b;
        public static final int powered_by_google_light = 0x7f02002c;
        public static final int r = 0x7f02002d;
        public static final int setting = 0x7f02002e;
        public static final int seven = 0x7f02002f;
        public static final int six = 0x7f020030;
        public static final int three = 0x7f020031;
        public static final int two = 0x7f020032;
        public static final int yen = 0x7f020033;
        public static final int zero = 0x7f020034;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int adjust_height = 0x7f0c0000;
        public static final int adjust_width = 0x7f0c0001;
        public static final int book_now = 0x7f0c0010;
        public static final int buttonAnalyze = 0x7f0c003c;
        public static final int buttonComplete = 0x7f0c0020;
        public static final int buttonDelete = 0x7f0c001f;
        public static final int buttonNfcSetting = 0x7f0c002a;
        public static final int buyButton = 0x7f0c000c;
        public static final int buy_now = 0x7f0c0011;
        public static final int buy_with_google = 0x7f0c0012;
        public static final int classic = 0x7f0c0014;
        public static final int donate_with_google = 0x7f0c0013;
        public static final int editBalance = 0x7f0c0039;
        public static final int editFormat = 0x7f0c0030;
        public static final int editName = 0x7f0c002d;
        public static final int grayscale = 0x7f0c0015;
        public static final int groupResult = 0x7f0c003d;
        public static final int groupSetting = 0x7f0c001c;
        public static final int holo_dark = 0x7f0c0007;
        public static final int holo_light = 0x7f0c0008;
        public static final int hybrid = 0x7f0c0003;
        public static final int image1stDigit = 0x7f0c0028;
        public static final int image2ndDigit = 0x7f0c0027;
        public static final int image3rdDigit = 0x7f0c0026;
        public static final int image4thDigit = 0x7f0c0025;
        public static final int image5thDigit = 0x7f0c0024;
        public static final int imageSetting = 0x7f0c0023;
        public static final int imageYen = 0x7f0c0029;
        public static final int layoutAd = 0x7f0c002b;
        public static final int match_parent = 0x7f0c000e;
        public static final int menu_settings = 0x7f0c003f;
        public static final int monochrome = 0x7f0c0016;
        public static final int none = 0x7f0c0002;
        public static final int normal = 0x7f0c0004;
        public static final int production = 0x7f0c0009;
        public static final int progressAnalyze = 0x7f0c0019;
        public static final int sandbox = 0x7f0c000a;
        public static final int satellite = 0x7f0c0005;
        public static final int selectionDetails = 0x7f0c000d;
        public static final int spinnerCard = 0x7f0c001b;
        public static final int strict_sandbox = 0x7f0c000b;
        public static final int terrain = 0x7f0c0006;
        public static final int textBalance = 0x7f0c002f;
        public static final int textHelp1 = 0x7f0c0033;
        public static final int textHelp2 = 0x7f0c0034;
        public static final int textHelp3 = 0x7f0c0035;
        public static final int textHelp4 = 0x7f0c0036;
        public static final int textHelp5 = 0x7f0c0037;
        public static final int textLeft = 0x7f0c0031;
        public static final int textName = 0x7f0c002c;
        public static final int textSpace = 0x7f0c001d;
        public static final int textSpace1 = 0x7f0c0018;
        public static final int textSpace2 = 0x7f0c001a;
        public static final int textSpacer = 0x7f0c0022;
        public static final int textSpacer1 = 0x7f0c0032;
        public static final int textSpacer2 = 0x7f0c002e;
        public static final int textSpacer3 = 0x7f0c0038;
        public static final int textStatus = 0x7f0c0017;
        public static final int textView1 = 0x7f0c0021;
        public static final int textView4 = 0x7f0c003e;
        public static final int textWarning = 0x7f0c001e;
        public static final int textWarning1 = 0x7f0c003b;
        public static final int textYen = 0x7f0c003a;
        public static final int wrap_content = 0x7f0c000f;

        public id()
        {
        }
    }

    public static final class integer
    {

        public static final int google_play_services_version = 0x7f090000;

        public integer()
        {
        }
    }

    public static final class layout
    {

        public static final int analyze = 0x7f030000;
        public static final int edit = 0x7f030001;
        public static final int main = 0x7f030002;
        public static final int manual = 0x7f030003;
        public static final int register = 0x7f030004;
        public static final int result = 0x7f030005;

        public layout()
        {
        }
    }

    public static final class menu
    {

        public static final int activity_main = 0x7f0b0000;

        public menu()
        {
        }
    }

    public static final class raw
    {

        public static final int gtm_analytics = 0x7f050000;

        public raw()
        {
        }
    }

    public static final class string
    {

        public static final int accept = 0x7f070002;
        public static final int app_name = 0x7f070023;
        public static final int balance = 0x7f070031;
        public static final int block_position = 0x7f07002d;
        public static final int button_complete = 0x7f070039;
        public static final int button_next = 0x7f070037;
        public static final int button_nfc_setting = 0x7f07005b;
        public static final int button_ok = 0x7f07003a;
        public static final int button_register = 0x7f070038;
        public static final int category_about = 0x7f07005f;
        public static final int category_advanced = 0x7f07005e;
        public static final int category_basic = 0x7f07005d;
        public static final int character = 0x7f070050;
        public static final int common_android_wear_notification_needs_update_text = 0x7f070009;
        public static final int common_android_wear_update_text = 0x7f070016;
        public static final int common_android_wear_update_title = 0x7f070014;
        public static final int common_google_play_services_enable_button = 0x7f070012;
        public static final int common_google_play_services_enable_text = 0x7f070011;
        public static final int common_google_play_services_enable_title = 0x7f070010;
        public static final int common_google_play_services_error_notification_requested_by_msg = 0x7f07000b;
        public static final int common_google_play_services_install_button = 0x7f07000f;
        public static final int common_google_play_services_install_text_phone = 0x7f07000d;
        public static final int common_google_play_services_install_text_tablet = 0x7f07000e;
        public static final int common_google_play_services_install_title = 0x7f07000c;
        public static final int common_google_play_services_invalid_account_text = 0x7f07001a;
        public static final int common_google_play_services_invalid_account_title = 0x7f070019;
        public static final int common_google_play_services_needs_enabling_title = 0x7f07000a;
        public static final int common_google_play_services_network_error_text = 0x7f070018;
        public static final int common_google_play_services_network_error_title = 0x7f070017;
        public static final int common_google_play_services_notification_needs_installation_title = 0x7f070007;
        public static final int common_google_play_services_notification_needs_update_title = 0x7f070008;
        public static final int common_google_play_services_notification_ticker = 0x7f070006;
        public static final int common_google_play_services_unknown_issue = 0x7f07001b;
        public static final int common_google_play_services_unsupported_text = 0x7f07001d;
        public static final int common_google_play_services_unsupported_title = 0x7f07001c;
        public static final int common_google_play_services_update_button = 0x7f07001e;
        public static final int common_google_play_services_update_text = 0x7f070015;
        public static final int common_google_play_services_update_title = 0x7f070013;
        public static final int common_open_on_phone = 0x7f070021;
        public static final int common_signin_button_text = 0x7f07001f;
        public static final int common_signin_button_text_long = 0x7f070020;
        public static final int confirm = 0x7f070045;
        public static final int create_calendar_message = 0x7f070005;
        public static final int create_calendar_title = 0x7f070004;
        public static final int decline = 0x7f070003;
        public static final int delete_item = 0x7f070040;
        public static final int error_invalid_format = 0x7f070056;
        public static final int error_limit = 0x7f070042;
        public static final int error_setting_not_found = 0x7f07005c;
        public static final int export_failed = 0x7f070058;
        public static final int export_nocard = 0x7f070059;
        public static final int export_nopackage = 0x7f07005a;
        public static final int export_succeeded = 0x7f070057;
        public static final int format = 0x7f07004e;
        public static final int help_algorithm = 0x7f070055;
        public static final int help_block_position = 0x7f070053;
        public static final int help_data_address = 0x7f070054;
        public static final int help_service_code = 0x7f070052;
        public static final int help_system_code = 0x7f070051;
        public static final int info_delete = 0x7f070043;
        public static final int input_card_name = 0x7f07003e;
        public static final int input_format = 0x7f07004d;
        public static final int key_edit = 0x7f07006a;
        public static final int key_export = 0x7f07006b;
        public static final int key_nfc_link = 0x7f070068;
        public static final int key_register = 0x7f070069;
        public static final int key_timeout = 0x7f07006e;
        public static final int key_upgrade = 0x7f07006c;
        public static final int key_version = 0x7f07006d;
        public static final int left = 0x7f07004f;
        public static final int menu_edit = 0x7f070034;
        public static final int menu_export = 0x7f070035;
        public static final int menu_register = 0x7f070033;
        public static final int menu_settings = 0x7f070024;
        public static final int menu_upgrade = 0x7f070036;
        public static final int no = 0x7f070047;
        public static final int pass_felica = 0x7f07003b;
        public static final int pref_summary_auto = 0x7f07004b;
        public static final int pref_summary_manual = 0x7f07004a;
        public static final int pref_title_auto = 0x7f070049;
        public static final int pref_title_manual = 0x7f070048;
        public static final int pref_warning_felica = 0x7f07004c;
        public static final int register = 0x7f07002f;
        public static final int select_item = 0x7f07003f;
        public static final int service_code = 0x7f07002c;
        public static final int start_address = 0x7f07002e;
        public static final int store_picture_message = 0x7f070001;
        public static final int store_picture_title = 0x7f070000;
        public static final int summary_edit = 0x7f070064;
        public static final int summary_export = 0x7f070065;
        public static final int summary_nfc_link = 0x7f070062;
        public static final int summary_register = 0x7f070063;
        public static final int summary_timeout = 0x7f070067;
        public static final int summary_upgrade = 0x7f070066;
        public static final int system_code = 0x7f07002b;
        public static final int text_balance = 0x7f070028;
        public static final int text_nfc_ready = 0x7f070026;
        public static final int text_nfc_unavailable = 0x7f070027;
        public static final int text_reading = 0x7f07002a;
        public static final int text_try_again = 0x7f070029;
        public static final int title_activity_main = 0x7f070025;
        public static final int title_nfc_link = 0x7f070060;
        public static final int title_timeout = 0x7f070061;
        public static final int wallet_buy_button_place_holder = 0x7f070022;
        public static final int warning_balance = 0x7f070032;
        public static final int warning_duplicated = 0x7f070044;
        public static final int warning_felica = 0x7f07003c;
        public static final int warning_no_item = 0x7f070041;
        public static final int warning_selection = 0x7f07003d;
        public static final int yen = 0x7f070030;
        public static final int yes = 0x7f070046;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppBaseTheme = 0x7f060005;
        public static final int AppTheme = 0x7f060006;
        public static final int DialogTheme = 0x7f060007;
        public static final int Theme_IAPTheme = 0x7f060000;
        public static final int WalletFragmentDefaultButtonTextAppearance = 0x7f060003;
        public static final int WalletFragmentDefaultDetailsHeaderTextAppearance = 0x7f060002;
        public static final int WalletFragmentDefaultDetailsTextAppearance = 0x7f060001;
        public static final int WalletFragmentDefaultStyle = 0x7f060004;

        public style()
        {
        }
    }

    public static final class styleable
    {

        public static final int AdsAttrs[] = {
            0x7f010000, 0x7f010001, 0x7f010002
        };
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int LoadingImageView[] = {
            0x7f010003, 0x7f010004, 0x7f010005
        };
        public static final int LoadingImageView_circleCrop = 2;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 0;
        public static final int MapAttrs[] = {
            0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 0x7f01000c, 0x7f01000d, 0x7f01000e, 0x7f01000f, 
            0x7f010010, 0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015
        };
        public static final int MapAttrs_cameraBearing = 1;
        public static final int MapAttrs_cameraTargetLat = 2;
        public static final int MapAttrs_cameraTargetLng = 3;
        public static final int MapAttrs_cameraTilt = 4;
        public static final int MapAttrs_cameraZoom = 5;
        public static final int MapAttrs_liteMode = 6;
        public static final int MapAttrs_mapType = 0;
        public static final int MapAttrs_uiCompass = 7;
        public static final int MapAttrs_uiMapToolbar = 15;
        public static final int MapAttrs_uiRotateGestures = 8;
        public static final int MapAttrs_uiScrollGestures = 9;
        public static final int MapAttrs_uiTiltGestures = 10;
        public static final int MapAttrs_uiZoomControls = 11;
        public static final int MapAttrs_uiZoomGestures = 12;
        public static final int MapAttrs_useViewLifecycle = 13;
        public static final int MapAttrs_zOrderOnTop = 14;
        public static final int WalletFragmentOptions[] = {
            0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019
        };
        public static final int WalletFragmentOptions_appTheme = 0;
        public static final int WalletFragmentOptions_environment = 1;
        public static final int WalletFragmentOptions_fragmentMode = 3;
        public static final int WalletFragmentOptions_fragmentStyle = 2;
        public static final int WalletFragmentStyle[] = {
            0x7f01001a, 0x7f01001b, 0x7f01001c, 0x7f01001d, 0x7f01001e, 0x7f01001f, 0x7f010020, 0x7f010021, 0x7f010022, 0x7f010023, 
            0x7f010024
        };
        public static final int WalletFragmentStyle_buyButtonAppearance = 3;
        public static final int WalletFragmentStyle_buyButtonHeight = 0;
        public static final int WalletFragmentStyle_buyButtonText = 2;
        public static final int WalletFragmentStyle_buyButtonWidth = 1;
        public static final int WalletFragmentStyle_maskedWalletDetailsBackground = 6;
        public static final int WalletFragmentStyle_maskedWalletDetailsButtonBackground = 8;
        public static final int WalletFragmentStyle_maskedWalletDetailsButtonTextAppearance = 7;
        public static final int WalletFragmentStyle_maskedWalletDetailsHeaderTextAppearance = 5;
        public static final int WalletFragmentStyle_maskedWalletDetailsLogoImageType = 10;
        public static final int WalletFragmentStyle_maskedWalletDetailsLogoTextColor = 9;
        public static final int WalletFragmentStyle_maskedWalletDetailsTextAppearance = 4;


        public styleable()
        {
        }
    }

    public static final class xml
    {

        public static final int nfc_filter = 0x7f040000;
        public static final int select = 0x7f040001;
        public static final int setting = 0x7f040002;
        public static final int setting_export = 0x7f040003;
        public static final int setting_free = 0x7f040004;

        public xml()
        {
        }
    }


    public R()
    {
    }
}
