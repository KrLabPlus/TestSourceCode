// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.tech.NfcF;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.util.ArrayList;
import jp.co.shekeen.FelicaTech.Felica;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            AnalyzerThread, ResultActivity, DebugHelper

public class AnalyzeActivity extends Activity
    implements AnalyzerThread.IAnalyzerListener
{

    public AnalyzeActivity()
    {
        mAnalyzing = false;
    }

    private void startAnalyze(Intent intent)
    {
        if(mAnalyzing)
        {
            return;
        } else
        {
            mAnalyzing = true;
            mTextStatus.setText("��͒��c");
            mProgressAnalyze.setVisibility(0);
            (new AnalyzerThread(this, Felica.getInstance(intent), mBalance)).start();
            return;
        }
    }

    public void onAnalyzeFailed()
    {
        mAnalyzing = false;
        mProgressAnalyze.setVisibility(4);
        mTextStatus.setText("��͂Ɏ��s���܂���");
    }

    public void onAnalyzeRetry()
    {
        mAnalyzing = false;
        mProgressAnalyze.setVisibility(4);
        mTextStatus.setText("�����P�x�������ĉ�����");
    }

    public void onAnalyzeSucceeded(ArrayList arraylist)
    {
        mAnalyzing = false;
        mProgressAnalyze.setVisibility(4);
        mTextStatus.setText("��͊����I");
        Intent intent = new Intent(this, jp/co/shekeen/BalanceReaderFree/ResultActivity);
        intent.putExtra("candidate", arraylist);
        startActivity(intent);
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030000);
        Bundle bundle1 = getIntent().getExtras();
        if(bundle1 != null)
            mBalance = bundle1.getInt("balance");
        mTextStatus = (TextView)findViewById(0x7f0c0017);
        mProgressAnalyze = (ProgressBar)findViewById(0x7f0c0019);
        if(mBalance < 256)
            mTextStatus.setText(getString(0x7f070032));
        Object aobj[] = new Object[1];
        aobj[0] = (new StringBuilder("onCreate balance = ")).append(String.valueOf(mBalance)).toString();
        DebugHelper.print(aobj);
    }

    protected void onNewIntent(Intent intent)
    {
        if("android.nfc.action.TECH_DISCOVERED".equals(intent.getAction()))
        {
            DebugHelper.print(new Object[] {
                "TECH_DISCOVERED"
            });
            startAnalyze(intent);
        }
    }

    protected void onPause()
    {
        if(isFinishing())
            NfcAdapter.getDefaultAdapter(this).disableForegroundDispatch(this);
        super.onPause();
    }

    protected void onResume()
    {
        IntentFilter intentfilter = new IntentFilter("android.nfc.action.TECH_DISCOVERED");
        IntentFilter aintentfilter[];
        Intent intent;
        PendingIntent pendingintent;
        String as[][];
        String as1[];
        try
        {
            intentfilter.addDataType("*/*");
        }
        catch(android.content.IntentFilter.MalformedMimeTypeException malformedmimetypeexception)
        {
            DebugHelper.print(new Object[] {
                "MalformedMimeTypeException"
            });
            return;
        }
        aintentfilter = (new IntentFilter[] {
            intentfilter
        });
        intent = new Intent(this, getClass());
        intent.addFlags(0x20000000);
        pendingintent = PendingIntent.getActivity(this, 0, intent, 0);
        as = new String[1][];
        as1 = new String[1];
        as1[0] = android/nfc/tech/NfcF.getName();
        as[0] = as1;
        NfcAdapter.getDefaultAdapter(this).enableForegroundDispatch(this, pendingintent, aintentfilter, as);
        super.onResume();
    }

    public static final String EXTRA_BALANCE = "balance";
    private boolean mAnalyzing;
    private int mBalance;
    private ProgressBar mProgressAnalyze;
    private TextView mTextStatus;
}
