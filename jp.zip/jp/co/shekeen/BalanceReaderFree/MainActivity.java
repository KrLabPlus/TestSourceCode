// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.*;
import android.graphics.Rect;
import android.nfc.NfcAdapter;
import android.nfc.tech.NfcF;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.*;
import android.widget.*;
import com.google.android.gms.ads.*;
import java.util.ArrayList;
import jp.co.shekeen.BalanceData.CardData;
import jp.co.shekeen.FelicaTech.Felica;
import jp.co.shekeen.FelicaTech.FelicaUserFactory;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            DebugHelper, FelicaScanner, SettingActivity, Config

public class MainActivity extends Activity
    implements android.content.DialogInterface.OnClickListener, android.view.View.OnClickListener, android.view.View.OnTouchListener, FelicaScanner.FelicaScannerCallback
{

    public MainActivity()
    {
        mImageDigit = new ImageView[5];
        mDisabled = false;
    }

    private void clearView()
    {
        int i = 0;
        do
        {
            if(i >= mImageDigit.length)
                return;
            mImageDigit[i].setImageResource(0x7f020000);
            i++;
        } while(true);
    }

    private void importCards(Bundle bundle)
    {
        boolean flag = saveReceivedCards(bundle);
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle(0x7f070035);
        builder.setCancelable(false);
        builder.setPositiveButton(0x7f07003a, this);
        if(flag)
        {
            builder.setMessage(0x7f070057);
            builder.setIcon(0x108009b);
        } else
        {
            builder.setMessage(0x7f070058);
            builder.setIcon(0x1080027);
        }
        builder.show();
    }

    private boolean isNfcAvailable()
    {
        return NfcAdapter.getDefaultAdapter(this) != null && NfcAdapter.getDefaultAdapter(this).isEnabled();
    }

    private void loadPlugin(FelicaUserFactory felicauserfactory)
    {
        String as[] = CardData.loadCardIndex(this);
        if(as != null && as.length >= 1)
        {
            int i = 0;
            while(i < as.length) 
            {
                felicauserfactory.addPlugin((new CardData(this, as[i])).toPlugin());
                Object aobj[] = new Object[3];
                aobj[0] = Integer.valueOf(i);
                aobj[1] = ":";
                aobj[2] = as[i];
                DebugHelper.print(aobj);
                i++;
            }
        }
    }

    private boolean saveReceivedCards(Bundle bundle)
    {
        ArrayList arraylist;
        if(bundle != null)
            if((arraylist = (ArrayList)bundle.get("card list")) != null)
            {
                int i = 0;
                do
                {
                    if(i >= arraylist.size())
                        return true;
                    ((CardData)arraylist.get(i)).save(this);
                    i++;
                } while(true);
            }
        return false;
    }

    private void setBalanceView(String s)
    {
        int ai[] = {
            0x7f020034, 0x7f02002a, 0x7f020032, 0x7f020031, 0x7f02001f, 0x7f02001e, 0x7f020030, 0x7f02002f, 0x7f02001d, 0x7f020028
        };
        clearView();
        int i = 0;
        int j = -1 + s.length();
        do
        {
            if(j < 0)
            {
                mImageYen.setVisibility(0);
                return;
            }
            int k = -48 + s.charAt(j);
            if(k < 0 || k > 9)
            {
                setErrorView();
                return;
            }
            mImageDigit[i].setImageResource(ai[k]);
            i++;
            j--;
        } while(true);
    }

    private void setErrorView()
    {
        mTextStatus.setText(0x7f070029);
        mImageDigit[4].setImageResource(0x7f02001c);
        mImageDigit[3].setImageResource(0x7f02002d);
        mImageDigit[2].setImageResource(0x7f02002d);
        mImageDigit[1].setImageResource(0x7f020029);
        mImageDigit[0].setImageResource(0x7f02002d);
        mImageYen.setVisibility(4);
    }

    private void startScan(Intent intent)
    {
        if(mScanner != null)
        {
            mScanner.cancel();
            mScanner = null;
        }
        boolean flag = PreferenceManager.getDefaultSharedPreferences(this).getBoolean(getString(0x7f07006e), false);
        Felica felica = Felica.getInstance(intent);
        if(felica == null)
        {
            return;
        } else
        {
            Object aobj[] = new Object[2];
            aobj[0] = "TIMEOUT";
            aobj[1] = Boolean.valueOf(flag);
            DebugHelper.print(aobj);
            felica.enableTimeout(flag);
            FelicaUserFactory felicauserfactory = new FelicaUserFactory(felica);
            loadPlugin(felicauserfactory);
            mScanner = new FelicaScanner(felicauserfactory, this);
            mScanner.start();
            return;
        }
    }

    private void updateNfcSetting(boolean flag)
    {
        boolean flag1 = isNfcAvailable();
        boolean flag2;
        boolean flag3;
        if(!flag && mOldNfcAvailable == flag1)
            flag2 = false;
        else
            flag2 = true;
        flag3 = PreferenceManager.getDefaultSharedPreferences(this).getBoolean(getString(0x7f070068), false);
        mOldNfcAvailable = flag1;
        if(flag1)
        {
            if(flag2)
                mTextStatus.setText(0x7f070026);
            if(flag3)
                mButtonNfcSetting.setVisibility(0);
            else
                mButtonNfcSetting.setVisibility(8);
            mDisabled = false;
            return;
        }
        if(flag2)
            mTextStatus.setText(0x7f070027);
        mButtonNfcSetting.setVisibility(0);
        mDisabled = true;
    }

    public void onClick(DialogInterface dialoginterface, int i)
    {
        finish();
    }

    public void onClick(View view)
    {
        if(view != mButtonNfcSetting)
            break MISSING_BLOCK_LABEL_52;
        startActivity(new Intent("android.settings.NFC_SETTINGS"));
_L1:
        return;
        ActivityNotFoundException activitynotfoundexception;
        activitynotfoundexception;
        try
        {
            startActivity(new Intent("android.settings.AIRPLANE_MODE_SETTINGS"));
            return;
        }
        catch(ActivityNotFoundException activitynotfoundexception1)
        {
            Toast.makeText(this, 0x7f07005c, 1).show();
        }
        return;
        if(view == mImageSetting)
        {
            startActivity(new Intent(this, jp/co/shekeen/BalanceReaderFree/SettingActivity));
            return;
        }
          goto _L1
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030002);
        Config.initialize(this);
        Intent intent = getIntent();
        mTextStatus = (TextView)findViewById(0x7f0c0017);
        mImageSetting = (ImageView)findViewById(0x7f0c0023);
        mImageSetting.setOnClickListener(this);
        mImageSetting.setOnTouchListener(this);
        String s;
        Bundle bundle1;
        if(Config.FREE)
        {
            mAdView = new AdView(this);
            mAdView.setAdUnitId("ca-app-pub-3894688502720171/9034184641");
            mAdView.setAdSize(AdSize.BANNER);
            mAdView.setAdListener(new AdListener() {

                public void onAdLoaded()
                {
                    super.onAdLoaded();
                    mAdLayout.setVisibility(0);
                }

                final MainActivity this$0;

            
            {
                this$0 = MainActivity.this;
                super();
            }
            }
);
            mAdLayout = (LinearLayout)findViewById(0x7f0c002b);
            mAdLayout.addView(mAdView);
            mAdLayout.setVisibility(8);
            mAdView.loadAd((new com.google.android.gms.ads.AdRequest.Builder()).addTestDevice(AdRequest.DEVICE_ID_EMULATOR).addTestDevice("1D81EC49F3EF570E927B26E95E425250").addTestDevice("5F346356CF3D3654DC83FB19F201E2D1").build());
        } else
        {
            mAdView = null;
        }
        mButtonNfcSetting = (Button)findViewById(0x7f0c002a);
        mButtonNfcSetting.setOnClickListener(this);
        mImageDigit[0] = (ImageView)findViewById(0x7f0c0028);
        mImageDigit[1] = (ImageView)findViewById(0x7f0c0027);
        mImageDigit[2] = (ImageView)findViewById(0x7f0c0026);
        mImageDigit[3] = (ImageView)findViewById(0x7f0c0025);
        mImageDigit[4] = (ImageView)findViewById(0x7f0c0024);
        mImageYen = (ImageView)findViewById(0x7f0c0029);
        CardData.checkPresetVersion(this);
        s = intent.getAction();
        bundle1 = intent.getExtras();
        if("android.nfc.action.TECH_DISCOVERED".equals(s))
        {
            mTextStatus.setText(0x7f07002a);
            clearView();
            startScan(intent);
        } else
        if("jp.co.shekeen.BalanceReader.ACTION_EXPORT_CARDS".equals(s))
            importCards(bundle1);
        else
            mTextStatus.setText(0x7f070026);
        mOldNfcAvailable = isNfcAvailable();
        updateNfcSetting(true);
        mTouchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
    }

    protected void onDestroy()
    {
        if(mAdView != null)
            mAdView.destroy();
        super.onDestroy();
    }

    protected void onNewIntent(Intent intent)
    {
        String s = intent.getAction();
        Bundle bundle = intent.getExtras();
        if("android.nfc.action.TECH_DISCOVERED".equals(s))
        {
            mTextStatus.setText(0x7f07002a);
            clearView();
            startScan(intent);
        } else
        if("jp.co.shekeen.BalanceReader.ACTION_EXPORT_CARDS".equals(s))
        {
            importCards(bundle);
            return;
        }
    }

    protected void onPause()
    {
        if(mDisabled)
        {
            super.onPause();
            return;
        }
        if(mScanner != null)
        {
            mScanner.cancel();
            mScanner = null;
        }
        if(isFinishing())
            NfcAdapter.getDefaultAdapter(this).disableForegroundDispatch(this);
        if(mAdView != null)
            mAdView.pause();
        super.onPause();
    }

    protected void onResume()
    {
        DebugHelper.print(new Object[] {
            "onResume"
        });
        updateNfcSetting(false);
        if(mDisabled)
        {
            super.onResume();
        } else
        {
            IntentFilter intentfilter = new IntentFilter("android.nfc.action.TECH_DISCOVERED");
            IntentFilter aintentfilter[];
            Intent intent;
            PendingIntent pendingintent;
            String as[][];
            String as1[];
            try
            {
                intentfilter.addDataType("*/*");
            }
            catch(android.content.IntentFilter.MalformedMimeTypeException malformedmimetypeexception)
            {
                DebugHelper.print(new Object[] {
                    "MalformedMimeTypeException"
                });
                return;
            }
            aintentfilter = (new IntentFilter[] {
                intentfilter
            });
            intent = new Intent(this, getClass());
            intent.addFlags(0x20000000);
            pendingintent = PendingIntent.getActivity(this, 0, intent, 0);
            as = new String[1][];
            as1 = new String[1];
            as1[0] = android/nfc/tech/NfcF.getName();
            as[0] = as1;
            NfcAdapter.getDefaultAdapter(this).enableForegroundDispatch(this, pendingintent, aintentfilter, as);
            super.onResume();
            if(mAdView != null)
            {
                mAdView.resume();
                return;
            }
        }
    }

    public void onScanFinished(jp.co.shekeen.FelicaTech.FelicaUserFactory.BalanceResult balanceresult)
    {
        mScanner = null;
        if(balanceresult != null)
        {
            mTextStatus.setText(0x7f070028);
            setBalanceView(balanceresult.balance);
            CardData.moveCardToTop(this, balanceresult.index);
            return;
        } else
        {
            setErrorView();
            return;
        }
    }

    public boolean onTouch(View view, MotionEvent motionevent)
    {
        int i = motionevent.getActionMasked();
        if(i == 3 || i == 1)
        {
            mImageSetting.setBackgroundResource(0);
        } else
        {
            if(i == 0)
            {
                mImageSetting.setBackgroundResource(0x7f020021);
                return false;
            }
            if(i == 2)
            {
                if(!(new Rect(-mTouchSlop, -mTouchSlop, view.getWidth() + mTouchSlop, view.getHeight() + mTouchSlop)).contains((int)motionevent.getX(), (int)motionevent.getY()))
                    mImageSetting.setBackgroundResource(0);
                Object aobj[] = new Object[4];
                aobj[0] = Float.valueOf(motionevent.getX());
                aobj[1] = Float.valueOf(motionevent.getY());
                aobj[2] = Integer.valueOf(view.getLeft());
                aobj[3] = Integer.valueOf(view.getTop());
                DebugHelper.print(aobj);
                return false;
            }
        }
        return false;
    }

    public static final String ACTION_EXPORT_CARDS = "jp.co.shekeen.BalanceReader.ACTION_EXPORT_CARDS";
    public static final String EXTRA_CARD_LIST = "card list";
    private LinearLayout mAdLayout;
    private AdView mAdView;
    private Button mButtonNfcSetting;
    private boolean mDisabled;
    private ImageView mImageDigit[];
    private ImageView mImageSetting;
    private ImageView mImageYen;
    private boolean mOldNfcAvailable;
    private FelicaScanner mScanner;
    private TextView mTextStatus;
    private int mTouchSlop;

}
