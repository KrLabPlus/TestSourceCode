// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) ansi 

package jp.co.shekeen.BalanceReaderFree;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import jp.co.shekeen.BalanceData.CandidateInfo;
import jp.co.shekeen.BalanceData.CardData;

// Referenced classes of package jp.co.shekeen.BalanceReaderFree:
//            SettingActivity

public class EditActivity extends Activity
    implements android.view.View.OnClickListener, android.widget.AdapterView.OnItemSelectedListener
{

    public EditActivity()
    {
        mRadioIdOffset = 5;
    }

    private void onClickComplete()
    {
        int j;
        if(mCardList == null || mDeleteList == null)
            return;
        int i = mGroupSetting.getCheckedRadioButtonId() - mRadioIdOffset;
        if(i >= 0)
            ((CardData)mCardList.get(mCurrentCard)).setSelectedIndex(i);
        j = 0;
_L3:
        if(j < mDeleteList.size()) goto _L2; else goto _L1
_L1:
        int k = 0;
_L4:
        if(k >= mCardList.size())
        {
            Intent intent = new Intent(this, jp/co/shekeen/BalanceReaderFree/SettingActivity);
            intent.addFlags(0x4000000);
            startActivity(intent);
            return;
        }
        break MISSING_BLOCK_LABEL_124;
_L2:
        ((CardData)mDeleteList.get(j)).delete(this);
        j++;
          goto _L3
        ((CardData)mCardList.get(k)).save(this);
        k++;
          goto _L4
    }

    private void onClickDelete()
    {
        CardData carddata = (CardData)mCardList.remove(mCurrentCard);
        mDeleteList.add(carddata);
        if(mCurrentCard > 0)
            mCurrentCard = -1 + mCurrentCard;
        updateSpinner();
        Toast.makeText(this, 0x7f070043, 0).show();
    }

    private void setNoItem()
    {
        mSpinnerCard.setEnabled(false);
        mTextStatus.setText(getString(0x7f070041));
        mButtonDelete.setEnabled(false);
    }

    private void updateRadioGroup(CardData carddata)
    {
        mGroupSetting.clearCheck();
        mGroupSetting.removeAllViewsInLayout();
        mRadioIdOffset = 1 + mRadioIdOffset;
        CandidateInfo acandidateinfo[];
        if(carddata != null)
            if((acandidateinfo = carddata.getCandidateList()) != null && acandidateinfo.length != 0)
            {
                int i = carddata.getSelectedIndex();
                int j = 0;
                do
                {
                    if(j >= acandidateinfo.length)
                    {
                        mGroupSetting.check(i + mRadioIdOffset);
                        return;
                    }
                    RadioButton radiobutton = new RadioButton(this);
                    radiobutton.setText(acandidateinfo[j].toString());
                    radiobutton.setTextAppearance(this, 0x1030042);
                    mGroupSetting.addView(radiobutton);
                    radiobutton.setId(j + mRadioIdOffset);
                    j++;
                } while(true);
            }
    }

    private void updateSpinner()
    {
        if(mCardList == null)
            return;
        String as[] = new String[mCardList.size()];
        int i = 0;
        do
        {
            if(i >= mCardList.size())
            {
                ArrayAdapter arrayadapter = new ArrayAdapter(this, 0x1090008, as);
                arrayadapter.setDropDownViewResource(0x1090009);
                mSpinnerCard.setAdapter(arrayadapter);
                if(mCardList.size() == 0)
                {
                    setNoItem();
                    updateRadioGroup(null);
                    return;
                } else
                {
                    mSpinnerCard.setSelection(mCurrentCard);
                    return;
                }
            }
            as[i] = ((CardData)mCardList.get(i)).getName();
            i++;
        } while(true);
    }

    public void onClick(View view)
    {
        if(view == mButtonDelete)
            onClickDelete();
        else
        if(view == mButtonComplete)
        {
            onClickComplete();
            return;
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030001);
        mSpinnerCard = (Spinner)findViewById(0x7f0c001b);
        mGroupSetting = (RadioGroup)findViewById(0x7f0c001c);
        mButtonDelete = (Button)findViewById(0x7f0c001f);
        mButtonComplete = (Button)findViewById(0x7f0c0020);
        mTextStatus = (TextView)findViewById(0x7f0c0017);
        mButtonDelete.setOnClickListener(this);
        mButtonComplete.setOnClickListener(this);
        mCardList = new ArrayList();
        mDeleteList = new ArrayList();
        String as[] = CardData.loadCardIndex(this);
        if(as == null || as.length == 0)
        {
            setNoItem();
            return;
        }
        int i = 0;
        int j = 0;
        do
        {
            if(j >= as.length)
            {
                mCurrentCard = i;
                if(mCurrentCard >= mCardList.size())
                    mCurrentCard = 0;
                updateSpinner();
                mSpinnerCard.setOnItemSelectedListener(this);
                updateRadioGroup((CardData)mCardList.get(0));
                return;
            }
            CardData carddata = new CardData(this, as[j]);
            if(carddata.isPreset())
            {
                mCardList.add(i, carddata);
                i++;
            } else
            {
                mCardList.add(carddata);
            }
            j++;
        } while(true);
    }

    public void onItemSelected(AdapterView adapterview, View view, int i, long l)
    {
        int j;
        if(i >= 0 && i < mCardList.size())
            if((j = mGroupSetting.getCheckedRadioButtonId() - mRadioIdOffset) >= 0)
            {
                ((CardData)mCardList.get(mCurrentCard)).setSelectedIndex(j);
                updateRadioGroup((CardData)mCardList.get(i));
                mCurrentCard = i;
                return;
            }
    }

    public void onNothingSelected(AdapterView adapterview)
    {
    }

    private Button mButtonComplete;
    private Button mButtonDelete;
    private ArrayList mCardList;
    private int mCurrentCard;
    private ArrayList mDeleteList;
    private RadioGroup mGroupSetting;
    private int mRadioIdOffset;
    private Spinner mSpinnerCard;
    private TextView mTextStatus;
}
