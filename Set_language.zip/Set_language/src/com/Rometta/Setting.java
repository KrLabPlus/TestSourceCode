package com.Rometta;

import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class Setting extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		int menu_key = i.getIntExtra("key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("it");
			  reload(key);
			  break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("key", key);
		startActivity(reload);
	}
}
