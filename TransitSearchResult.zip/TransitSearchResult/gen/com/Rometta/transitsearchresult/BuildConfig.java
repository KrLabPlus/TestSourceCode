/** Automatically generated file. DO NOT MODIFY */
package com.Rometta.transitsearchresult;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}