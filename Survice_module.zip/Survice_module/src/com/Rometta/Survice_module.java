package com.Rometta;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class Survice_module extends Activity implements OnClickListener{
	private ImageButton btn1;
	private ImageButton btn2;
	private ImageButton btn3;
	private ImageButton btn4;
	private ImageButton btn5;
	private Button btn6;
	private Button btn7;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_survice_module);

	    btn1 = (ImageButton)findViewById(R.id.ic_card);
	    btn2 = (ImageButton)findViewById(R.id.one_day);
	    btn3 = (ImageButton)findViewById(R.id.teiki);
	    btn4 = (ImageButton)findViewById(R.id.okyaku);
	    btn5 = (ImageButton)findViewById(R.id.heart);
	    btn6 = (Button)findViewById(R.id.teiki2);
	    btn7 = (Button)findViewById(R.id.odekake);

	    btn1.setOnClickListener(this);
	    btn2.setOnClickListener(this);
	    btn3.setOnClickListener(this);
	    btn4.setOnClickListener(this);
	    btn5.setOnClickListener(this);
	    btn6.setOnClickListener(this);
	    btn7.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.survice_module, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
    public void onClick(View v) {
		Intent set = new Intent();
		switch (v.getId()) {
		case R.id.ic_card:
			set.setClassName("com.Rometta","com.Rometta.Survice_ic");
			startActivity(set);
		case R.id.heart:
			set.setClassName("com.Rometta","com.Rometta.Survice_heart");
			startActivity(set);
		case R.id.odekake:
			set.setClassName("com.Rometta","com.Rometta.Survice_odekake");
			startActivity(set);
		case R.id.okyaku:
			set.setClassName("com.Rometta","com.Rometta.Survice_okyaku");
			startActivity(set);
		case R.id.one_day:
			set.setClassName("com.Rometta","com.Rometta.Survice_one_day");
			startActivity(set);
		case R.id.teiki:
			set.setClassName("com.Rometta","com.Rometta.Survice_one_day");
			startActivity(set);
		case R.id.teiki2:
			set.setClassName("com.Rometta","com.Rometta.Survice_one_day");
			startActivity(set);
		}
    }
}
