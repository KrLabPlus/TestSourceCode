package com.example.gurunavitest;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import static com.example.gurunavitest.MainActivity.TAG;

public class RequestRunnable implements Runnable {
	private GurunaviAPI mSpotFinder;
	private Handler mHandler;
	
	public RequestRunnable(GurunaviAPI gAPI, Handler handler) {
		this.mSpotFinder = gAPI;
		//APIへのアクセスが終わったことを知らせるためのハンドラ
		this.mHandler = handler;
	}
	
	public void run() {
		Log.i(TAG, "run RequestRunnable thread");
		mSpotFinder.getJSON();
		
		//ハンドラに通知
		Message msg = new Message();
		msg.obj = mSpotFinder.getGPoint();
		mHandler.sendMessage(msg);
	}
}
