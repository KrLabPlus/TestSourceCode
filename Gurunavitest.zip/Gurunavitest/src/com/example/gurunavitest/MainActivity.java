package com.example.gurunavitest;

import static com.example.gurunavitest.MainActivity.TAG;
import java.io.StringReader;
import java.net.URI;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.http.client.methods.HttpGet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xml.sax.InputSource;

import com.example.gurunavitest.GurunaviAPI.ResponseItem;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ZoomControls;

public class MainActivity extends MapActivity{
	static final String TAG = "Gurunavitest";
	static final int MIN_TIME = 0;
	static final int MIN_METER = 0;
	
	private ProgressDialog mDialog;
	private Resources mRes;
	private GurunaviAPI mSpotFinder;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i(TAG, "onCreate");
		//APIの実行
		mSpotFinder = new GurunaviAPI();
		
		setContentView(R.layout.activity_main);
		TextView textView2 = (TextView) findViewById(id.textView2);
		String mResponse = GurunaviAPI.mRest.toString();
	    textView2.setText(mResponse);
		
		//リソースの確保
		mRes = getResources();
		

	}
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}
}