package com.example.gurunavitest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.util.Log;
import static com.example.gurunavitest.MainActivity.TAG;

public class MyHttpClient extends DefaultHttpClient {
	private HttpGet httpGet;
	public MyHttpClient() {
		Log.i(TAG, "constructor MyHttpClient");
		httpGet = new HttpGet();
	}
	public InputStream getInputStreamOnWeb(String uri) {
		Log.i(TAG, "getInputStreamOnWeb");
		try {
			httpGet.setURI(new URI(uri));
		} catch (URISyntaxException e1) {
			Log.e(TAG, "URISyntaxException");
			e1.printStackTrace();
			return null;
		}
		
		HttpResponse response = null;
		try {
			response = execute(httpGet);
			int statusCode = response.getStatusLine().getStatusCode();
			Log.i(TAG, "Status Code: " + statusCode);
			if (200 <= statusCode && statusCode < 300) {
				//success!!
				return response.getEntity().getContent();
			}
		} catch (ClientProtocolException e) {
			Log.e(TAG, "ClientProtocolException");
			e.printStackTrace();
		} catch (IllegalStateException e) {
			Log.e(TAG, "IllegatStateException");
			e.printStackTrace();
		} catch (IOException e) {
			Log.e(TAG, "IOException");
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public String getStringOnWeb(String uri) {
		Log.i(TAG, "getStringOnWeb");
		InputStream is = getInputStreamOnWeb(uri);
		if(is == null) {
			return null;
		}
		
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		StringBuffer buffer = new StringBuffer();
		
		try {
			String line;
			while ((line = br.readLine()) != null) {
				buffer.append(line);
			}
		} catch (IOException e) {
			Log.e(TAG, "IOException");
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return buffer.toString();
	}

}
