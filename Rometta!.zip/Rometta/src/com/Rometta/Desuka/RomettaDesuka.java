package com.Rometta.Desuka;

import com.Rometta.R;

import android.app.*;
import android.os.*;

public class RomettaDesuka extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_desuka);
		setTitle("ですか残高確認");
	}
}
