package com.Rometta.TimeSchedule;

import android.graphics.Bitmap;

public class RomettaTimeSchedule_ResultItemData {

	// アイテムID
    private int Id;

    // テキスト
    private String text1;
    private String text2;

    // 画像
    private Bitmap color1;
    private Bitmap color2;

    public String getText1() {
        return text1;
    }

    public void setText1(String text) {
        this.text1 = text;
    }

    public String getText2() {
        return text2;
    }

    public void setText2(String text) {
        this.text2 = text;
    }

    public Bitmap getColor1() {
        return color1;
    }

    public void setColor1(Bitmap color) {
        this.color1 = color;
    }

    public Bitmap getColor2() {
        return color2;
    }

    public void setColor2(Bitmap color) {
        this.color2 = color;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

}