package com.Rometta.Norikae;

import android.graphics.Bitmap;


public class RomettaNorikae_SelectResultCustomData {
    private Bitmap imageData_;
    private String textData_;
    private String textData2_;
    private String textData3_;
    private String textData4_;
    private String textData5_;

    public void setImagaData(Bitmap image) {
        imageData_ = image;
    }

    public Bitmap getImageData() {
        return imageData_;
    }

    public void setTextData(String text) {
        textData_ = text;
    }

    public String getTextData() {
        return textData_;
    }

    public void setTextData2(String text) {
        textData2_ = text;
    }

    public String getTextData2() {
        return textData2_;
    }

    public void setTextData3(String text) {
        textData3_ = text;
    }

    public String getTextData3() {
        return textData3_;
    }

    public void setTextData4(String text) {
        textData4_ = text;
    }

    public String getTextData4() {
        return textData4_;
    }

    public void setTextData5(String text) {
        textData5_ = text;
    }

    public String getTextData5() {
        return textData5_;
    }
}