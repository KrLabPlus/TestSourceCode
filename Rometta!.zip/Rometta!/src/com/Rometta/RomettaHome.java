package com.Rometta;

import com.Rometta.HowTo.*;
import com.Rometta.Desuka.*;
import com.Rometta.Norikae.*;
import com.Rometta.Service.*;
import com.Rometta.Spot.*;
import com.Rometta.TimeSchedule.*;

import android.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import android.view.View.*;
import android.widget.*;

public class RomettaHome extends Activity {
	ImageButton bt1,bt2,bt3,bt4,bt5,bt6;
    private static final int MENU_A = 0; // 右上メニューに対しての値
    private static final int MENU_B = 1;

	public void onCreate(Bundle savedInstanceState) {
		setTheme(R.style.my_theme);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_home);

		bt1 = (ImageButton)findViewById(R.id.imageButton1);
		bt2 = (ImageButton)findViewById(R.id.imageButton2);
		bt3 = (ImageButton)findViewById(R.id.imageButton3);
		bt4 = (ImageButton)findViewById(R.id.imageButton4);
		bt5 = (ImageButton)findViewById(R.id.imageButton5);
		bt6 = (ImageButton)findViewById(R.id.imageButton6);

		bt1.setOnClickListener(new HomeClickListener());
		bt2.setOnClickListener(new HomeClickListener());
		bt3.setOnClickListener(new HomeClickListener());
		bt4.setOnClickListener(new HomeClickListener());
		bt5.setOnClickListener(new HomeClickListener());
		bt6.setOnClickListener(new HomeClickListener());
	}
	class HomeClickListener implements OnClickListener{
		public void onClick(View v){
			Intent it;
			if(v == bt1){
				it = new Intent(getApplicationContext(), RomettaNorikae.class);
			} else if(v == bt2){
				it = new Intent(getApplicationContext(), RomettaSpot.class);
			} else if(v == bt3){
				it = new Intent(getApplicationContext(), RomettaTimeSchedule.class);
			} else if(v == bt4){
				it = new Intent(getApplicationContext(), RomettaDesuka.class);
			} else if(v == bt5){
				it = new Intent(getApplicationContext(), RomettaHowTo.class);
			} else {
				it = new Intent(getApplicationContext(), RomettaService.class);
			}
			startActivity(it);
		}
	}
	public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_A,   0, "ほげー");
        menu.add(0, MENU_B,   0, "ほほほほほ");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch ( item.getItemId() )
        {
        case MENU_A:
        	AlertDialog.Builder InfoDialog = new AlertDialog.Builder(RomettaHome.this);
        	InfoDialog.setTitle("hoge");
        	InfoDialog.setMessage("ほげ");
        	InfoDialog.setPositiveButton("OK", null);
        	InfoDialog.show();
            return true;
        case MENU_B:
            AlertDialog.Builder LicenseDialog = new AlertDialog.Builder(RomettaHome.this);
            LicenseDialog.setTitle("hogege");
            LicenseDialog.setMessage("ほげげげげ");
            LicenseDialog.setPositiveButton("OK", null);
            LicenseDialog.show();
            return true;
        }
        return false;
    }
}