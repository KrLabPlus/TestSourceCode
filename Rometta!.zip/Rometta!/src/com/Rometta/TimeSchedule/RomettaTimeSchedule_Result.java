package com.Rometta.TimeSchedule;

import java.util.ArrayList;
import java.util.List;

import com.Rometta.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class RomettaTimeSchedule_Result extends Activity implements OnClickListener {
	//与えられた値と仮定する
	String home, news, ki = "0";
	String[] timeschedule, direction;
	//普通の路面電車=0,金曜限定=1, ハートラム=2として仮で扱ってま
	String[] kind ={"1", "0","2"};
	String[] destination_holi = {"1", "2", "3","ダー"};
	Intent it;
	Bitmap bitmap;

	private Button btn1;
	private Button btn2;
	private TextView tv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_timeschedule_result);
        btn1 = (Button)findViewById(R.id.heijitu);
        btn2 = (Button)findViewById(R.id.yasumi);

        tv = (TextView)findViewById(R.id.train_houkou);


        it = getIntent();
        home = it.getStringExtra("STATION");
        timeschedule = it.getStringArrayExtra("TIME_LIST");
        direction = it.getStringArrayExtra("DIRECTION_LIST");
        news = it.getStringExtra("DIRECTION");

        if(news.equals("n")){
        	tv.setText("南北線 上り");
        } else if(news.equals("s")) {
        	tv.setText("南北線 下り");
        } else if(news.equals("e")) {
        	tv.setText("東西線 上り");
        } else {
        	tv.setText("東西線 下り");
        }


	    btn1.setOnClickListener(this);
	    btn2.setOnClickListener(this);

	    btn1.setBackgroundResource(R.drawable.timeschedule_button_pressed);

	    //駅名（乗り駅)
	    TextView textView = (TextView) findViewById(R.id.train_name);
	    textView.setText(home);

		ListView listView = (ListView) findViewById(R.id.listview1);

		// リスト
		List<RomettaTimeSchedule_ResultItemData> list = weekDay();
		RomettaTimeSchedule_CustomAdapter customAd = new RomettaTimeSchedule_CustomAdapter(this, list);
        listView.setAdapter(customAd);
	}

    public void onClick(View v) {
		ListView listView = (ListView) findViewById(R.id.listview1);
    	switch (v.getId()) {
    	case R.id.heijitu:
    		btn1.setBackgroundResource(R.drawable.timeschedule_button_pressed);
    		btn2.setBackgroundResource(R.drawable.timeschedule_button_normal);
			List<RomettaTimeSchedule_ResultItemData> list1 = weekDay();
			RomettaTimeSchedule_CustomAdapter customAd1 = new RomettaTimeSchedule_CustomAdapter(this, list1);
        	listView.setAdapter(customAd1);
        	break;
    	case R.id.yasumi:
    		btn1.setBackgroundResource(R.drawable.timeschedule_button_normal);
    		btn2.setBackgroundResource(R.drawable.timeschedule_button_pressed);
			List<RomettaTimeSchedule_ResultItemData> list2 = holiDay();
			RomettaTimeSchedule_CustomAdapter customAd2 = new RomettaTimeSchedule_CustomAdapter(this, list2);
        	listView.setAdapter(customAd2);
        	break;
    	}
    }


	//平日のときの処理
	private List<RomettaTimeSchedule_ResultItemData> weekDay(){
		List<RomettaTimeSchedule_ResultItemData> list = new ArrayList<RomettaTimeSchedule_ResultItemData>();
        for (int i = 0; i < timeschedule.length; i++) {
        	RomettaTimeSchedule_ResultItemData tempData = new RomettaTimeSchedule_ResultItemData();

            String[] jikoku_split = timeschedule[i].split(":");
            tempData.setText1(jikoku_split[0]+":"+jikoku_split[1]);
            tempData.setText2(direction[i]+"行き");

            if (ki == "0") {
            	tempData.setText1(jikoku_split[0]+":"+jikoku_split[1]+"  ");
            } else if (ki == "1") {
            	bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.timeschedule_friday);
            	bitmap = Bitmap.createScaledBitmap(bitmap, 40, 40, true);
                tempData.setColor1(bitmap);
            } else {
            	bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.timeschedule_heartrum);
            	bitmap = Bitmap.createScaledBitmap(bitmap, 40, 40, true);
                tempData.setColor1(bitmap);
            }
            //tempData.setColor2(BitmapFactory.decodeResource(getResources(),
            //        R.drawable.arrow));

            tempData.setId(i);
            list.add(tempData);
        }
		return list;
	}

	//休日のときの処理
	private List<RomettaTimeSchedule_ResultItemData> holiDay(){
		List<RomettaTimeSchedule_ResultItemData> list = new ArrayList<RomettaTimeSchedule_ResultItemData>();
        for (int i = 0; i < 4; i++) {
        	RomettaTimeSchedule_ResultItemData tempData = new RomettaTimeSchedule_ResultItemData();

            String[] jikoku_split = timeschedule[i].split(":");
            tempData.setText1(jikoku_split[0]+":"+jikoku_split[1]);
            tempData.setText2(destination_holi[i]+"行き");

            if (ki == "0") {
            	tempData.setText1(jikoku_split[0]+":"+jikoku_split[1]+"  ");
            } else if (ki == "1") {
            	bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.timeschedule_friday);
            	bitmap = Bitmap.createScaledBitmap(bitmap, 40, 40, true);
                tempData.setColor1(bitmap);
            } else {
            	bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.timeschedule_heartrum);
            	bitmap = Bitmap.createScaledBitmap(bitmap, 40, 40, true);
                tempData.setColor1(bitmap);
            }
            //tempData.setColor2(BitmapFactory.decodeResource(getResources(),
            //        R.drawable.arrow));

            tempData.setId(i);
            list.add(tempData);
        }
		return list;
	}
}