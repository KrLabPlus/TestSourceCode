package com.Rometta.TimeSchedule;

import com.Rometta.R;
import com.Rometta.RomettaSearchStation;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class RomettaTimeSchedule extends Activity {
	ImageButton bt1, bt2, bt3, bt4;
	Intent it;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_timeschedule);

		bt1 = (ImageButton)findViewById(R.id.image_InoGomen);
		bt2 = (ImageButton)findViewById(R.id.image_GomenIno);
		bt3 = (ImageButton)findViewById(R.id.image_ZanbashiKochi);
		bt4 = (ImageButton)findViewById(R.id.image_KochiZanbashi);

		bt1.setOnClickListener(new TimeClickListener());
		bt2.setOnClickListener(new TimeClickListener());
		bt3.setOnClickListener(new TimeClickListener());
		bt4.setOnClickListener(new TimeClickListener());
	}

	class TimeClickListener implements OnClickListener{
		public void onClick(View v){
			it = new Intent(getApplicationContext(), RomettaSearchStation.class);
			if(v == bt1){
				it.putExtra("keyword", "e");
			} else if(v == bt2){
				it.putExtra("keyword", "w");
			} else if(v == bt3){
				it.putExtra("keyword", "n");
			} else {
				it.putExtra("keyword", "s");
			}
			startActivity(it);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}