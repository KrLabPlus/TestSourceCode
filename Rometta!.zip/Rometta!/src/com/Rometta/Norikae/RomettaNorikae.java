package com.Rometta.Norikae;

import java.util.Calendar;
import java.util.Locale;

import com.Rometta.*;
import com.Rometta.Server.*;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.KeyEvent;
import android.view.View.OnClickListener;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class RomettaNorikae extends Activity {
	int menu_key;
	String select, from_it = null, to_it = null, time_it = null, time_it2 = null, dmp;
	String[] strAry, strAry2, strAry3, routeAry;
	EditText from_text, to_text;
	Button btn;
	int count = 0, j = 0, lvc = 0;
	double[] latlng = new double[4];
	private AlertDialog dialog;
	private static final int FROM_ACTIVITY = 1001;
	private static final int TO_ACTIVITY = 1002;
	ImageButton search_btn, search_btn_touch, change_button;
	ImageView norikae_from, norikae_to;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_norikae);
		setTitle(R.string.title_norikae);
		
		//menu_keyを受け取る
		menu_key = getIntent().getIntExtra("menu_key",0);
		
		// カスタムビュー設定
		LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
		final View layout = inflater.inflate(R.layout.dialog, (ViewGroup) findViewById(R.id.dialog_custom));

		// 時刻設定ボタンのオブジェクト取得
		btn = (Button) findViewById(R.id.set_button);

		// さがすボタンなどのオブジェクト取得
		search_btn = (ImageButton) findViewById(R.id.search_button);
		change_button = (ImageButton) findViewById(R.id.change_button);
		norikae_from = (ImageView) findViewById(R.id.from);
		norikae_to = (ImageView) findViewById(R.id.to);
		
		if(menu_key == 1){
			search_btn.setImageResource(R.drawable.norikae_change_search_button_en);
			norikae_from.setImageResource(R.drawable.norikae_from_en);
			norikae_to.setImageResource(R.drawable.norikae_to_en);
		}
		
		
		//発着地を別画面でタップ入力させる
		from_text = (EditText)findViewById(R.id.from_text);
		to_text = (EditText)findViewById(R.id.to_text);

		from_text.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent it;

				it = new Intent(getApplicationContext(), RomettaSearchStation.class);
				startActivityForResult(it, FROM_ACTIVITY);
			    // ①駅名入力画面への遷移処理
				// ②駅名入力画面から返ってきた値をEditTextに表示する
			}
		});

		to_text.setOnClickListener(new OnClickListener() {
			@Override
		    public void onClick(View v) {
				Intent it;

				it = new Intent(getApplicationContext(), RomettaSearchStation.class);
				startActivityForResult(it, TO_ACTIVITY);
		        // ①駅名入力画面への遷移処理
				// ②駅名入力画面から返ってきた値をEditTextに表示する
		    }
		});

		change_button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				EditText from_text = (EditText)findViewById(R.id.from_text);
				EditText to_text = (EditText)findViewById(R.id.to_text);
				SpannableStringBuilder sb1 = (SpannableStringBuilder)from_text.getText();
				SpannableStringBuilder sb2 = (SpannableStringBuilder)to_text.getText();
				SpannableStringBuilder tmp;
				tmp = sb1;
				sb1 = sb2;
				sb2 = tmp;

				dmp = from_it;
				from_it = to_it;
				to_it = dmp;

				from_text.setText((CharSequence) sb1);
				to_text.setText((CharSequence) sb2);
			}
		});

		// アラートダイアログ生成
		if (dialog == null) {
			dialog = new AlertDialog.Builder(this)
					.setTitle(getString(R.string.dialog_title))
					.setView(layout)

					.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							// OKボタンクリック処理

							// 設定した日時取得
							DatePicker date = (DatePicker)layout.findViewById(R.id.datepicker);
							TimePicker time = (TimePicker)layout.findViewById(R.id.timepicker);

							//ラジオボタンの値取得
							RadioGroup radioGroup = (RadioGroup)layout.findViewById(R.id.radio_group);
							select = getString(R.string.from_radio_button_select);
							int checkedId = radioGroup.getCheckedRadioButtonId();
							// 選択されたRadioButtonによって範囲を変更
							if (checkedId == R.id.to_radio_button) {
								select = getString(R.string.to_radio_button_select);
							} else if (checkedId == R.id.start_radio_button) {
								select = getString(R.string.start_radio_button);
							} else if (checkedId == R.id.finish_radio_button){
								select = getString(R.string.finish_radio_button);
							} else {
								select = getString(R.string.from_radio_button_select);
							}

							String zero_h = "";
							String zero_m = "";
							if(time.getCurrentHour() < 10){
								zero_h = "0";
							}
							if (time.getCurrentMinute() < 10) {
								zero_m = "0";
							}

							// ボタンの文字変更
							if (checkedId == R.id.from_radio_button || checkedId == R.id.to_radio_button) {
                                btn.setText(date.getYear() + "/" + (date.getMonth() + 1) + "/" + date.getDayOfMonth() + " " + zero_h + time.getCurrentHour() + ":" + zero_m + time.getCurrentMinute() + " " + select);
                            } else {
                                btn.setText(date.getYear() + "/" + (date.getMonth() + 1) + "/" + date.getDayOfMonth() + " " + select);
                            }
							time_it = zero_h + time.getCurrentHour() + ":" + zero_m + time.getCurrentMinute();
						}
					})

					.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							// Cancelボタンクリック処理
							// 現在の日時取得
							Calendar calendar = Calendar.getInstance();
							int year = calendar.get(Calendar.YEAR); // 年
							int month = calendar.get(Calendar.MONTH) + 1; // 月
							int day = calendar.get(Calendar.DAY_OF_MONTH); // 日
							int hour = calendar.get(Calendar.HOUR_OF_DAY); // 時
							int minute = calendar.get(Calendar.MINUTE); // 分

							String zero_h = "";
							String zero_m = "";
							if(hour < 10){
								zero_h = "0";
							}
							if (minute < 10) {
								zero_m = "0";
							}
							// ボタンの文字変更
							btn.setText(year + "/" + month + "/" + day + " " + hour + ":" + minute + " " + getString(R.string.from_radio_button_select));
							time_it = zero_h + hour + ":" + zero_m + minute;
						}
					})

					.create();
			}

		btn.setOnClickListener(new OnClickListener() {
			//@Override
			public void onClick(View v) {
				// 表示
		        dialog.show();
			}
		});

		search_btn.setOnClickListener(new OnClickListener() {
			//@Override
			public void onClick(View v) {
				if(from_it != null && to_it != null){
					exec_post_latlng(from_it);
					exec_post_latlng(to_it);



				} else {
					new AlertDialog.Builder(RomettaNorikae.this)
							.setTitle("入力エラー")
							.setMessage("出発駅と到着駅を入力してください")
							.setPositiveButton(
									"OK",
									new DialogInterface.OnClickListener() {
										@Override
										public void onClick(DialogInterface dialog, int which) {
										}
									})
							.show();
				}
				//遷移先に緯度経度・時刻などを渡す処理
			}
		});
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	  // TODO Auto-generated method stub
	  // requestCodeがサブ画面か確認する
	  if(requestCode == FROM_ACTIVITY) {
	    // resultCodeがOKか確認する
	      if(resultCode == RESULT_OK) {
	      // 結果を取得して, 表示する.
	          from_text.setText(data.getCharSequenceExtra("keyword"));
	          from_it = (String)data.getCharSequenceExtra("keyword");
	      }
	  } else if(requestCode == TO_ACTIVITY){
		  if(resultCode == RESULT_OK) {
			  to_text.setText(data.getCharSequenceExtra("keyword"));
			  to_it = (String)data.getCharSequenceExtra("keyword");
		  }
	  }
	}
	public void exec_post_latlng(String station) {

	    // 非同期タスクを定義
	    HttpPostTask task = new HttpPostTask(
	      this,
	      "http://krlab.info.kochi-tech.ac.jp/Krlabp/GetStationData.php?Name='" + station + "'",
	      //アクセスする箇所を

	      // タスク完了時に呼ばれるUIのハンドラ
	      new HttpPostHandler(){
	        @Override
	        public void onPostCompleted(String response) {
	        	strAry = response.split(",");

	        	if(count == 0){
	        		strAry2 = strAry[2].split("=");
	        		latlng[0] = Double.parseDouble(strAry2[1]);
	        		strAry2 = strAry[3].split("=");
	        		latlng[1] = Double.parseDouble(strAry2[1]);

	        		count = 1;
	        	} else if(count == 1){
	        		strAry2 = strAry[2].split("=");
	        		latlng[2] = Double.parseDouble(strAry2[1]);
	        		strAry2 = strAry[3].split("=");
	        		latlng[3] = Double.parseDouble(strAry2[1]);

	        		count = 0;

	        		exec_post_route(from_it, to_it, time_it);
	        	}
	        }
	        @Override
	        public void onPostFailed(String response) {
	          Toast.makeText(
	            getApplicationContext(),
	            "エラーが発生しました。",
	            Toast.LENGTH_LONG
	          ).show();
	        }
	      }
	    );
	    task.addPostParam( "post_1", "ユーザID" );
	    task.addPostParam( "post_2", "パスワード" );

	    // タスクを開始
	    task.execute();
	  }

	public void exec_post_route(String from_s, String to_s, String time_s) {

	    // 非同期タスクを定義
	    HttpPostTask task = new HttpPostTask(
	      this,
	      "http://krlab.info.kochi-tech.ac.jp/Krlabp/GetRoot.php?Start='" + from_s + "'&End='" + to_s +"'&Time='" + time_s + ":00'",
	      //アクセスする箇所を

	      // タスク完了時に呼ばれるUIのハンドラ
	      new HttpPostHandler(){
	        @Override
	        public void onPostCompleted(String response) {
	        	response = response.replaceAll("通番=高知", "通番=,高知");
	        	response = response.replaceAll("通番=", "通番=00:00:00");
	        	strAry = response.split(",");

	        	for(int i = 0; i < strAry.length; i+=7){
	        		if(strAry[i].indexOf("00:00:00") != -1){
	        			strAry[i] = null;
	        		} else {
	        			if(strAry[i + 4].indexOf("00:00:00") != -1 && i < strAry.length - 7){
	        				strAry[i + 4] = strAry[i + 11];
	        				strAry[i + 5] = strAry[i + 12];
	        			} else {

	        			}
	        		}
	        	}

	        	routeAry = new String[35];

	        	for(int i = 0; i < strAry.length; i++){
	        		if(strAry[i] != null){
	        			if(strAry[i].equals("通番=")){
		        			routeAry[j] = "通番";
		        			j++;
	        			} else {
	        				strAry2 = strAry[i].split("=");
		        			strAry3 = strAry2[1].split(":");
		        			routeAry[j] = strAry3[0] + ":" + strAry3[1];
		        			j++;
	        			}
	        		} else {
	        			i += 6;
	        		}

	        		if(j == 35){
	        			lvc = 5;
	        			break;
	        		}
	        	}

	        	if(j == 28){
	        		lvc = 4;
	        	} else if(j == 21){
	        		lvc = 3;
	        	} else if(j == 14){
	        		lvc = 2;
	        	} else if(j == 7){
	        		lvc = 1;
	        	} else {
	        		lvc = 0;
	        	}

	        	j = 0;

        		time_it2 = btn.getText().toString();

	        	Intent it = new Intent(getApplicationContext(), RomettaNorikae_SelectResult.class);
	        	it.putExtra("menu_key", menu_key);

	        	it.putExtra("FROM", from_it);
	        	it.putExtra("TO", to_it);
        		it.putExtra("LATLNG", latlng); // 出発駅の緯度,出発駅の経度,到着駅の緯度,到着駅の経度
				//it.putExtra("EDIT_TIME", time_it); // 基準となる時刻
				it.putExtra("PICKER_TIME", time_it2);// TimePickerで入力した年月日時刻(TextView用)
				it.putExtra("ROUTE_TIME", routeAry); // 電車の発着時間(例：07:00)
				it.putExtra("LISTVIEWCOUNT", lvc);


				startActivity(it);

	        }
	        @Override
	        public void onPostFailed(String response) {
	          Toast.makeText(
	            getApplicationContext(),
	            "エラーが発生しました。",
	            Toast.LENGTH_LONG
	          ).show();
	        }
	      }
	    );
	    task.addPostParam( "post_1", "ユーザID" );
	    task.addPostParam( "post_2", "パスワード" );

	    // タスクを開始
	    task.execute();
	  }
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		menu_key = i.getIntExtra("menu_key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
			//search_btn.setImageResource(R.drawable.norikae_search_button_en);
			//search_btn.setBackgroundResource(R.drawable.norikae_search_button_touch_en);
			norikae_from.setImageResource(R.drawable.norikae_from_en);
			norikae_to.setImageResource(R.drawable.norikae_to_en);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("");
			  reload(key);
			  break;
		  case R.id.credit:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage("Rometta! ver 1.0.1" + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n" 
			    		+ "Rometta!はとさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if(keyCode == KeyEvent.KEYCODE_BACK) {
	    	Intent it = new Intent(getApplicationContext(), RomettaHome.class);
        	it.putExtra("menu_key", menu_key);
        	startActivity(it);
	       return super.onKeyDown(keyCode, event);
	    } else {
	        return super.onKeyDown(keyCode, event);
	    }
	}

}