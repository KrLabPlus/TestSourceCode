package com.Rometta.Norikae;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.Rometta.R;

public class RomettaNorikaeResultRoutes extends Activity{

	TextView tv1, tv2;
	Intent it;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_test);

		it = getIntent();

		tv1 = (TextView)findViewById(R.id.textView1);
		tv2 = (TextView)findViewById(R.id.textView2);

		tv1.setText(it.getDoubleExtra("FROM_LAT",0) + ", " + it.getDoubleExtra("FROM_LNG",0));
		tv2.setText(it.getDoubleExtra("TO_LAT",0) + ", " + it.getDoubleExtra("TO_LNG",0));
	}

}
