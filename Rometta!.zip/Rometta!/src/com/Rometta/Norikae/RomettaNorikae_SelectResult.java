package com.Rometta.Norikae;

import java.util.ArrayList;
import java.util.List;

import com.Rometta.R;
import com.Rometta.TimeSchedule.RomettaTimeSchedule_Result;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class RomettaNorikae_SelectResult extends Activity{

	double[] latlng;
	String from_station, to_station, time_it;
	String[] time_table;
	int norikae, lvc;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_norikae_select_result);

		Intent it = getIntent();

		TextView tv, tv2, tv3;

        // リソースに準備した画像ファイルからBitmapを作成しておく
        Bitmap image1;
        Bitmap image2;
        Bitmap image3;
        Bitmap image4;
        Bitmap image5;

        from_station = it.getStringExtra("FROM");
        to_station = it.getStringExtra("TO");
        time_it = it.getStringExtra("PICKER_TIME");
        time_table = it.getStringArrayExtra("ROUTE_TIME");
        latlng = it.getDoubleArrayExtra("LATLNG");
        lvc = it.getIntExtra("LISTVIEWCOUNT", 0);

        tv = (TextView) findViewById(R.id.picker_time);
        tv2 = (TextView) findViewById(R.id.text_start_name);
        tv3 = (TextView) findViewById(R.id.text_goal_name);

        tv.setText(time_it);
        tv2.setText(from_station);
        tv3.setText(to_station);

        image1 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_one);
        image2 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_two);
        image3 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_three);
        image4 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_four);
        image5 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_five);

        RomettaNorikae_SelectResultCustomData item1 = new RomettaNorikae_SelectResultCustomData();
        RomettaNorikae_SelectResultCustomData item2 = new RomettaNorikae_SelectResultCustomData();
        RomettaNorikae_SelectResultCustomData item3 = new RomettaNorikae_SelectResultCustomData();
        RomettaNorikae_SelectResultCustomData item4 = new RomettaNorikae_SelectResultCustomData();
        RomettaNorikae_SelectResultCustomData item5 = new RomettaNorikae_SelectResultCustomData();


     // データの作成
        List<RomettaNorikae_SelectResultCustomData> objects = new ArrayList<RomettaNorikae_SelectResultCustomData>();

        switch(lvc){
        	case 5:
                item5.setImagaData(image5);
                item5.setTextData(time_table[28] + " - " + time_table[33]);
                item5.setTextData2("詳細5");
                item5.setTextData3("(大人)200円");
                item5.setTextData4("乗換あり");
                item5.setTextData5("整理券あり");
        	case 4:
                item4.setImagaData(image4);
                item4.setTextData(time_table[21] + " - " + time_table[26]);
                item4.setTextData2("25分");
                item4.setTextData3("(大人)200円");
                item4.setTextData4("乗換あり");
                item4.setTextData5("整理券あり");
        	case 3:
                item3.setImagaData(image3);
                item3.setTextData(time_table[14] + " - " + time_table[19]);
                item3.setTextData2("25分");
                item3.setTextData3("(大人)200円");
                item3.setTextData4("乗換あり");
                item3.setTextData5("整理券あり");
        	case 2:
                item2.setImagaData(image2);
                item2.setTextData(time_table[7] + " - " + time_table[12]);
                item2.setTextData2("25分");
                item2.setTextData3("(大人)200円");
                item2.setTextData4("乗換あり");
                item2.setTextData5("整理券あり");
        	case 1:
                item1.setImagaData(image1);
                item1.setTextData(time_table[0] + " - " + time_table[5]);
                item1.setTextData2("30分");
                item1.setTextData3("(大人)200円");
                item1.setTextData4("乗換あり");
                item1.setTextData5("整理券あり");

                objects.add(item1);

                break;

        	default:

        }

        if(lvc > 1){
        	objects.add(item2);
        	if(lvc > 2){
        		objects.add(item3);
        		if(lvc > 3){
        			objects.add(item4);
        			if(lvc > 4){
        				objects.add(item5);
        			}
        		}
        	}
        }

        RomettaNorikae_SelectResultCustomAdapter customAdapter = new RomettaNorikae_SelectResultCustomAdapter(this, 0, objects);

        // リストビューにデータを設定
        ListView lv = (ListView)findViewById(R.id.result_list);
        lv.setAdapter(customAdapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> av, View vi, int position, long id) {

            	TextView textView = (TextView)findViewById(R.id.cost_view);

            	if(textView.getText().equals("乗換あり")){
            		norikae = 1;
            	}

            	Intent it2 = new Intent(getApplicationContext(), RomettaNorikae_ResultRoute.class);

            	it2.putExtra("FROM_LAT", latlng[0]);
            	it2.putExtra("FROM_LNG", latlng[1]);
            	it2.putExtra("TO_LAT", latlng[2]);
            	it2.putExtra("TO_LNG", latlng[3]);
            	it2.putExtra("NORIKAE", norikae);
            	it2.putExtra("COST", 200);
            	it2.putExtra("FROM_TIME", time_table[position * 7]);
            	it2.putExtra("TO_TIME", time_table[(position * 7) + 5]);
            	it2.putExtra("FROM_STATION", from_station);
            	it2.putExtra("TO_STATION", to_station);

            	norikae = 0;

            	startActivity(it2);
            }
        });
	}
}




















