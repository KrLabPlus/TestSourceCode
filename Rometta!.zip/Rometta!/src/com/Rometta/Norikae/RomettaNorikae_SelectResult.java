package com.Rometta.Norikae;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.Rometta.R;
import com.Rometta.TimeSchedule.RomettaTimeSchedule_Result;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class RomettaNorikae_SelectResult extends Activity{
	int menu_key;
	double[] latlng;
	String from_station, to_station, time_it;
	String[] time_table;
	int norikae, lvc;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_norikae_select_result);
		setTitle("検索結果");

		Intent it = getIntent();
		//menu_keyを受け取る
		menu_key = (Integer) getIntent().getExtras().get("menu_key");

		TextView tv, tv2, tv3;

        // リソースに準備した画像ファイルからBitmapを作成しておく
        Bitmap image1;
        Bitmap image2;
        Bitmap image3;
        Bitmap image4;
        Bitmap image5;

        from_station = it.getStringExtra("FROM");
        to_station = it.getStringExtra("TO");
        time_it = it.getStringExtra("PICKER_TIME");
        time_table = it.getStringArrayExtra("ROUTE_TIME");
        latlng = it.getDoubleArrayExtra("LATLNG");
        lvc = it.getIntExtra("LISTVIEWCOUNT", 0);

        tv = (TextView) findViewById(R.id.picker_time);
        tv2 = (TextView) findViewById(R.id.text_start_name);
        tv3 = (TextView) findViewById(R.id.text_goal_name);

        tv.setText(time_it);
        tv2.setText(from_station);
        tv3.setText(to_station);

        image1 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_one);
        image2 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_two);
        image3 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_three);
        image4 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_four);
        image5 = BitmapFactory.decodeResource(getResources(), R.drawable.norikae_five);

        RomettaNorikae_SelectResultCustomData item1 = new RomettaNorikae_SelectResultCustomData();
        RomettaNorikae_SelectResultCustomData item2 = new RomettaNorikae_SelectResultCustomData();
        RomettaNorikae_SelectResultCustomData item3 = new RomettaNorikae_SelectResultCustomData();
        RomettaNorikae_SelectResultCustomData item4 = new RomettaNorikae_SelectResultCustomData();
        RomettaNorikae_SelectResultCustomData item5 = new RomettaNorikae_SelectResultCustomData();


     // データの作成
        List<RomettaNorikae_SelectResultCustomData> objects = new ArrayList<RomettaNorikae_SelectResultCustomData>();

        switch(lvc){
        	case 5:
                item5.setImagaData(image5);
                item5.setTextData(time_table[28] + " - " + time_table[33]);
                item5.setTextData2("詳細5");
                item5.setTextData3("(大人)200円");
                item5.setTextData4("乗換あり");
                item5.setTextData5("整理券あり");
        	case 4:
                item4.setImagaData(image4);
                item4.setTextData(time_table[21] + " - " + time_table[26]);
                item4.setTextData2("25分");
                item4.setTextData3("(大人)200円");
                item4.setTextData4("乗換あり");
                item4.setTextData5("整理券あり");
        	case 3:
                item3.setImagaData(image3);
                item3.setTextData(time_table[14] + " - " + time_table[19]);
                item3.setTextData2("25分");
                item3.setTextData3("(大人)200円");
                item3.setTextData4("乗換あり");
                item3.setTextData5("整理券あり");
        	case 2:
                item2.setImagaData(image2);
                item2.setTextData(time_table[7] + " - " + time_table[12]);
                item2.setTextData2("25分");
                item2.setTextData3("(大人)200円");
                item2.setTextData4("乗換あり");
                item2.setTextData5("整理券あり");
        	case 1:
                item1.setImagaData(image1);
                item1.setTextData(time_table[0] + " - " + time_table[5]);
                item1.setTextData2("30分");
                item1.setTextData3("(大人)200円");
                item1.setTextData4("乗換あり");
                item1.setTextData5("整理券あり");

                objects.add(item1);

                break;

        	default:

        }

        if(lvc > 1){
        	objects.add(item2);
        	if(lvc > 2){
        		objects.add(item3);
        		if(lvc > 3){
        			objects.add(item4);
        			if(lvc > 4){
        				objects.add(item5);
        			}
        		}
        	}
        }

        RomettaNorikae_SelectResultCustomAdapter customAdapter = new RomettaNorikae_SelectResultCustomAdapter(this, 0, objects);

        // リストビューにデータを設定
        ListView lv = (ListView)findViewById(R.id.result_list);
        lv.setAdapter(customAdapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> av, View vi, int position, long id) {

            	TextView textView = (TextView)findViewById(R.id.cost_view);

            	if(textView.getText().equals("乗換あり")){
            		norikae = 1;
            	}

            	Intent it2 = new Intent(getApplicationContext(), RomettaNorikae_ResultRoute.class);

            	it2.putExtra("FROM_LAT", latlng[0]);
            	it2.putExtra("FROM_LNG", latlng[1]);
            	it2.putExtra("TO_LAT", latlng[2]);
            	it2.putExtra("TO_LNG", latlng[3]);
            	it2.putExtra("NORIKAE", norikae);
            	it2.putExtra("COST", 200);
            	it2.putExtra("FROM_TIME", time_table[position * 7]);
            	it2.putExtra("TO_TIME", time_table[(position * 7) + 5]);
            	it2.putExtra("FROM_STATION", from_station);
            	it2.putExtra("TO_STATION", to_station);
            	it2.putExtra("menu_key", menu_key);

            	norikae = 0;

            	startActivity(it2);
            }
        });
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		int menu_key = i.getIntExtra("menu_key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("");
			  reload(key);
			  break;
		  case R.id.credit:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage("Rometta! ver 1.0.1" + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n" 
			    		+ "Rometta!はとさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}
}




















