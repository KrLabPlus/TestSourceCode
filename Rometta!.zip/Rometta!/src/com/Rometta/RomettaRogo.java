package com.Rometta;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;

public class RomettaRogo extends Activity{
	Button bt1;

	public void onCreate(Bundle savedInstanceState) {
		setTheme(R.style.my_theme);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_rogo);

		new Handler().postDelayed(new Runnable() {
            public void run() {
            	Intent it = new Intent(getApplicationContext(), RomettaHome.class);
                startActivity(it);

                // �A�N�e�B�r�e�B���I�������邱�ƂŁA�X�v���b�V����ʂɖ߂邱�Ƃ�h���B
                RomettaRogo.this.finish();
            }
        }, 1800);
    }
}