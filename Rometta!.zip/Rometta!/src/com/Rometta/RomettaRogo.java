package com.Rometta;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;

public class RomettaRogo extends Activity{
	Button bt1;

	public void onCreate(Bundle savedInstanceState) {
		setTheme(R.style.my_theme);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_rogo);

		new Handler().postDelayed(new Runnable() {
            public void run() {
            	Intent it = new Intent(getApplicationContext(), RomettaHome.class);
                startActivity(it);

                // アクティビティを終了させることで、スプラッシュ画面に戻ることを防ぐ。
                RomettaRogo.this.finish();
            }
        }, 1800);
    }
}