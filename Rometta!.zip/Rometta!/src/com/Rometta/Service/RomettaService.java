package com.Rometta.Service;

import java.util.Locale;

import com.Rometta.R;
import com.Rometta.RomettaHome;
import com.Rometta.Desuka.RomettaDesuka;
import com.Rometta.HowTo.RomettaHowTo;
import com.Rometta.Norikae.RomettaNorikae;
import com.Rometta.R.id;
import com.Rometta.R.layout;
import com.Rometta.Spot.RomettaSpot;
import com.Rometta.TimeSchedule.RomettaTimeSchedule;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class RomettaService extends Activity implements OnClickListener{
	int menu_key;
	private ImageButton btn1;
	private ImageButton btn2;
	private ImageButton btn3;
	private ImageButton btn4;
	private ImageButton btn5;
	private ImageButton btn6;
	private ImageButton btn7;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_service);
		setTitle("サービス");
		menu_key = (Integer) getIntent().getExtras().get("menu_key");

	    btn1 = (ImageButton)findViewById(R.id.ic_card);
	    btn2 = (ImageButton)findViewById(R.id.one_day);
	    btn3 = (ImageButton)findViewById(R.id.teiki);
	    btn4 = (ImageButton)findViewById(R.id.okyaku);
	    btn5 = (ImageButton)findViewById(R.id.heart);
	    btn6 = (ImageButton)findViewById(R.id.teiki2);
	    btn7 = (ImageButton)findViewById(R.id.odekake);

	    btn1.setOnClickListener(this);
	    btn2.setOnClickListener(this);
	    btn3.setOnClickListener(this);
	    btn4.setOnClickListener(this);
	    btn5.setOnClickListener(this);
	    btn6.setOnClickListener(this);
	    btn7.setOnClickListener(this);
	}



	@Override
	public void onClick(View v){
		Intent it;
		if(v == btn1){
			it = new Intent(getApplicationContext(), RomettaService_Ic.class);
			it.putExtra("menu_key", menu_key);
		} else if(v == btn2){
			it = new Intent(getApplicationContext(), RomettaService_Oneday.class);
			it.putExtra("menu_key", menu_key);
		} else if(v == btn3){
			it = new Intent(getApplicationContext(), RomettaService_Teiki.class);
			it.putExtra("menu_key", menu_key);
		} else if(v == btn4){
			it = new Intent(getApplicationContext(), RomettaService_Okyaku.class);
			it.putExtra("menu_key", menu_key);
		} else if(v == btn5){
			it = new Intent(getApplicationContext(), RomettaService_Heart.class);
			it.putExtra("menu_key", menu_key);
		} else if(v == btn6){
			it = new Intent(getApplicationContext(), RomettaService_Tokuwari.class);
			it.putExtra("menu_key", menu_key);
		} else {
			it = new Intent(getApplicationContext(), RomettaService_Odekake.class);
			it.putExtra("menu_key", menu_key);
		}
		startActivity(it);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		Intent i = getIntent();
		int menu_key = i.getIntExtra("menu_key", 0);//0は受け取る値がない場合に渡す値
		//前の画面での言語の値を受け取り、条件分岐で表示するメニューを判断する
		//0=日本語, 1=英語, 2=土佐弁
		if(menu_key == 1){
			getMenuInflater().inflate(R.menu.menu_en, menu);
		} else if(menu_key == 2){
			getMenuInflater().inflate(R.menu.menu_ts, menu);
		} else {
			getMenuInflater().inflate(R.menu.menu_jp, menu);
		}
		return true;
	}

	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("it");
			  reload(key);
			  break;
		  case R.id.credit:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage("Rometta! ver 1.0.1" + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n" 
			    		+ "Rometta!はとさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if(keyCode == KeyEvent.KEYCODE_BACK) {
	    	Intent it = new Intent(getApplicationContext(), RomettaHome.class);
        	it.putExtra("menu_key", menu_key);
        	startActivity(it);
	       return super.onKeyDown(keyCode, event);
	    } else {
	        return super.onKeyDown(keyCode, event);
	    }
	}
}