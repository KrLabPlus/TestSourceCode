package com.Rometta.Spot;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.TreeMap;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;
import android.widget.TextView;

public class RomettaSpot_GurunaviAPI extends AsyncTask<String, Void, TreeMap<Integer, String>>{
	static final String TAG = "Gurunavitest";
	static final int MIN_TIME = 0;
	static final int MIN_METER = 0;
	private static final String api_uri = "http://api.gnavi.co.jp/ver1/RestSearchAPI/?";
	private static final String keyid = "eb6010ac17f00372ba1ee7b41e20d505";
	private static final String format = "xml";
	private String freeword_uri;
	static final double ERROR_DOUBLE = 10000.0;
	static final String ERROR_STRING = "NULL";
	private Activity main_activity;
	double lat, lng;
	String moyori_it;
	int menu_key;


	public RomettaSpot_GurunaviAPI(Activity activity) {
		this.main_activity = activity;
	}

	protected TreeMap<Integer, String> doInBackground(String... string) {
		//UIで入力された緯度経度を受け取る
		lat = Double.parseDouble(string[0]);
		lng = Double.parseDouble(string[1]);
		String freeword = string[2];
		String range = string[3];
		moyori_it = string[4];
		menu_key = Integer.parseInt(string[5]);

		if (freeword != null) {
			freeword_uri = "&freeword=" + freeword;
		} else {
			freeword_uri = "";
		}


		//APIから受け取ったスポットデータを格納するTreeMap
		TreeMap<Integer, String> Spot = new TreeMap<Integer, String>();

		//HTTPクライアントの生成
		HttpClient http_client = new DefaultHttpClient();

		//APIからXMLを取得する
    	Log.i(TAG, "createXML/lat:" + lat + ", lng:" + lng);
		String uri = api_uri + "keyid=" + keyid + "&format=" + format + freeword_uri
				+ "&freeword_condition=2" + "&latitude=" + lat + "&longitude=" + lng + "&range=" + range;
		Log.i(TAG, uri);
		HttpGet request = new HttpGet(uri);
    	HttpResponse response = null;

    	try {
    		response = http_client.execute(request);
    	} catch (ClientProtocolException e) {
    		e.printStackTrace();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}

    	int status = response.getStatusLine().getStatusCode();
    	if (status == HttpStatus.SC_OK) {
    		try {
    			ByteArrayOutputStream ostream = new ByteArrayOutputStream();
    			response.getEntity().writeTo(ostream);

    			//XMLパーサを生成
    			XmlPullParser xml_pullparser = Xml.newPullParser();
    			xml_pullparser.setInput(new StringReader(ostream.toString()));

    			int eventType = 0;
				String spot_detail = new String();
				String[] spot_data = new String[10];
				int spot_count = 0;


				//XML構文解析
    			while (((eventType = xml_pullparser.next()) != XmlPullParser.END_DOCUMENT) && (spot_count != 10)) {
    				if (eventType == XmlPullParser.START_TAG && "name".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "latitude".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "longitude".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "category".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "url".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "address".equals(xml_pullparser.getName())) {
        				spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "tel".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "opentime".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "holiday".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText();
    				} else if (eventType == XmlPullParser.END_TAG && "rest".equals(xml_pullparser.getName())) {
    					spot_count++;
    					spot_data[spot_count - 1] = spot_detail;
    					Log.i("spot_data", spot_data[spot_count-1]);
    					Spot.put(spot_count, spot_data[spot_count - 1]);
    					spot_detail = "";
    				}
    			}
    		} catch (Exception e) {
    	    	Log.d("XmlPullParser", "Error");
    	    }
    	}

		return Spot;

	}

	//以下はここまでの処理が行われた後に実行される
	@Override
	protected void onPostExecute(TreeMap<Integer, String> Spot) {
		String UserLat = Double.toString(lat);
		String UserLng = Double.toString(lng);

		Intent it = new Intent(main_activity, RomettaSpot_Result.class);
		it.putExtra("menu_key", menu_key);
		it.putExtra("SpotData", Spot);
		it.putExtra("UserLat", UserLat);
		it.putExtra("UserLng", UserLng);
		it.putExtra("UserStation", moyori_it);
		it.putExtra("API", "g");
		main_activity.startActivity(it);

	}
}
