package com.Rometta.Spot;

import java.util.List;

import com.Rometta.R;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class RomettaSpot_CustomAdapter extends ArrayAdapter<RomettaSpot_CustomData> {
	protected static int MAX_FONT_SIZE = 20;
	protected static int MIN_FONT_SIZE = 5;
	private LayoutInflater layoutInflater_;

	 public RomettaSpot_CustomAdapter(Context context, int textViewResourceId, List<RomettaSpot_CustomData> objects) {
		 super(context, textViewResourceId, objects);
		 layoutInflater_ = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	 }

	 @Override
	 public View getView(int position, View convertView, ViewGroup parent) {
		 // 特定の行(position)のデータを得る
		 RomettaSpot_CustomData item = (RomettaSpot_CustomData)getItem(position);

		 // convertViewは使い回しされている可能性があるのでnullの時だけ新しく作る
		 if (null == convertView) {
			 convertView = layoutInflater_.inflate(R.layout.activity_rometta_spot_custom_layout, null);
		 }

		 // CustomDataのデータをViewの各Widgetにセットする
		 ImageView imageView;
		 imageView = (ImageView)convertView.findViewById(R.id.image_number);
		 imageView.setImageBitmap(item.getImageData());

		 TextView textView;
		 textView = (TextView)convertView.findViewById(R.id.store_name);
		 //setMaxTextSize(item.getTextData(), textView);
		 textView.setText(item.getTextData());

		 TextView textView2;
		 textView2 = (TextView)convertView.findViewById(R.id.store_detail);
		 //setMaxTextSize(item.getTextData2(), textView2);
		 textView2.setText(item.getTextData2());

		 return convertView;
	 }
}