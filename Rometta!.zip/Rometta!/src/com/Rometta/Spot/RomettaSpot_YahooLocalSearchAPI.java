package com.Rometta.Spot;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.TreeMap;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.xmlpull.v1.XmlPullParser;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

public class RomettaSpot_YahooLocalSearchAPI extends AsyncTask<String, Void, TreeMap<Integer, String>>{
	static final String TAG = "YahooLocalSearchTest";
	static final int MIN_TIME = 0;
	static final int MIN_METER = 0;
	private static final String api_uri = "http://search.olp.yahooapis.jp/OpenLocalPlatform/V1/localSearch?";
	private static final String keyid = "dj0zaiZpPU9wYWVraUQyMlZHUyZzPWNvbnN1bWVyc2VjcmV0Jng9NWU-";
	private static final String device = "mobile";
	private static final String sort = "dist";
	private static final int results = 10;
	static final double ERROR_DOUBLE = 10000.0;
	static final String ERROR_STRING = "NULL";
	private Activity main_activity;
	float lat, lon;
	String moyori_it;

	public RomettaSpot_YahooLocalSearchAPI(Activity activity) {
		this.main_activity = activity;
	}

	protected TreeMap<Integer, String> doInBackground(String... string) {
		lat = Float.parseFloat(string[0]);
		lon = Float.parseFloat(string[1]);
		String gc = string[2];
		String dist = string[3];
		moyori_it = string[4];

		//APIから受け取ったスポットデータを格納するTreeMap
		TreeMap<Integer, String> Convini = new TreeMap<Integer, String>();

		//HTTPクライアントの生成
		HttpClient http_client = new DefaultHttpClient();

		//APIからXMLを生成
    	Log.i(TAG, "createXML/lat:" + lat + ", lon:" + lon);
		String uri = api_uri + "appid=" + keyid + "&device=" + device + "&sort=" + sort + "&results=" + results
				+ "&lat=" + lat + "&lon=" + lon + "&dist=" + dist + "&gc=" + gc;
		Log.i(TAG, uri);
    	HttpGet request = new HttpGet(uri);
    	HttpResponse response = null;

    	try {
    		response = http_client.execute(request);
    	} catch (ClientProtocolException e) {
    		e.printStackTrace();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}

    	int status = response.getStatusLine().getStatusCode();
    	if (status == HttpStatus.SC_OK) {
    		try {
    			ByteArrayOutputStream ostream = new ByteArrayOutputStream();
    			response.getEntity().writeTo(ostream);

    			//XMLパーサの生成
    			XmlPullParser xml_pullparser = Xml.newPullParser();
    			xml_pullparser.setInput(new StringReader(ostream.toString()));

    			int eventType = 0;
				String spot_detail = new String();
				String[] spot_data = new String[10];
				int spot_count = 0;
				int name_get_count = 0;
				boolean coordinates_get_is = false;

				//XML構文解析
    			while (((eventType = xml_pullparser.next()) != XmlPullParser.END_DOCUMENT) && (spot_count != 10)) {
    				if (eventType == XmlPullParser.START_TAG && "Name".equals(xml_pullparser.getName()) && name_get_count == 0) {
    					//店名を取得
    					spot_detail += xml_pullparser.nextText() + ",";
    					name_get_count = 1;
    				} else if (eventType == XmlPullParser.START_TAG && "Name".equals(xml_pullparser.getName()) && name_get_count == 1) {
    					//国名を取得するが、必要ないので格納せずにカウントだけ回す
    					name_get_count = 2;
    				} else if (eventType == XmlPullParser.START_TAG && "Name".equals(xml_pullparser.getName()) && name_get_count == 2) {
    					//ジャンル名を取得
        				spot_detail += xml_pullparser.nextText() + ",";
        				name_get_count = 3;
    				} else if (eventType == XmlPullParser.START_TAG && "Coordinates".equals(xml_pullparser.getName()) && coordinates_get_is != true) {
    					spot_detail += xml_pullparser.nextText() + ",";
    					coordinates_get_is = true;
    				} else if (eventType == XmlPullParser.START_TAG && "Address".equals(xml_pullparser.getName())) {
    					spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "Tel1".equals(xml_pullparser.getName())) {
    	    			spot_detail += xml_pullparser.nextText() + ",";
    				} else if (eventType == XmlPullParser.START_TAG && "PcUrl1".equals(xml_pullparser.getName())) {
    	    			spot_detail += xml_pullparser.nextText();
    				} else if (eventType == XmlPullParser.END_TAG && "Feature".equals(xml_pullparser.getName())) {
    					spot_count++;
    					spot_data[spot_count - 1] = spot_detail;
    					Log.i("spot_data", spot_data[spot_count-1]);
    					Convini.put(spot_count, spot_data[spot_count - 1]);
    					spot_detail = "";
    					name_get_count = 0;
    					coordinates_get_is = false;
    				}
    			}
    		} catch (Exception e) {
    	    	Log.d("XmlPullParser", "Error");
    	    }
    	}

		return Convini;

	}


	String[] spotDataAnalyze (String spotData) {
		String[] analyzedSpotData = spotData.split(",");
		return analyzedSpotData;
	}

	@Override
	protected void onPostExecute(TreeMap<Integer, String> Spot) {
		String UserLat = Float.toString(lat);
		String UserLon = Float.toString(lon);

		Intent it = new Intent(main_activity, RomettaSpot_Result.class);

		it.putExtra("SpotData", Spot);
		it.putExtra("UserLat", UserLat);
		it.putExtra("UserLng", UserLon);
		it.putExtra("UserStation", moyori_it);
		it.putExtra("API", "y");
		main_activity.startActivity(it);

	}
}
