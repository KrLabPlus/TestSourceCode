package com.Rometta.Spot;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;

import android.app.*;
import android.content.Intent;
import android.os.*;
import android.text.util.Linkify;
import android.util.*;
import android.widget.*;

import com.Rometta.R;
import com.Rometta.Norikae.RomettaNorikae_ParseJsonpOfDirectionAPI;
import com.google.android.gms.maps.*;
import com.google.android.gms.maps.GoogleMap.*;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.*;

public class RomettaSpot_ResultDetail extends Activity {
    GoogleMap gMap;
    Intent it;
    LatLng point;
    Object[] spot_data;
    String name, category, address, tel, opentime, holiday, url, api;

    public static String posinfo = "";
    public static String info_A = "";
    public static String info_B = "";
    ArrayList<LatLng> markerPoints;

    public static MarkerOptions options1;
    public static MarkerOptions options2;

    public ProgressDialog progressDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rometta_spot_result_detail);

        name = new String((String)getIntent().getExtras().get("Name"));
        category = new String((String)getIntent().getExtras().get("Category"));
        address = new String((String)getIntent().getExtras().get("Address"));
        tel = new String((String)getIntent().getExtras().get("Tel"));
        opentime = new String((String)getIntent().getExtras().get("Opentime"));
        holiday = new String((String)getIntent().getExtras().get("Holiday"));
        url = new String((String)getIntent().getExtras().get("Url"));
        api = new String((String)getIntent().getExtras().get("API"));


        //店舗情報を表示する各テキストビューを取得
        TextView tv_name = (TextView)findViewById(R.id.tv_name);
        TextView tv_category = (TextView)findViewById(R.id.tv_category);
        TextView tv_address = (TextView)findViewById(R.id.tv_address);
        TextView tv_tel = (TextView)findViewById(R.id.tv_tel);
        TextView tv_opentime = (TextView)findViewById(R.id.tv_opentime);
        TextView tv_holiday = (TextView)findViewById(R.id.tv_holiday);
        TextView tv_url = (TextView)findViewById(R.id.tv_url);

        tv_name.setText(name);
        tv_category.setText(category);
        tv_address.setText(address);
        tv_tel.setText(tel);
        tv_opentime.setText(opentime);
        tv_holiday.setText(holiday);

        //urlを利用してリンク生成
        if (url.equals("No data") != true) {
        	tv_url.setText("詳細はこちら(ブラウザが開きます)");
        	Pattern pattern = Pattern.compile("詳細はこちら");
        	final String strUrl = url;

        	Linkify.TransformFilter filter = new Linkify.TransformFilter() {
        		@Override
        		public String transformUrl(Matcher match, String url) {
        			return strUrl;
        		}
        	};
        	Linkify.addLinks(tv_url, pattern, strUrl, null, filter);
        }

    //プログレス(読み込み中にクルクルまわるやつ)
        progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage("ルート検索中...");
        progressDialog.hide();

        //初期化
        markerPoints = new ArrayList<LatLng>();
        MapFragment mapfragment = (MapFragment)getFragmentManager().findFragmentById(R.id.map);
        gMap = mapfragment.getMap();

        if (gMap != null) {
        	gMap.getUiSettings().setZoomControlsEnabled(true);
        }

        it = getIntent();

        // 出発地のマーカー設置
        point = new LatLng(it.getDoubleExtra("Start_lat", 0), it.getDoubleExtra("Start_lng", 0));
        markerPoints.add(point);

        options1 = new MarkerOptions();
        options1.position(point);
        options1.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        options1.title("出発地");

        // 到着地のマーカー設置
        point = new LatLng(it.getDoubleExtra("Goal_lat", 0), it.getDoubleExtra("Goal_lng", 0));
        markerPoints.add(point);

        options2 = new MarkerOptions();
        options2.position(point);
        options2.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        options2.title("到着地");

        gMap.addMarker(options1);
        gMap.addMarker(options2);

        LatLng location = new LatLng(it.getDoubleExtra("Start_lat", 0), it.getDoubleExtra("Start_lng", 0));
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 16));

        // ルート検索
        routeSearch();

        gMap.setOnMarkerClickListener(new OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
            	String title = marker.getTitle();
            	if (title.equals("出発地")){
            		marker.setSnippet(info_A);
            	}else if (title.equals("到着地")){
            		marker.setSnippet(info_B);
            	}
            	return false;
            }
        });
    }

    // ルート検索メソッド
    private void routeSearch(){
        progressDialog.show();

        LatLng origin = markerPoints.get(0);
        LatLng dest = markerPoints.get(1);

        // GoogleDirectionsAPI からURL取得
        String url = getDirectionsUrl(origin, dest);

        downloadTask downloadTask = new downloadTask();

        downloadTask.execute(url);
    }

    private String getDirectionsUrl(LatLng origin,LatLng dest){
    	// スタート地点の緯度・経度を指定
        String str_origin = "origin="+origin.latitude+","+origin.longitude;

        // ゴール地点の緯度・経度を指定
        String str_dest = "destination="+dest.latitude+","+dest.longitude;

        // GPSを使うか否か
        String sensor = "sensor=false";

        //JSON指定(帰ってくるデータの形式の指定)
        String output = "json";

        // parametersの宣言(これで条件を指定)
        String parameters = null;

        parameters = str_origin+"&"+str_dest+"&"+sensor+"&language=ja"+"&mode=walking";

        String url = "https://maps.googleapis.com/maps/api/directions/"+output+"?"+parameters;
        return url;
    }

    private String downloadUrl(String strUrl) throws IOException{
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try{
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            StringBuffer sb = new StringBuffer();

            String line = "";
            while( ( line = br.readLine()) != null){
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        }catch(Exception e){
            Log.d("Exception while downloading url", e.toString());
        }finally{
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    private class downloadTask extends AsyncTask<String, Void, String>{
    //非同期で取得
        @Override
        protected String doInBackground(String... url) {
            String data = "";
            try{
                // Fetching the data from web service
                data = downloadUrl(url[0]);
            }catch(Exception e){
                Log.d("Background Task",e.toString());
            }
            return data;
        }

        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            parserTask parserTask = new parserTask();

            parserTask.execute(result);
        }
    }

    // JSON形式で帰ってきたデータを解析
    private class parserTask extends AsyncTask<String, Integer, List<List<HashMap<String,String>>> >{

        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {
            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try{
                jObject = new JSONObject(jsonData[0]);
                RomettaNorikae_ParseJsonpOfDirectionAPI parser = new RomettaNorikae_ParseJsonpOfDirectionAPI();

                routes = parser.parse(jObject);
            }catch(Exception e){
                e.printStackTrace();
            }
            return routes;
        }

        //ルート検索で得た座標を使って経路表示
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {

            ArrayList<LatLng> points = null;
            PolylineOptions lineOptions = null;

            if(result.size() != 0){
                for(int i=0;i<result.size();i++){
                    points = new ArrayList<LatLng>();
                    lineOptions = new PolylineOptions();

                    List<HashMap<String, String>> path = result.get(i);

                    for(int j=0;j<path.size();j++){
                        HashMap<String,String> point = path.get(j);

                        double lat = Double.parseDouble(point.get("lat"));
                        double lng = Double.parseDouble(point.get("lng"));
                        LatLng position = new LatLng(lat, lng);

                        points.add(position);
                    }
                    //ポリライン
                    lineOptions.addAll(points);
                    lineOptions.width(17);
                    lineOptions.color(0x550000ff);
                }
                //描画
                gMap.addPolyline(lineOptions);
            }else{
                gMap.clear();
                Toast.makeText(RomettaSpot_ResultDetail.this, "ルート情報を取得できませんでした", Toast.LENGTH_LONG).show();
            }
            progressDialog.hide();
        }
    }
}