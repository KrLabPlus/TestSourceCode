package com.Rometta.Spot;


import com.Rometta.R;
import com.Rometta.RomettaSearchStation;
import com.Rometta.Server.*;

import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.DecelerateInterpolator;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class RomettaSpot extends Activity {
	String select, moyori_it = null;
	EditText station_edit_text;
	String[] strAry, strAry2;
	int count = 0;
	String lat, lng;
	String range = "1";
	String dist = "0.3";
	String category, gc;
	RadioButton radiobutton_food;
	RadioButton radiobutton_hotel;
	RadioButton radiobutton_postoffice;
	RadioButton radiobutton_convenience;
	String izakaya, restaurant, cafe, freeword;
	CheckBox check_izakaya;
	CheckBox check_restaurant;
	CheckBox check_cafe;
	private static final int MOYORI_ACTIVITY = 1001;
	Boolean _first = true;
	private accordionSet _as1;
	private accordionSet _as2;
	private accordionSet _as3;
	private accordionSet _as4;
	private accordionSet _as5;

	 @Override
	 public void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
		 setContentView(R.layout.activity_rometta_spot);

		 //最寄り駅名を入力するEditText
		 station_edit_text = (EditText) findViewById(R.id.editText1);
		 station_edit_text.setOnClickListener(new OnClickListener() {
			 @Override
			 public void onClick(View v) {
				Intent it;
				it = new Intent(getApplicationContext(), RomettaSearchStation.class);
				startActivityForResult(it, MOYORI_ACTIVITY);
				}
			});



		 /*------------選択されたカテゴリを取得する処理------------*/
		 radiobutton_food = (RadioButton)findViewById(R.id.radioButton_food);
		 radiobutton_hotel = (RadioButton)findViewById(R.id.radioButton_hotel);
		 radiobutton_postoffice = (RadioButton)findViewById(R.id.radioButton_postoffice);
		 radiobutton_convenience = (RadioButton)findViewById(R.id.radioButton_convenience);

		 check_izakaya = (CheckBox)findViewById(R.id.checkbox_izakaya);
		 check_restaurant = (CheckBox)findViewById(R.id.checkbox_restaurant);
		 check_cafe = (CheckBox)findViewById(R.id.checkbox_cafe);

		 radiobutton_food.setOnClickListener(new OnClickListener() {
			 @Override
			 public void onClick(View v) {
				 // ぐるなびAPIに飛ばす準備
				 category = "飲食店";
				 // 他のラジオボタンのチェックをはずす
				 radiobutton_hotel.setChecked(false);
				 radiobutton_postoffice.setChecked(false);
				 radiobutton_convenience.setChecked(false);

				//飲食店カテゴリのチェックボックスを使用可能にする
				 check_izakaya.setEnabled(true);
				 check_restaurant.setEnabled(true);
				 check_cafe.setEnabled(true);
			 }
		 });

		 radiobutton_hotel.setOnClickListener(new OnClickListener() {
			 @Override
			 public void onClick(View v) {
				 // Yahoo!ローカルサーチAPIに飛ばす準備
				 category = "ホテル";
				 gc = "0304001";
				 // 他のラジオボタンのチェックをはずす
				 radiobutton_food.setChecked(false);
				 radiobutton_postoffice.setChecked(false);
				 radiobutton_convenience.setChecked(false);

				 //飲食店カテゴリのチェックをはずす
				 check_izakaya.setChecked(false);
				 check_restaurant.setChecked(false);
				 check_cafe.setChecked(false);

				 //飲食店カテゴリのチェックボックスを使用不可にする
				 check_izakaya.setEnabled(false);
				 check_restaurant.setEnabled(false);
				 check_cafe.setEnabled(false);
			 }
		 });

		 radiobutton_postoffice.setOnClickListener(new OnClickListener() {
			 @Override
			 public void onClick(View v) {
				 // Yahoo!ローカルサーチAPIに飛ばす準備
				 category = "郵便局";
				 gc = "0411001";
				 // 他のラジオボタンのチェックをはずす
				 radiobutton_food.setChecked(false);
				 radiobutton_hotel.setChecked(false);
				 radiobutton_convenience.setChecked(false);

				 //飲食店カテゴリのチェックをはずす
				 check_izakaya.setChecked(false);
				 check_restaurant.setChecked(false);
				 check_cafe.setChecked(false);

				 //飲食店カテゴリのチェックボックスを使用不可にする
				 check_izakaya.setEnabled(false);
				 check_restaurant.setEnabled(false);
				 check_cafe.setEnabled(false);
			 }
		 });

		 radiobutton_convenience.setOnClickListener(new OnClickListener() {
			 @Override
			 public void onClick(View v) {
				 // Yahoo!ローカルサーチAPIに飛ばす準備
				 category = "コンビニエンスストア";
				 gc = "0205001";
				 // 他のラジオボタンのチェックをはずす
				 radiobutton_food.setChecked(false);
				 radiobutton_hotel.setChecked(false);
				 radiobutton_postoffice.setChecked(false);

				 //飲食店カテゴリのチェックをはずす
				 check_izakaya.setChecked(false);
				 check_restaurant.setChecked(false);
				 check_cafe.setChecked(false);

				 //飲食店カテゴリのチェックボックスを使用不可にする
				 check_izakaya.setEnabled(false);
				 check_restaurant.setEnabled(false);
				 check_cafe.setEnabled(false);
			 }
		 });

		 /*------------詳細検索条件の範囲指定を取得する処理------------*/
		 //詳細検索における範囲指定のラジオグループ
		 RadioGroup radioGroup1 = (RadioGroup)findViewById(R.id.RadioGroup1);
		 radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			 public void onCheckedChanged(RadioGroup group, int checkedId) {

             // 選択されたRadioButtonによって範囲を変更
             if (checkedId == R.id.radioButton300) {
             	range = "1";
             	dist = "0.3";
             } else if (checkedId == R.id.radioButton500) {
             	range = "2";
             	dist = "0.5";
             } else {
             	range = "3";
             	dist = "1";
             }
           }
         });

		 ImageButton search_btn = (ImageButton)findViewById(R.id.search_button);
			search_btn.setOnClickListener(new OnClickListener() {
				//@Override
				public void onClick(View v) {
        			if (izakaya == "居酒屋" && cafe == "" && restaurant == "") {
	    				freeword = izakaya;
	    			} else if (izakaya == "" && cafe == "カフェ" && restaurant == "") {
	    				freeword = cafe;
	    			} else if (izakaya == "" && cafe == "" && restaurant == "レストラン") {
	    				freeword = restaurant;
	    			} else if (izakaya == "居酒屋" && cafe == "カフェ" && restaurant == "") {
	    				freeword = izakaya + "," + cafe;
	    			} else if (izakaya == "" && cafe == "カフェ" && restaurant == "レストラン") {
	    				freeword = cafe + "," + restaurant;
	    			} else if (izakaya == "居酒屋" && cafe == "" && restaurant == "レストラン") {
	    				freeword = izakaya + "," + restaurant;
	    			} else if (izakaya == "居酒屋" && cafe == "カフェ" && restaurant == "レストラン") {
	    				freeword = izakaya + "," + cafe + "," + restaurant;
	    			} else {
	    				freeword = null;
	    			}

					if(moyori_it != null){
						exec_post(moyori_it);
					} else {
						moyori_it = "はりまや橋";
						exec_post(moyori_it);	//デフォルト地点
					}
				}
			});

		//ぐるなびAPIに投げるために飲食店のカテゴリを格納する
	        check_izakaya.setOnClickListener(new View.OnClickListener() {
	            @Override
	            public void onClick(View v) {
	                CheckBox checkBox = (CheckBox) v;
	                // チェックボックスのチェック状態を取得します
	                if (checkBox.isChecked() == true) {
	                	izakaya = "居酒屋";
	                } else {
	                	izakaya = "";
	                }
	            }
	        });

	        check_restaurant.setOnClickListener(new View.OnClickListener() {
	            @Override
	            public void onClick(View v) {
	                CheckBox checkBox = (CheckBox) v;
	                // チェックボックスのチェック状態を取得します
	                if (checkBox.isChecked() == true) {
	                	restaurant = "レストラン";
	                } else {
	                	restaurant = "";
	                }
	            }
	        });

	        check_cafe.setOnClickListener(new View.OnClickListener() {
	            @Override
	            public void onClick(View v) {
	                CheckBox checkBox = (CheckBox) v;
	                // チェックボックスのチェック状態を取得します
	                if (checkBox.isChecked() == true) {
	                	cafe = "カフェ";
	                } else {
	                	cafe = "";
	                }
	            }
	        });
	 }

		protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		  // TODO Auto-generated method stub
		  // requestCodeがサブ画面か確認する
		  if(requestCode == MOYORI_ACTIVITY) {
		    // resultCodeがOKか確認する
		      if(resultCode == RESULT_OK) {
		      // 結果を取得して, 表示する.
		          station_edit_text.setText(data.getCharSequenceExtra("keyword"));
		          moyori_it = (String)data.getCharSequenceExtra("keyword");
		      }
		  }
		}

		/*-------------サーバへリクエスト--------------*/
		public void exec_post(String station) {

		    // 非同期タスクを定義
		    HttpPostTask task = new HttpPostTask(
		      this,
		      "http://krlab.info.kochi-tech.ac.jp/Krlabp/GetStationData.php?Name='" + station + "'",

		      // タスク完了時に呼ばれるUIのハンドラ
		      new HttpPostHandler(){
		        @Override
		        public void onPostCompleted(String response) {
		        	strAry = response.split(",");
		        		strAry2 = strAry[2].split("=");
		        		lat = strAry2[1];
		        		strAry2 = strAry[3].split("=");
		        		lng = strAry2[1];


						//カテゴリが飲食店なら、GurunaviAPIに緯度経度などを投げる
		        		if (radiobutton_food.isChecked() == true) {
		        			RomettaSpot_GurunaviAPI task_gurunavi = new RomettaSpot_GurunaviAPI(RomettaSpot.this);
		        			task_gurunavi.execute(lat, lng, freeword, range, moyori_it);
		        		} else {
						//カテゴリが飲食店以外なら、YahooローカルサーチAPIに緯度経度などを投げる
		        			RomettaSpot_YahooLocalSearchAPI task_yahoo = new RomettaSpot_YahooLocalSearchAPI(RomettaSpot.this);
		        			task_yahoo.execute(lat, lng, gc, dist, moyori_it);
		        		}

		        }
		        @Override
		        public void onPostFailed(String response) {
		          Toast.makeText(
		            getApplicationContext(),
		            "通信エラーが発生しました。\nもう一度「さがす」ボタンを押してください",
		            Toast.LENGTH_LONG
		          ).show();
		        }
		      });
		    task.addPostParam( "post_1", "ユーザID" );
		    task.addPostParam( "post_2", "パスワード" );

		    // タスクを開始
		    task.execute();
		  }






	 //フォーカスが変更されたとき呼び出される
	 @Override
	 public void onWindowFocusChanged(boolean hasFocus) {
		 if (_first) {
			 _first = false;
			 _as1 = new accordionSet((LinearLayout)findViewById(R.id.btn_food), (LinearLayout)findViewById(R.id.content_izakaya), (LinearLayout)findViewById(R.id.content_restaurant), (LinearLayout)findViewById(R.id.content_cafe));
			 _as2 = new accordionSet((LinearLayout)findViewById(R.id.btn_hotel));
			 _as3 = new accordionSet((LinearLayout)findViewById(R.id.btn_postoffice));
			 _as4 = new accordionSet((LinearLayout)findViewById(R.id.btn_convenience));
			 _as5 = new accordionSet((LinearLayout)findViewById(R.id.btn_details), (LinearLayout)findViewById(R.id.moyori), (LinearLayout)findViewById(R.id.content02));
		 }
	 super.onWindowFocusChanged(hasFocus);
	 }

	 //アコーディオンリストの表示を削除
	 @Override
	 protected void onDestroy() {
		 if (!_first) {
			 _as1.deleteAccordion();
			 _as2.deleteAccordion();
			 _as3.deleteAccordion();
			 _as4.deleteAccordion();
			 _as5.deleteAccordion();
		 }
	 super.onDestroy();
	 }



/*-------------以下、アコーディオンリストの設定--------------*/
//アコーディオンセットを設定するクラス
public class accordionSet {

	private LinearLayout _btn;
	private LinearLayout _content01;
	private LinearLayout _content02;
	private LinearLayout _content1;
	private LinearLayout _content2;
	private LinearLayout _content3;
	private Handler _handler0;
	private Handler _handler;
	private float _height01;
	private float _height02;
	private float _height;
	private float current01 = 0.0f;
	private float current02 = 0.0f;
	private float current = 0.0f;
	private Thread _thread0;
	private Thread _thread;
	private String _bound0 = "close";
	private String _bound = "close";
	private int _startTime0;
	private int _startTime;
	private DecelerateInterpolator mInterpolator0 = new DecelerateInterpolator();
	private DecelerateInterpolator mInterpolator = new DecelerateInterpolator();
	private int easeTime = 400;

	public accordionSet(LinearLayout btn){
		_btn = btn;
	}


	//詳細設定
	public accordionSet(LinearLayout btn, LinearLayout content01, LinearLayout content02) {
		_btn = btn;
		_content01 = content01;
		_content02 = content02;
		_handler0 = new Handler();
		_height01 = _content01.getHeight();
		_height02 = _content02.getHeight();
		mInterpolator0 = new DecelerateInterpolator();
		_content01.setLayoutParams(new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, 0));
		_content02.setLayoutParams(new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, 0));

		_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				_startTime0 = (int)System.currentTimeMillis();
				if (_bound0.equals("open")) {
					_bound0 = "close";
				} else {
					_bound0 = "open";
				}
				if (_thread0 == null || !_thread0.isAlive()) {
					_thread0 = null;
					makeThread0();
					_thread0.start();
				}
			}
		});

	}


 //完了したアコーディオンリスト

	public accordionSet(LinearLayout btn, LinearLayout content1, LinearLayout content2, LinearLayout content3) {
		_btn = btn;
		_content1 = content1;
		_content2 = content2;
		_content3 = content3;
		_handler = new Handler();
		_height = _content1.getHeight();
		mInterpolator = new DecelerateInterpolator();
		_content1.setLayoutParams(new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, 0));
		_content2.setLayoutParams(new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, 0));
		_content3.setLayoutParams(new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, 0));
		_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				_startTime = (int)System.currentTimeMillis();
				if (_bound.equals("open")) {
					_bound = "close";
				} else {
					_bound = "open";
				}

				if (_thread == null || !_thread.isAlive()) {
					_thread = null;
					makeThread();
					_thread.start();
				}

			}
		});
	}




	private void makeThread0() {
		_thread0 = new Thread(new Runnable() {
			public void run() {
				while (easeTime > (int)System.currentTimeMillis() - _startTime0) {
					int diff = (int)System.currentTimeMillis() - _startTime0;
					if (_bound0.equals("open")) {
						current01 = _height01 * mInterpolator0.getInterpolation((float)diff/(float)easeTime);
						current02 = _height02 * mInterpolator0.getInterpolation((float)diff/(float)easeTime);
					} else {
						current01 = _height01-_height01 * mInterpolator0.getInterpolation((float)diff/(float)easeTime);
						current02 = _height02-_height02 * mInterpolator0.getInterpolation((float)diff/(float)easeTime);
					}
					threadFunc0();
				}
			}
		});
	}

	private void makeThread() {
		_thread = new Thread(new Runnable() {
			public void run() {
				while (easeTime > (int)System.currentTimeMillis() - _startTime) {
					int diff = (int)System.currentTimeMillis() - _startTime;
					if (_bound.equals("open")) {
						current = _height * mInterpolator.getInterpolation((float)diff/(float)easeTime);
					} else {
						current = _height-_height * mInterpolator.getInterpolation((float)diff/(float)easeTime);
					}
					threadFunc();
				}
			}
		});
	}

	private void threadFunc0() {
		_handler0.post(new Runnable() {

			public void run() {
				_content01.setLayoutParams(new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.MATCH_PARENT, (int) current01));
				_content02.setLayoutParams(new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.MATCH_PARENT, (int) current02));
			}
		});
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
		}
	}

	private void threadFunc() {
		_handler.post(new Runnable() {

			public void run() {
				_content1.setLayoutParams(new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.MATCH_PARENT, (int) current));
				_content2.setLayoutParams(new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.MATCH_PARENT, (int) current));
				_content3.setLayoutParams(new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.MATCH_PARENT, (int) current));
			}
		});
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
		}
	}

	public void deleteAccordion() {
		_btn.setOnClickListener(null);
		_btn = null;
		_content01 = null;
		_content02 = null;
		_content1 = null;
		_content2 = null;
		_content3 = null;
	}
	}


}