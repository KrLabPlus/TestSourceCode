package com.Rometta.Spot;

import com.Rometta.R;
import com.Rometta.R.id;
import com.Rometta.R.layout;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class RomettaSpot extends Activity{
	Button bt1;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_spot);

		bt1 = (Button)findViewById(R.id.button1);

		bt1.setOnClickListener(new SampleClickListener());
	}
	class SampleClickListener implements OnClickListener{
		public void onClick(View v){
			finish();
		}
	}
}
