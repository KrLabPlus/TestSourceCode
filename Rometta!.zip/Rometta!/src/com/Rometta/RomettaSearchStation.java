package com.Rometta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

public class RomettaSearchStation extends Activity {

	Button bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9, bt0, dmp;
	ListView lv;
	TextView tv;
	String bn, parentName = "_parent", childName = "_child";
	List<Map<String, String>> list = new ArrayList<Map<String, String>>();
	SimpleAdapter adapter;
	int count = 0;
	String[] parent, child;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_search_station);

        bt1 = (Button)findViewById(R.id.button_A);
        bt2 = (Button)findViewById(R.id.button_ka);
        bt3 = (Button)findViewById(R.id.button_sa);
        bt4 = (Button)findViewById(R.id.button_ta);
        bt5 = (Button)findViewById(R.id.button_na);
        bt6 = (Button)findViewById(R.id.button_ha);
        bt7 = (Button)findViewById(R.id.button_ma);
        bt8 = (Button)findViewById(R.id.button_ya);
        bt9 = (Button)findViewById(R.id.button_ra);
        bt0 = (Button)findViewById(R.id.button_wa);

        adapter = new SimpleAdapter(
       		this,
       		list,
       		android.R.layout.simple_list_item_2,
       		new String[] {"Parent", "Child"},
       		new int[] {android.R.id.text1, android.R.id.text2});

        lv = (ListView) findViewById(R.id.listView1);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> av, View vi, int position, long id) {
            	Intent it = new Intent();
            	if(bn != "WA"){
            		it.putExtra("keyword", parent[position]);

            		setResult(RESULT_OK, it);
            		finish();
            	}
            }
        });

        bt1.setOnClickListener(new AkaClickListener());
        bt2.setOnClickListener(new AkaClickListener());
        bt3.setOnClickListener(new AkaClickListener());
        bt4.setOnClickListener(new AkaClickListener());
        bt5.setOnClickListener(new AkaClickListener());
        bt6.setOnClickListener(new AkaClickListener());
        bt7.setOnClickListener(new AkaClickListener());
        bt8.setOnClickListener(new AkaClickListener());
        bt9.setOnClickListener(new AkaClickListener());
        bt0.setOnClickListener(new AkaClickListener());

	}

    class AkaClickListener implements OnClickListener{
    	public void onClick(View v){
    		if(dmp != null && dmp != (Button)v){
    			dmp.setBackgroundResource(R.drawable.search_station_button_normal);
    		}
    		if(v == bt1){
    			bt1.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "A";
    		} else if(v == bt2){
    			bt2.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "KA";
    		} else if(v == bt3){
    			bt3.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "SA";
    		} else if(v == bt4){
    			bt4.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "TA";
    		} else if(v == bt5){
    			bt5.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "NA";
    		} else if(v == bt6){
    			bt6.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "HA";
    		} else if(v == bt7){
    			bt7.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "MA";
    		} else if(v == bt8){
    			bt8.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "YA";
    		} else if(v == bt9){
    			bt9.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "RA";
    		} else {
    			bt0.setBackgroundResource(R.drawable.search_station_button_pressed);
    			bn = "WA";
    		}
    		dmp = (Button) v;

    		int parentId = getResources().getIdentifier(bn + parentName, "array", getPackageName());
        	int childId = getResources().getIdentifier(bn + childName, "array", getPackageName());

        	parent = getResources().getStringArray(parentId);
        	child = getResources().getStringArray(childId);

    		if(count != 0){
        		for(int i = count - 1; i >= 0; i--){
        			list.remove(i);
        		}
    		}

        	count = parent.length;

        	for (int i = 0; i < parent.length; i++) {
        		Map<String, String> conMap = new HashMap<String, String>();
        		conMap.put("Parent", parent[i]);
        		conMap.put("Child", child[i]);
        		list.add(conMap);
        	}
    		adapter.notifyDataSetChanged();
    	}
	}
}