package com.Rometta.HowTo;

import com.Rometta.R;

import android.app.Activity;
import android.os.Bundle;

public class RomettaHowTo_Norikae extends Activity {

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_howto_norikae);
	}

}
