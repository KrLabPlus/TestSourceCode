package com.Rometta.HowTo;

import java.util.Locale;

import com.Rometta.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuItem;

public class RomettaHowTo_Norikae extends Activity {
	int menu_key;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rometta_howto_norikae);
		setTitle(R.string.title_howto_norikae);
		menu_key = (Integer) getIntent().getExtras().get("menu_key");
	}
	
	//メニューの項目が選択されたときに使用するメソッド
	//keyの数字は上のメソッドの数字に対応している
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int key = 0;
		switch (item.getItemId()) {
		  case R.id.japanese:
			  key = 0;
			  setLocale("ja");
			  reload(key);
			  break;
		  case R.id.english:
			  key = 1;
			  setLocale("en");
			  reload(key);
			  break;
		  case R.id.tosaben:
			  key = 2;
			  setLocale("");
			  reload(key);
			  break;
		  case R.id.credit:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    builder.setTitle("このアプリについて");
			    builder.setMessage("Rometta! ver 1.0.1" + "\n" +"現在このアプリケーションは最新です。" + "\n" +"\n" 
			    		+ "Rometta!はとさでん交通株式会社が運営する高知県の路面電車専用の乗り換えアプリケーションです。"
			    		+ "このアプリケーションは以下のAPIを使用しています。"+ "\n" + "\n" + "Google Maps API"
			    		+ "\n" + "ぐるなびAPI" + "\n" + "Yahoo! Open Local Platform");
			    AlertDialog dialog = builder.create();
			    dialog.show();
			    break;
		}
		return super.onOptionsItemSelected(item);
	}

	//参照するファイルを変更するメソッド
	public	void setLocale(String lang){
			Locale locale = new Locale(lang);
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			getResources().updateConfiguration(config, null);
	}

	//画面を再読み込みするメソッド
	//画面遷移する際に、putExtraで選択された言語情報を渡している
	public void reload(int key) {
		Intent reload = getIntent();
		overridePendingTransition(0, 0);
		reload.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		finish();

		overridePendingTransition(0, 0);
		reload.putExtra("menu_key", key);
		startActivity(reload);
	}

}
