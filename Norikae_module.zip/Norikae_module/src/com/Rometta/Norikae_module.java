package com.Rometta;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.OnClickListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;

public class Norikae_module extends Activity {
	String select;
	private AlertDialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.norikae_module);
		// カスタムビュー設定
		LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
		final View layout = inflater.inflate(R.layout.dialog, (ViewGroup) findViewById(R.id.dialog_custom));
		
		// 時刻設定ボタンのオブジェクト取得
		final Button btn = (Button) findViewById(R.id.set_button);
		
		// さがすボタンのオブジェクト取得
		ImageButton search_btn = (ImageButton) findViewById(R.id.search_button);
		
		//発着地を別画面でタップ入力させる(未完成)
		EditText from_text = (EditText)findViewById(R.id.from_text);
		EditText to_text = (EditText)findViewById(R.id.to_text);
		from_text.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
			    // ①駅名入力画面への遷移処理
				// ②駅名入力画面から返ってきた値をEditTextに表示する
			}
		});
		
		to_text.setOnClickListener(new OnClickListener() {
			@Override
		    public void onClick(View v) {
		        // ①駅名入力画面への遷移処理
				// ②駅名入力画面から返ってきた値をEditTextに表示する
		    }
		});
		
		//入れ替えボタンがタップされたときの入れ替え処理
		ImageButton change_button = (ImageButton) findViewById(R.id.change_button);
		change_button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				EditText from_text = (EditText)findViewById(R.id.from_text);
				EditText to_text = (EditText)findViewById(R.id.to_text);
				SpannableStringBuilder sb1 = (SpannableStringBuilder)from_text.getText();
				SpannableStringBuilder sb2 = (SpannableStringBuilder)to_text.getText();
				SpannableStringBuilder tmp;
				tmp = sb1;
				sb1 = sb2;
				sb2 = tmp;
				from_text.setText((CharSequence) sb1);
				to_text.setText((CharSequence) sb2);
			}
		});

		// アラートダイアログ生成
		if (dialog == null) {
			dialog = new AlertDialog.Builder(this)
					.setTitle("時間を選択してください。")
					.setView(layout)
		
					.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {	
							// OKボタンクリック処理 
				
							// 設定した日時取得
							DatePicker date = (DatePicker)layout.findViewById(R.id.datepicker);
							TimePicker time = (TimePicker)layout.findViewById(R.id.timepicker);
	    	    
							//ラジオボタンの値取得
							RadioGroup radioGroup = (RadioGroup)layout.findViewById(R.id.radio_group);
							select = getString(R.string.from_radio_button_select);
							int checkedId = radioGroup.getCheckedRadioButtonId();
							// 選択されたRadioButtonによって範囲を変更  
							if (checkedId == R.id.to_radio_button) {
								select = getString(R.string.to_radio_button_select);  	
							} else if (checkedId == R.id.start_radio_button) {
								select = getString(R.string.start_radio_button);
							} else if (checkedId == R.id.finish_radio_button){
								select = getString(R.string.finish_radio_button);
							} else {
								select = getString(R.string.from_radio_button_select);
							}
	            
							String zero = "";
							if (time.getCurrentMinute() < 10) {
								zero = "0";
							}
	    	    
							// ボタンの文字変更
                            if (checkedId == R.id.from_radio_button || checkedId == R.id.to_radio_button) {
                                btn.setText(date.getYear() + "/" + (date.getMonth() + 1) + "/" + date.getDayOfMonth() + " " + time.getCurrentHour() + ":" + zero + time.getCurrentMinute() + " " + select);
                            } else {
                                btn.setText(date.getYear() + "/" + (date.getMonth() + 1) + "/" + date.getDayOfMonth() + " " + select);
                            }
						}	
					})
		
					.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							// Cancelボタンクリック処理
							// 現在の日時取得
							Calendar calendar = Calendar.getInstance();
							int year = calendar.get(Calendar.YEAR); // 年
							int month = calendar.get(Calendar.MONTH) + 1; // 月
							int day = calendar.get(Calendar.DAY_OF_MONTH); // 日
							int hour = calendar.get(Calendar.HOUR_OF_DAY); // 時
							int minute = calendar.get(Calendar.MINUTE); // 分
							// ボタンの文字変更
							btn.setText(year + "/" + month + "/" + day + " " + hour + ":" + minute + " " + "発");
						}
					})
		
					.create();
			}
		
		btn.setOnClickListener(new OnClickListener() {
			//@Override
			public void onClick(View v) {
				// 表示
		        dialog.show();
			}
		});
		
		search_btn.setOnClickListener(new OnClickListener() {
			//@Override
			public void onClick(View v) {
				//遷移先に緯度経度・時刻などを渡す処理
			}
		});
	}

	//設定メニュー
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.norikae_module, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}