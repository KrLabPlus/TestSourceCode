package com.Rometta;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Jikoku extends Activity implements OnClickListener {
	//与えられた値と仮定する
	String home = "菜園場";
	String[] jikoku = {"6:20:00", "6:30:00", "6:40:00"};
	//普通の路面電車=0,金曜限定=1, ハートラム=2として仮で扱ってます
	String[] kind ={"1", "0","2"};
	String[] destination = {"いの", "鏡川橋", "いの"};
	String[] destination_holi = {"1", "2", "ダー"};
	Bitmap bitmap;

	private Button btn1;
	private Button btn2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jikoku);
        btn1 = (Button)findViewById(R.id.heijitu);
        btn2 = (Button)findViewById(R.id.yasumi);

	    btn1.setOnClickListener(this);
	    btn2.setOnClickListener(this);

	    btn1.setBackgroundResource(R.drawable.button_pressed);

	    //駅名（乗り駅)
	    TextView textView = (TextView) findViewById(R.id.train_name);
	    textView.setText(home);

		ListView listView = (ListView) findViewById(R.id.listview1);

		// リスト
		List<JikokuListItemData> list = weekDay();
        CustomAdapter customAd = new CustomAdapter(this, list);
        listView.setAdapter(customAd);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jikoku, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

    public void onClick(View v) {
		ListView listView = (ListView) findViewById(R.id.listview1);
    	switch (v.getId()) {
    	case R.id.heijitu:
    		btn1.setBackgroundResource(R.drawable.button_pressed);
    		btn2.setBackgroundResource(R.drawable.button_normal);
			List<JikokuListItemData> list1 = weekDay();
        	CustomAdapter customAd1 = new CustomAdapter(this, list1);
        	listView.setAdapter(customAd1);
        	break;
    	case R.id.yasumi:
    		btn1.setBackgroundResource(R.drawable.button_normal);
    		btn2.setBackgroundResource(R.drawable.button_pressed);
			List<JikokuListItemData> list2 = holiDay();
        	CustomAdapter customAd2 = new CustomAdapter(this, list2);
        	listView.setAdapter(customAd2);
        	break;
    	}
    }


	//平日のときの処理
	private List<JikokuListItemData> weekDay(){
		List<JikokuListItemData> list = new ArrayList<JikokuListItemData>();
        for (int i = 0; i < jikoku.length; i++) {
            JikokuListItemData tempData = new JikokuListItemData();

            String[] jikoku_split = jikoku[i].split(":", 0);
            tempData.setText1(jikoku_split[0]+":"+jikoku_split[1]);
            tempData.setText2(destination[i]+"行き");

            if (kind[i] == "0") {
            	tempData.setText1(jikoku_split[0]+":"+jikoku_split[1]+"  ");
            } else if (kind[i] == "1") {
            	bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.friday);
            	bitmap = Bitmap.createScaledBitmap(bitmap, 40, 40, true);
                tempData.setColor1(bitmap);
            } else {
            	bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.heartrum);
            	bitmap = Bitmap.createScaledBitmap(bitmap, 40, 40, true);
                tempData.setColor1(bitmap);
            }
            //tempData.setColor2(BitmapFactory.decodeResource(getResources(),
            //        R.drawable.arrow));

            tempData.setId(i);
            list.add(tempData);
        }
		return list;
	}

	//休日のときの処理
	private List<JikokuListItemData> holiDay(){
		List<JikokuListItemData> list = new ArrayList<JikokuListItemData>();
        for (int i = 0; i < jikoku.length; i++) {
            JikokuListItemData tempData = new JikokuListItemData();

            String[] jikoku_split = jikoku[i].split(":", 0);
            tempData.setText1(jikoku_split[0]+":"+jikoku_split[1]);
            tempData.setText2(destination_holi[i]+"行き");

            if (kind[i] == "0") {
            	tempData.setText1(jikoku_split[0]+":"+jikoku_split[1]+"  ");
            } else if (kind[i] == "1") {
            	bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.friday);
            	bitmap = Bitmap.createScaledBitmap(bitmap, 40, 40, true);
                tempData.setColor1(bitmap);
            } else {
            	bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.heartrum);
            	bitmap = Bitmap.createScaledBitmap(bitmap, 40, 40, true);
                tempData.setColor1(bitmap);
            }
            //tempData.setColor2(BitmapFactory.decodeResource(getResources(),
            //        R.drawable.arrow));

            tempData.setId(i);
            list.add(tempData);
        }
		return list;
	}
}
