package com.Rometta;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {
	Context context;
    private List<JikokuListItemData> list;

    private class ViewHolder {
        ImageView imageView1;
        ImageView imageView2;
        TextView txtView1;
        TextView txtView2;
    }

    private ViewHolder holder;

    public CustomAdapter(Context context, List<JikokuListItemData> list) {
        this.context = context;
        this.list = list;
    }


	@Override
    public View getView(int pos, View convertView, ViewGroup parent) {
        // 特定の行(pos)のデータを得る
        JikokuListItemData item = (JikokuListItemData) getItem(pos);

        if (convertView == null) {
            LinearLayout layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.HORIZONTAL);
            layout.setGravity(Gravity.CENTER_VERTICAL);
            convertView = layout;

            holder = new ViewHolder();

            // テキストビュー 時刻
            TextView textview1 = new TextView(context);
            textview1.setPadding(70, 10, 0, 10);
            textview1.setTextSize(25);
            textview1.setTextColor(Color.BLACK);

            // イメージビュー 車種
            ImageView colorview1 = new ImageView(context);
            colorview1.setPadding(50, 0, 0, 0);

            // テキストビュー 駅名
            TextView textview2 = new TextView(context);
            textview2.setPadding(100, 10, 0, 10);
            textview2.setTextSize(25);
            textview2.setTextColor(Color.BLACK);

            // イメージビュー矢印
            //ImageView colorview2 = new ImageView(context);
            //colorview2.setPadding(200, 0, 0, 0);

            holder.txtView1 = textview1;
            holder.imageView1 = colorview1;
            holder.txtView2 = textview2;
            //holder.imageView2 = colorview2;
            layout.addView(holder.txtView1);
            layout.addView(holder.imageView1);
            layout.addView(holder.txtView2);
            //layout.addView(holder.imageView2);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txtView1.setText(item.getText1());
        holder.imageView1.setImageBitmap(item.getColor1());
        holder.txtView2.setText(item.getText2());
        //holder.imageView2.setImageBitmap(item.getColor2());

        return convertView;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

}
