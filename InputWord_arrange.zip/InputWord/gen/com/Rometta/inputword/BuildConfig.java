/** Automatically generated file. DO NOT MODIFY */
package com.Rometta.inputword;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}